import { and, eq, lt, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  callLogs,
  conversations,
  messages,
  purgeEvents,
  stickers,
  users,
} from "@/db/schema";
import { PURGE_HOURS } from "@/lib/config";
import type {
  CallWire,
  ConversationWire,
  MessageWire,
  PurgeWire,
  StickerWire,
  UserWire,
} from "@/lib/types";

type MessageRow = typeof messages.$inferSelect;
type CallRow = typeof callLogs.$inferSelect;
type StickerRow = typeof stickers.$inferSelect;
type PurgeRow = typeof purgeEvents.$inferSelect;

export const toMessageWire = (row: MessageRow): MessageWire => ({
  id: row.id,
  conversationId: row.conversationId,
  senderId: row.senderId,
  kind: row.kind as MessageWire["kind"],
  body: row.body,
  mediaData: row.mediaData,
  mediaMime: row.mediaMime,
  mediaName: row.mediaName,
  stickerId: row.stickerId,
  replyToId: row.replyToId,
  status: row.status as MessageWire["status"],
  simulated: row.simulated === 1,
  createdAt: row.createdAt.toISOString(),
  expiresAt: row.expiresAt.toISOString(),
});

export const toCallWire = (row: CallRow): CallWire => ({
  id: row.id,
  conversationId: row.conversationId,
  callerId: row.callerId,
  kind: row.kind as CallWire["kind"],
  status: row.status as CallWire["status"],
  durationSeconds: row.durationSeconds,
  startedAt: row.startedAt.toISOString(),
});

export const toStickerWire = (row: StickerRow): StickerWire => ({
  id: row.id,
  ownerId: row.ownerId,
  pack: row.pack,
  label: row.label,
  source: row.source as StickerWire["source"],
  data: row.data,
  createdAt: row.createdAt.toISOString(),
});

export const toPurgeWire = (row: PurgeRow): PurgeWire => ({
  id: row.id,
  purged: row.purged,
  trigger: row.trigger,
  ranAt: row.ranAt.toISOString(),
});

export const dmKey = (a: string, b: string) => [a, b].sort().join("+");

export function membersOf(
  conv: { kind: string; key: string },
  all: UserWire[],
): number[] {
  if (conv.kind === "group") return all.map((u) => u.id);
  return conv.key
    .split("+")
    .map((handle) => all.find((u) => u.handle === handle)?.id)
    .filter((id): id is number => typeof id === "number");
}

export const toConversationWire = (
  row: typeof conversations.$inferSelect,
  all: UserWire[],
): ConversationWire => ({
  id: row.id,
  kind: row.kind as ConversationWire["kind"],
  key: row.key,
  title: row.title,
  subject: row.subject,
  members: membersOf(row, all),
  lastMessageAt: row.lastMessageAt.toISOString(),
});

export const expiryFor = (at: Date = new Date()) =>
  new Date(at.getTime() + PURGE_HOURS * 3_600_000);

/**
 * AUTO-PURGE SWEEP
 * Physically deletes every message whose 48h TTL has elapsed and writes an
 * audit row so the Settings tab can show the vault staying lean.
 */
export async function purgeExpired(trigger: "auto" | "manual" = "auto") {
  const cutoff = new Date();
  const doomed = await db
    .select({ id: messages.id })
    .from(messages)
    .where(lt(messages.expiresAt, cutoff));

  const ids = doomed.map((d) => d.id);
  if (ids.length) {
    await db.delete(messages).where(
      and(
        lt(messages.expiresAt, cutoff),
        sql`${messages.expiresAt} is not null`,
      ),
    );
  }

  const [event] = await db
    .insert(purgeEvents)
    .values({ purged: ids.length, trigger })
    .returning();

  // keep the audit trail short
  await db.execute(sql`
    delete from purge_events
    where id not in (
      select id from purge_events order by ran_at desc limit 25
    )
  `);

  return { purged: ids.length, ids, event: toPurgeWire(event) };
}

export async function counters() {
  const [alive] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(messages);
  const [burned] = await db
    .select({ n: sql<number>`coalesce(sum(purged),0)::int` })
    .from(purgeEvents);
  return { alive: alive?.n ?? 0, burned: burned?.n ?? 0 };
}

export async function touchConversation(conversationId: number, at: Date) {
  await db
    .update(conversations)
    .set({ lastMessageAt: at })
    .where(eq(conversations.id, conversationId));
}

export async function findUserByHandle(handle: string) {
  const rows = await db.select().from(users).where(eq(users.handle, handle)).limit(1);
  return rows[0] ?? null;
}
