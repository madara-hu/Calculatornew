"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { Vault, haptic } from "@/lib/client";
import { GROUP_TITLE } from "@/lib/config";
import type {
  Bootstrap,
  CallWire,
  ConversationWire,
  MessageWire,
  PurgeWire,
  StickerWire,
  UserWire,
} from "@/lib/types";

export type ActiveCall = {
  id: number;
  conversationId: number;
  partnerIds: number[];
  kind: "audio" | "video";
  direction: "outgoing" | "incoming";
  phase: "ringing" | "connected";
  connectedAt: number | null;
};

export type Toast = { id: number; text: string; tone: "ok" | "warn" | "bad" };

export type StreamState = {
  state: "idle" | "connecting" | "live" | "error";
  url: string;
  received: number;
  lastEventAt: number | null;
};

type Ctx = {
  me: UserWire;
  users: UserWire[];
  userById: (id: number) => UserWire | undefined;
  threads: ConversationWire[];
  messages: MessageWire[];
  messagesIn: (conversationId: number) => MessageWire[];
  calls: CallWire[];
  stickers: StickerWire[];
  purges: PurgeWire[];
  alive: number;
  burned: number;
  purgeHours: number;
  ready: boolean;
  error: string | null;
  openId: number | null;
  setOpenId: (id: number | null) => void;
  typingIn: number[];
  stream: StreamState;
  activeCall: ActiveCall | null;
  demoReplies: boolean;
  toasts: Toast[];
  notify: (text: string, tone?: Toast["tone"]) => void;
  dismissToast: (id: number) => void;
  titleFor: (conv: ConversationWire) => string;
  othersIn: (conv: ConversationWire) => UserWire[];
  unreadIn: (conversationId: number) => number;
  send: (payload: {
    conversationId: number;
    kind: MessageWire["kind"];
    body?: string;
    mediaData?: string | null;
    mediaMime?: string | null;
    mediaName?: string | null;
    stickerId?: string | null;
    replyToId?: number | null;
  }) => Promise<void>;
  deleteMessage: (id: number) => Promise<void>;
  placeCall: (conversationId: number, kind: "audio" | "video") => Promise<void>;
  answerCall: () => void;
  declineCall: () => Promise<void>;
  endCall: (status: "completed" | "missed" | "declined") => Promise<void>;
  addSticker: (payload: { label: string; data: string; pack?: string }) => Promise<void>;
  removeSticker: (id: number) => Promise<void>;
  purgeNow: () => Promise<number>;
  setDemoReplies: (on: boolean) => Promise<void>;
  relock: () => Promise<void>;
  signOut: () => Promise<void>;
};

const VaultCtx = createContext<Ctx | null>(null);

export const useVault = () => {
  const ctx = useContext(VaultCtx);
  if (!ctx) throw new Error("useVault must be used inside <VaultProvider>");
  return ctx;
};

export function VaultProvider({ me, children }: { me: UserWire; children: ReactNode }) {
  const [users, setUsers] = useState<UserWire[]>([]);
  const [threads, setThreads] = useState<ConversationWire[]>([]);
  const [messages, setMessages] = useState<MessageWire[]>([]);
  const [calls, setCalls] = useState<CallWire[]>([]);
  const [stickers, setStickers] = useState<StickerWire[]>([]);
  const [purges, setPurges] = useState<PurgeWire[]>([]);
  const [alive, setAlive] = useState(0);
  const [burned, setBurned] = useState(0);
  const [purgeHours, setPurgeHours] = useState(48);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [openId, setOpenId] = useState<number | null>(null);
  const [typingIn, setTypingIn] = useState<number[]>([]);
  const [activeCall, setActiveCall] = useState<ActiveCall | null>(null);
  const [demoReplies, setDemoState] = useState(true);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [stream, setStream] = useState<StreamState>({
    state: "idle",
    url: "/api/stream",
    received: 0,
    lastEventAt: null,
  });

  const cursors = useRef({ msg: 0, call: 0, sticker: 0 });
  const openRef = useRef<number | null>(null);
  const callRef = useRef<ActiveCall | null>(null);
  const demoRef = useRef(true);
  const lastIncoming = useRef(0);
  const streamOk = useRef(false);
  const lastBeat = useRef(0);
  const forcePoll = useRef(false);
  openRef.current = openId;
  callRef.current = activeCall;
  demoRef.current = demoReplies;

  const notify = useCallback((text: string, tone: Toast["tone"] = "ok") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-2), { id, text, tone }]);
    window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);

  const dismissToast = useCallback((id: number) => {
    setToasts((t) => t.filter((x) => x.id !== id));
  }, []);

  const mergeMessages = useCallback((incoming: MessageWire[]) => {
    if (!incoming.length) return;
    setMessages((prev) => {
      const map = new Map(prev.map((m) => [m.id, m]));
      for (const m of incoming) map.set(m.id, m);
      return [...map.values()].sort((a, b) => a.id - b.id);
    });
    cursors.current.msg = Math.max(
      cursors.current.msg,
      ...incoming.map((m) => (m.id > 0 ? m.id : 0)),
    );
  }, []);

  /* ── first paint ── */
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data: Bootstrap = await Vault.bootstrap();
        if (cancelled) return;
        setUsers(data.users);
        setThreads(data.conversations);
        setMessages(data.messages);
        setCalls(data.calls);
        setStickers(data.stickers);
        setPurges(data.purges);
        setAlive(data.alive);
        setBurned(data.burned);
        setPurgeHours(data.purgeHours);
        cursors.current = {
          msg: data.messages.reduce((max, m) => Math.max(max, m.id), 0),
          call: data.calls.reduce((max, c) => Math.max(max, c.id), 0),
          sticker: data.stickers.reduce((max, s) => Math.max(max, s.id), 0),
        };
        setReady(true);
        const s = await Vault.settings();
        if (!cancelled) setDemoState(s.demoReplies);
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : "Vault unreachable");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  /* ── delta sync + auto-purge heartbeat ── */
  useEffect(() => {
    if (!ready) return;
    let busy = false;
    const tick = async () => {
      if (busy || document.hidden) return;
      const streamIsFresh = streamOk.current && Date.now() - lastBeat.current < 45_000;
      if (streamIsFresh && !forcePoll.current) return;
      forcePoll.current = false;
      busy = true;
      try {
        const res = await Vault.sync({
          after: cursors.current.msg,
          ac: cursors.current.call,
          as: cursors.current.sticker,
          open: openRef.current ?? undefined,
        });
        mergeMessages(res.messages);
        if (res.calls.length) {
          setCalls((prev) => {
            const map = new Map(prev.map((c) => [c.id, c]));
            for (const c of res.calls) map.set(c.id, c);
            return [...map.values()].sort((a, b) => b.startedAt.localeCompare(a.startedAt));
          });
          cursors.current.call = Math.max(
            cursors.current.call,
            ...res.calls.map((c) => c.id),
          );
        }
        if (res.stickers.length) {
          setStickers((prev) => {
            const map = new Map(prev.map((s) => [s.id, s]));
            for (const s of res.stickers) map.set(s.id, s);
            return [...map.values()].sort((a, b) => a.id - b.id);
          });
          cursors.current.sticker = Math.max(
            cursors.current.sticker,
            ...res.stickers.map((s) => s.id),
          );
        }
        if (res.purges.length) setPurges(res.purges);
        if (res.deletedMessageIds.length) {
          const gone = new Set(res.deletedMessageIds);
          setMessages((prev) => prev.filter((m) => !gone.has(m.id)));
        }
        for (const group of res.readIds) {
          const ids = new Set(group.ids);
          setMessages((prev) =>
            prev.map((m) => (ids.has(m.id) && m.status !== "read" ? { ...m, status: "read" } : m)),
          );
        }
        setAlive(res.alive);
        setBurned(res.burned);
      } catch {
        /* transient — next tick retries */
      } finally {
        busy = false;
      }
    };
    const timer = window.setInterval(tick, 2400);
    document.addEventListener("visibilitychange", tick);
    return () => {
      window.clearInterval(timer);
      document.removeEventListener("visibilitychange", tick);
    };
  }, [ready, mergeMessages]);

  /* ── realtime: SSE first, polling as the safety net ── */
  useEffect(() => {
    if (!ready) return;
    const url = (process.env.NEXT_PUBLIC_CLOUDFLARE_STREAM_URL || "").trim() || "/api/stream";
    const es = new EventSource(url, { withCredentials: true });
    setStream((s) => ({ ...s, url, state: "connecting" }));

    const beat = () => {
      streamOk.current = true;
      lastBeat.current = Date.now();
      setStream((s) => ({ ...s, state: "live", lastEventAt: Date.now() }));
    };

    const onVault = (raw: MessageEvent<string>) => {
      beat();
      let event: any;
      try {
        event = JSON.parse(raw.data);
      } catch {
        return;
      }
      setStream((s) => ({ ...s, received: s.received + 1 }));
      switch (event?.type) {
        case "message":
          mergeMessages([event.message]);
          break;
        case "message:delete":
          setMessages((prev) => prev.filter((m) => m.id !== event.id));
          break;
        case "read": {
          const ids = new Set<number>(event.ids ?? []);
          setMessages((prev) =>
            prev.map((m) => (ids.has(m.id) && m.status !== "read" ? { ...m, status: "read" } : m)),
          );
          break;
        }
        case "call":
          setCalls((prev) => {
            const map = new Map(prev.map((c) => [c.id, c]));
            map.set(event.call.id, event.call);
            return [...map.values()].sort((a, b) => b.startedAt.localeCompare(a.startedAt));
          });
          break;
        case "sticker":
          setStickers((prev) =>
            prev.some((x) => x.id === event.sticker.id) ? prev : [...prev, event.sticker],
          );
          break;
        case "sticker:delete":
          setStickers((prev) => prev.filter((x) => x.id !== event.id));
          break;
        case "purge": {
          const gone = new Set<number>(event.ids ?? []);
          setMessages((prev) => prev.filter((m) => !gone.has(m.id)));
          forcePoll.current = true; // refresh counters on the next tick
          break;
        }
        default:
          break;
      }
    };

    es.addEventListener("vault", onVault as EventListener);
    es.addEventListener("ping", beat as EventListener);
    es.addEventListener("hello", beat as EventListener);
    es.onopen = beat;
    es.onerror = () => {
      streamOk.current = false;
      setStream((s) => ({ ...s, state: es.readyState === EventSource.CLOSED ? "error" : "connecting" }));
    };

    return () => {
      es.removeEventListener("vault", onVault as EventListener);
      es.removeEventListener("ping", beat as EventListener);
      es.removeEventListener("hello", beat as EventListener);
      es.close();
      streamOk.current = false;
    };
  }, [ready, mergeMessages]);

  /* ── local 48h expiry sweep (keeps a stale tab honest) ── */
  useEffect(() => {
    const sweep = () => {
      const now = Date.now();
      setMessages((prev) => {
        const next = prev.filter((m) => new Date(m.expiresAt).getTime() > now);
        return next.length === prev.length ? prev : next;
      });
    };
    const t = window.setInterval(sweep, 20_000);
    return () => window.clearInterval(t);
  }, []);

  /* ── simulated inbound ring so the incoming-call UI is reachable ── */
  useEffect(() => {
    if (!ready) return;
    const t = window.setInterval(() => {
      if (!demoRef.current || callRef.current || document.hidden) return;
      if (Date.now() - lastIncoming.current < 150_000) return;
      if (Math.random() > 0.3) return;
      lastIncoming.current = Date.now();
      const pool = threads.filter((c) => c.members.includes(me.id));
      const conv = pool[Math.floor(Math.random() * pool.length)];
      if (!conv) return;
      (async () => {
        try {
          const res = await Vault.call(conv.id, Math.random() < 0.5 ? "video" : "audio");
          setActiveCall({
            id: res.call.id,
            conversationId: conv.id,
            partnerIds: [res.call.callerId],
            kind: res.call.kind,
            direction: "incoming",
            phase: "ringing",
            connectedAt: null,
          });
          haptic([120, 90, 120, 90, 120]);
        } catch {
          /* simulator off */
        }
      })();
    }, 18_000);
    return () => window.clearInterval(t);
  }, [ready, threads, me.id]);

  const userById = useCallback((id: number) => users.find((u) => u.id === id), [users]);

  const messagesIn = useCallback(
    (conversationId: number) => messages.filter((m) => m.conversationId === conversationId),
    [messages],
  );

  const othersIn = useCallback(
    (conv: ConversationWire) =>
      conv.members.filter((id) => id !== me.id).map((id) => users.find((u) => u.id === id)).filter(
        (u): u is UserWire => !!u,
      ),
    [users, me.id],
  );

  const titleFor = useCallback(
    (conv: ConversationWire) =>
      conv.kind === "group"
        ? conv.title ?? GROUP_TITLE
        : (othersIn(conv)[0]?.name ?? "Unknown"),
    [othersIn],
  );

  const unreadIn = useCallback(
    (conversationId: number) =>
      messages.filter(
        (m) => m.conversationId === conversationId && m.senderId !== me.id && m.status !== "read",
      ).length,
    [messages, me.id],
  );

  const triggerReply = useCallback(
    (conversationId: number) => {
      if (!demoRef.current) return;
      window.setTimeout(() => {
        setTypingIn((t) => (t.includes(conversationId) ? t : [...t, conversationId]));
      }, 650);
      const delay = 1900 + Math.random() * 2100;
      window.setTimeout(async () => {
        try {
          const res = await Vault.simulateReply(conversationId);
          mergeMessages([res.message]);
          haptic(14);
        } catch {
          /* simulator off */
        } finally {
          setTypingIn((t) => t.filter((c) => c !== conversationId));
        }
      }, delay);
    },
    [mergeMessages],
  );

  const send = useCallback<Ctx["send"]>(
    async (payload) => {
      const tempId = -Date.now();
      const optimistic: MessageWire = {
        id: tempId,
        conversationId: payload.conversationId,
        senderId: me.id,
        kind: payload.kind,
        body: payload.body ?? "",
        mediaData: payload.mediaData ?? null,
        mediaMime: payload.mediaMime ?? null,
        mediaName: payload.mediaName ?? null,
        stickerId: payload.stickerId ?? null,
        replyToId: payload.replyToId ?? null,
        status: "sent",
        simulated: false,
        createdAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + purgeHours * 3_600_000).toISOString(),
      };
      setMessages((prev) => [...prev, optimistic]);
      haptic(10);
      try {
        const res = await Vault.send(payload);
        setMessages((prev) => prev.map((m) => (m.id === tempId ? res.message : m)));
        cursors.current.msg = Math.max(cursors.current.msg, res.message.id);
        triggerReply(payload.conversationId);
      } catch (e) {
        setMessages((prev) => prev.filter((m) => m.id !== tempId));
        notify(e instanceof Error ? e.message : "Send failed", "bad");
      }
    },
    [me.id, notify, purgeHours, triggerReply],
  );

  const deleteMessage = useCallback(
    async (id: number) => {
      setMessages((prev) => prev.filter((m) => m.id !== id));
      try {
        await Vault.remove(id);
        notify("Deleted for everyone", "ok");
      } catch (e) {
        notify(e instanceof Error ? e.message : "Delete failed", "bad");
      }
    },
    [notify],
  );

  const placeCall = useCallback<Ctx["placeCall"]>(
    async (conversationId, kind) => {
      try {
        const res = await Vault.call(conversationId, kind);
        setActiveCall({
          id: res.call.id,
          conversationId,
          partnerIds: res.partnerIds,
          kind,
          direction: "outgoing",
          phase: "ringing",
          connectedAt: null,
        });
        haptic(18);
      } catch (e) {
        notify(e instanceof Error ? e.message : "Could not place call", "bad");
      }
    },
    [notify],
  );

  const answerCall = useCallback(() => {
    setActiveCall((c) => (c ? { ...c, phase: "connected", connectedAt: Date.now() } : c));
    haptic(24);
  }, []);

  const finishCall = useCallback(
    async (status: "completed" | "missed" | "declined", seconds: number) => {
      const call = callRef.current;
      setActiveCall(null);
      if (!call || !call.id) return;
      try {
        const res = await Vault.endCall(call.id, status, seconds);
        setCalls((prev) => {
          const map = new Map(prev.map((c) => [c.id, c]));
          map.set(res.call.id, res.call);
          return [...map.values()].sort((a, b) => b.startedAt.localeCompare(a.startedAt));
        });
      } catch {
        /* ignore */
      }
    },
    [],
  );

  const declineCall = useCallback(async () => {
    const call = callRef.current;
    haptic(30);
    await finishCall(call?.direction === "incoming" ? "declined" : "missed", 0);
  }, [finishCall]);

  const endCall = useCallback<Ctx["endCall"]>(
    async (status) => {
      const call = callRef.current;
      const seconds = call?.connectedAt ? Math.round((Date.now() - call.connectedAt) / 1000) : 0;
      await finishCall(status, seconds);
    },
    [finishCall],
  );

  const addSticker = useCallback<Ctx["addSticker"]>(
    async (payload) => {
      try {
        const res = await Vault.addSticker(payload);
        setStickers((prev) => [...prev, res.sticker]);
        notify(`“${res.sticker.label}” added to ${res.sticker.pack}`, "ok");
      } catch (e) {
        notify(e instanceof Error ? e.message : "Could not add sticker", "bad");
      }
    },
    [notify],
  );

  const removeSticker = useCallback<Ctx["removeSticker"]>(
    async (id) => {
      setStickers((prev) => prev.filter((s) => s.id !== id));
      try {
        await Vault.removeSticker(id);
      } catch (e) {
        notify(e instanceof Error ? e.message : "Could not remove sticker", "bad");
      }
    },
    [notify],
  );

  const purgeNow = useCallback(async () => {
    try {
      const res = await Vault.purge();
      setMessages((prev) => prev.filter((m) => !res.ids.includes(m.id)));
      setAlive(res.alive);
      setBurned(res.burned);
      notify(res.purged ? `${res.purged} expired message${res.purged === 1 ? "" : "s"} burned` : "Nothing to burn — vault is clean", "ok");
      return res.purged;
    } catch (e) {
      notify(e instanceof Error ? e.message : "Purge failed", "bad");
      return 0;
    }
  }, [notify]);

  const setDemoReplies = useCallback(
    async (on: boolean) => {
      setDemoState(on);
      try {
        await Vault.purge(on);
      } catch {
        /* ignore */
      }
    },
    [],
  );

  const relock = useCallback(async () => {
    window.location.reload();
  }, []);

  const signOut = useCallback(async () => {
    try {
      await Vault.purge();
    } catch {
      /* ignore */
    }
    const { Auth } = await import("@/lib/client");
    await Auth.logout().catch(() => undefined);
    window.location.reload();
  }, []);

  const value = useMemo<Ctx>(
    () => ({
      me,
      users,
      userById,
      threads,
      messages,
      messagesIn,
      calls,
      stickers,
      purges,
      alive,
      burned,
      purgeHours,
      ready,
      error,
      openId,
      setOpenId,
      typingIn,
      stream,
      activeCall,
      demoReplies,
      toasts,
      notify,
      dismissToast,
      titleFor,
      othersIn,
      unreadIn,
      send,
      deleteMessage,
      placeCall,
      answerCall,
      declineCall,
      endCall,
      addSticker,
      removeSticker,
      purgeNow,
      setDemoReplies,
      relock,
      signOut,
    }),
    [
      me, users, userById, threads, messages, messagesIn, calls, stickers, purges, alive, burned,
      purgeHours, ready, error, openId, typingIn, stream, activeCall, demoReplies, toasts, notify,
      dismissToast, titleFor, othersIn, unreadIn, send, deleteMessage, placeCall, answerCall,
      declineCall, endCall, addSticker, removeSticker, purgeNow, setDemoReplies, relock, signOut,
    ],
  );

  return <VaultCtx.Provider value={value}>{children}</VaultCtx.Provider>;
}
