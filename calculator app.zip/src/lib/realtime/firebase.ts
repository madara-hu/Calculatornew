import { createSign } from "node:crypto";
import type { VaultEvent } from "./bus";

/**
 * FIREBASE (Firestore) MIRROR — zero dependencies.
 * Talks to the Firestore REST API with a service-account JWT signed locally via
 * node:crypto, so nothing extra has to be installed on Termux / Codespace / EAS.
 *
 * Activate by setting these three env vars (nothing happens until you do):
 *   FIREBASE_PROJECT_ID     your-project-id
 *   FIREBASE_CLIENT_EMAIL   firebase-adminsdk-xxxx@your-project-id.iam.gserviceaccount.com
 *   FIREBASE_PRIVATE_KEY    "-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n"
 *
 * Collection layout (mirrors src/db/schema.ts):
 *   threads/{conversationId}/messages/{messageId}
 *   threads/{conversationId}/calls/{callId}
 *   meta/purge/last
 * Every document carries `expiresAt` so a scheduled Cloud Function (or the
 * Firestore TTL policy) can burn 48h-old data without touching this server.
 */

const TIMEOUT = 8_000;

export const firebaseState = {
  configured: false,
  projectId: "",
  clientEmailMasked: "",
  ok: false,
  mirrored: 0,
  failed: 0,
  lastError: null as string | null,
  lastMirroredAt: 0,
};

let tokenCache: { value: string; expiresAt: number } | null = null;

function config() {
  const projectId = (process.env.FIREBASE_PROJECT_ID ?? "").trim();
  const clientEmail = (process.env.FIREBASE_CLIENT_EMAIL ?? "").trim();
  const privateKey = (process.env.FIREBASE_PRIVATE_KEY ?? "").replace(/\\n/g, "\n").trim();
  if (!projectId || !clientEmail || !privateKey) return null;
  firebaseState.configured = true;
  firebaseState.projectId = projectId;
  firebaseState.clientEmailMasked = clientEmail.replace(/^(.{6}).*(@.*)$/, "$1…$2");
  return { projectId, clientEmail, privateKey };
}

async function accessToken(cfg: NonNullable<ReturnType<typeof config>>) {
  if (tokenCache && tokenCache.expiresAt > Date.now() + 60_000) return tokenCache.value;

  const now = Math.floor(Date.now() / 1000);
  const b64 = (input: string) => Buffer.from(input).toString("base64url");
  const header = b64(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claim = b64(
    JSON.stringify({
      iss: cfg.clientEmail,
      scope: "https://www.googleapis.com/auth/datastore",
      aud: "https://oauth2.googleapis.com/token",
      iat: now,
      exp: now + 3_600,
    }),
  );
  const signature = createSign("RSA-SHA256")
    .update(`${header}.${claim}`)
    .sign(cfg.privateKey)
    .toString("base64url");

  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: `${header}.${claim}.${signature}`,
    }),
    signal: AbortSignal.timeout(TIMEOUT),
  });
  if (!res.ok) throw new Error(`token request failed (${res.status})`);
  const data = (await res.json()) as { access_token?: string; expires_in?: number };
  if (!data.access_token) throw new Error("token response missing access_token");
  tokenCache = {
    value: data.access_token,
    expiresAt: Date.now() + (data.expires_in ?? 3_600) * 1_000,
  };
  return tokenCache.value;
}

const str = (v: string) => ({ stringValue: String(v) });
const int = (v: number) => ({ integerValue: String(Math.trunc(v)) });
const bool = (v: boolean) => ({ booleanValue: v });
const stamp = (v: string | Date) => ({ timestampValue: new Date(v).toISOString() });

async function commit(cfg: NonNullable<ReturnType<typeof config>>, writes: unknown[]) {
  const token = await accessToken(cfg);
  const res = await fetch(
    `https://firestore.googleapis.com/v1/projects/${cfg.projectId}/databases/(default)/documents:commit`,
    {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${token}` },
      body: JSON.stringify({ writes }),
      signal: AbortSignal.timeout(TIMEOUT),
    },
  );
  if (!res.ok) throw new Error(`firestore commit failed (${res.status})`);
}

const docPath = (cfg: { projectId: string }, path: string) =>
  `projects/${cfg.projectId}/databases/(default)/documents/${path}`;

/** Fire-and-forget mirror. Never throws into the request path. */
export async function mirror(event: VaultEvent) {
  const cfg = config();
  if (!cfg) return;
  try {
    if (event.type === "message") {
      const m = event.message;
      await commit(cfg, [
        {
          update: {
            name: docPath(cfg, `threads/${m.conversationId}/messages/${m.id}`),
            fields: {
              senderId: int(m.senderId),
              kind: str(m.kind),
              body: str(m.body),
              mediaData: str(m.mediaData ?? ""),
              mediaMime: str(m.mediaMime ?? ""),
              mediaName: str(m.mediaName ?? ""),
              stickerId: str(m.stickerId ?? ""),
              replyToId: int(m.replyToId ?? 0),
              status: str(m.status),
              simulated: bool(m.simulated),
              createdAt: stamp(m.createdAt),
              expiresAt: stamp(m.expiresAt),
            },
          },
        },
        {
          update: {
            name: docPath(cfg, `threads/${m.conversationId}/meta`),
            fields: { lastMessageAt: stamp(m.createdAt), lastSenderId: int(m.senderId) },
          },
        },
      ]);
    } else if (event.type === "message:delete") {
      await commit(cfg, [
        { delete: docPath(cfg, `threads/${event.conversationId}/messages/${event.id}`) },
      ]);
    } else if (event.type === "call") {
      const c = event.call;
      await commit(cfg, [
        {
          update: {
            name: docPath(cfg, `threads/${c.conversationId}/calls/${c.id}`),
            fields: {
              callerId: int(c.callerId),
              kind: str(c.kind),
              status: str(c.status),
              durationSeconds: int(c.durationSeconds),
              startedAt: stamp(c.startedAt),
            },
          },
        },
      ]);
    } else if (event.type === "purge") {
      await commit(cfg, [
        {
          update: {
            name: docPath(cfg, "meta/purge/last"),
            fields: { purged: int(event.purged), at: stamp(new Date()) },
          },
        },
      ]);
    } else {
      return; // read receipts / stickers stay on Postgres + SSE
    }
    firebaseState.ok = true;
    firebaseState.mirrored += 1;
    firebaseState.lastError = null;
    firebaseState.lastMirroredAt = Date.now();
  } catch (error) {
    firebaseState.ok = false;
    firebaseState.failed += 1;
    firebaseState.lastError = error instanceof Error ? error.message : "unknown error";
  }
}
