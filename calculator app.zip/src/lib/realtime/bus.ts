import type { CallWire, MessageWire, StickerWire } from "@/lib/types";

/**
 * Realtime event contract shared by:
 *   • the in-process SSE bus (zero-config, works out of the box)
 *   • the Cloudflare edge relay (optional)
 *   • the Firestore mirror used by the React Native port (optional)
 */
export type VaultEvent =
  | { type: "message"; conversationId: number; message: MessageWire }
  | { type: "message:delete"; conversationId: number; id: number }
  | { type: "read"; conversationId: number; ids: number[] }
  | { type: "call"; conversationId: number; call: CallWire }
  | { type: "sticker"; sticker: StickerWire }
  | { type: "sticker:delete"; id: number }
  | { type: "purge"; ids: number[]; purged: number }
  | { type: "ping"; at: string };

export type Envelope = { event: VaultEvent; audience: number[] | null; at: number; seq: number };

type Listener = (envelope: Envelope) => void;

const listeners = new Set<Listener>();

export const stats = {
  published: 0,
  delivered: 0,
  lastPublishedAt: 0,
  lastType: "",
};

let seq = 0;

export function subscribe(listener: Listener) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function subscriberCount() {
  return listeners.size;
}

/** Fan an event out to every open SSE connection whose user is in the audience. */
export function publish(event: VaultEvent, audience: number[] | null = null) {
  const envelope: Envelope = { event, audience, at: Date.now(), seq: ++seq };
  stats.published += 1;
  stats.lastPublishedAt = envelope.at;
  stats.lastType = event.type;
  for (const listener of listeners) {
    try {
      listener(envelope);
      stats.delivered += 1;
    } catch {
      listeners.delete(listener);
    }
  }
}
