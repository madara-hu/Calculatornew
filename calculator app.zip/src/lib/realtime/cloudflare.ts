import type { VaultEvent } from "./bus";

/**
 * CLOUDFLARE EDGE RELAY — plain HTTPS, zero dependencies.
 * Every vault event is forwarded to a Worker (Durable Object) that fans it out
 * to every connected device on the edge. This is what makes realtime work when
 * the app runs on more than one instance, or when the React Native build talks
 * straight to the edge instead of to Next.js.
 *
 * Activate with:
 *   CLOUDFLARE_RELAY_URL=https://vault.<your-subdomain>.workers.dev/internal/publish
 *   CLOUDFLARE_RELAY_TOKEN=<long random string>           (server → worker, secret)
 *   NEXT_PUBLIC_CLOUDFLARE_STREAM_URL=https://vault.<your-subdomain>.workers.dev/stream
 *                                                          (browser → worker, optional)
 *
 * Worker source + wrangler.toml: handover/cloudflare/
 * Until the env vars exist this module is a silent no-op.
 */

const TIMEOUT = 5_000;

export const cloudflareState = {
  configured: false,
  host: "",
  streamUrl: "",
  ok: false,
  published: 0,
  failed: 0,
  lastError: null as string | null,
  lastPublishedAt: 0,
};

function config() {
  const url = (process.env.CLOUDFLARE_RELAY_URL ?? "").trim();
  const token = (process.env.CLOUDFLARE_RELAY_TOKEN ?? "").trim();
  cloudflareState.streamUrl = (process.env.NEXT_PUBLIC_CLOUDFLARE_STREAM_URL ?? "").trim();
  if (!url || !token) return null;
  cloudflareState.configured = true;
  try {
    cloudflareState.host = new URL(url).host;
  } catch {
    cloudflareState.host = url.slice(0, 42);
  }
  return { url, token };
}

/** Fire-and-forget publish to the edge. Never throws into the request path. */
export async function relay(event: VaultEvent, audience: number[] | null) {
  const cfg = config();
  if (!cfg) return;
  try {
    const res = await fetch(cfg.url, {
      method: "POST",
      headers: { "content-type": "application/json", "x-relay-token": cfg.token },
      body: JSON.stringify({ event, audience, at: Date.now() }),
      signal: AbortSignal.timeout(TIMEOUT),
    });
    if (!res.ok) throw new Error(`relay responded ${res.status}`);
    cloudflareState.ok = true;
    cloudflareState.published += 1;
    cloudflareState.failed = Math.max(0, cloudflareState.failed);
    cloudflareState.lastError = null;
    cloudflareState.lastPublishedAt = Date.now();
  } catch (error) {
    cloudflareState.ok = false;
    cloudflareState.failed += 1;
    cloudflareState.lastError = error instanceof Error ? error.message : "unknown error";
  }
}

/** Explicit connectivity probe used by the Settings → Realtime panel. */
export async function probe() {
  const cfg = config();
  if (!cfg) return { configured: false as const, ok: false, detail: "CLOUDFLARE_RELAY_URL / TOKEN not set" };
  const started = Date.now();
  try {
    const res = await fetch(cfg.url.replace(/\/internal\/publish\/?$/, "/healthz"), {
      headers: { "x-relay-token": cfg.token },
      signal: AbortSignal.timeout(TIMEOUT),
    });
    return {
      configured: true as const,
      ok: res.ok,
      detail: `${res.status} in ${Date.now() - started}ms · ${cloudflareState.host}`,
    };
  } catch (error) {
    return {
      configured: true as const,
      ok: false,
      detail: error instanceof Error ? error.message : "unreachable",
    };
  }
}
