import { PURGE_HOURS } from "@/lib/config";
import { publish, stats, subscriberCount, type VaultEvent } from "./bus";
import { cloudflareState, probe, relay } from "./cloudflare";
import { firebaseState, mirror } from "./firebase";

/**
 * ONE entry point for every realtime side-effect.
 *   1. in-process SSE bus   — always on, zero config
 *   2. Cloudflare edge relay — only if CLOUDFLARE_RELAY_* exist
 *   3. Firestore mirror      — only if FIREBASE_* exist
 * Both external hops are fire-and-forget, so a missing key, a dead network or a
 * bad token can never slow down or break a send.
 */
export function broadcast(event: VaultEvent, audience: number[] | null = null) {
  publish(event, audience);
  void relay(event, audience);
  void mirror(event);
}

export const POLL_INTERVAL_MS = 2_400;
export const POLL_INTERVAL_LIVE_MS = 9_000;

export function transport() {
  if (cloudflareState.configured) return "cloudflare-edge + postgres-sse";
  if (firebaseState.configured) return "postgres-sse + firestore-mirror";
  return "postgres-sse";
}

export async function realtimeStatus() {
  const cloudflareProbe = await probe();
  return {
    transport: transport(),
    purgeHours: PURGE_HOURS,
    sse: {
      endpoint: "/api/stream",
      subscribers: subscriberCount(),
      published: stats.published,
      delivered: stats.delivered,
      lastEventAt: stats.lastPublishedAt || null,
      lastType: stats.lastType || null,
    },
    cloudflare: {
      configured: cloudflareState.configured,
      host: cloudflareState.host || null,
      streamUrl: cloudflareState.streamUrl || null,
      ok: cloudflareProbe.ok,
      probe: cloudflareProbe.detail,
      published: cloudflareState.published,
      failed: cloudflareState.failed,
      lastError: cloudflareState.lastError,
    },
    firebase: {
      configured: firebaseState.configured,
      projectId: firebaseState.projectId || null,
      serviceAccount: firebaseState.clientEmailMasked || null,
      ok: firebaseState.ok,
      mirrored: firebaseState.mirrored,
      failed: firebaseState.failed,
      lastError: firebaseState.lastError,
      lastMirroredAt: firebaseState.lastMirroredAt || null,
    },
    clientStreamUrl:
      process.env.NEXT_PUBLIC_CLOUDFLARE_STREAM_URL?.trim() || "/api/stream",
  };
}

export type RealtimeStatus = Awaited<ReturnType<typeof realtimeStatus>>;
