/**
 * ─────────────────────────────────────────────────────────────
 *  HUSTLER CALCULATOR — SINGLE SOURCE OF TRUTH FOR CONFIG
 * ─────────────────────────────────────────────────────────────
 *  Everything a developer needs to change lives here.
 *  See SETUP_GUIDE.md §3 "Exact code insertion points".
 *
 *  SECURITY: passwords below are *seed material only*. They are never stored
 *  as plaintext — each account gets a random per-user salt and only
 *  sha256(salt + handle + password + AUTH_SECRET) is written to Postgres.
 */

/** The cover app name. Never shows personal branding. */
export const APP_NAME = "Hustler Calculator";

/**
 * THE STEALTH KEY.
 * Typing exactly this expression on the cover calculator and pressing "="
 * unlocks the inner layer. Change it to any `a+b` style expression.
 */
export const SECRET_SEQUENCE = "74+88";
export const SECRET_ANSWER = 162;

/** Auto-purge window. Messages older than this are physically deleted. */
export const PURGE_HOURS = 48;

/** How long a login session lasts (days). */
export const SESSION_DAYS = 30;

/**
 * STRICT, HARDCODED USER POOL — EXACTLY FOUR.
 * No sign-ups. No OAuth. No Gmail. Only these accounts exist.
 * Every handle has its own unique password.
 * To rotate a seat, edit the row below and bump SEED_VERSION so the vault
 * reseeds (all threads, messages, stickers and sessions are rebuilt).
 */
export type SeedUser = {
  handle: string;
  name: string;
  password: string;
  hue: number;
  tagline: string;
  role: string;
  status: string;
};

export const SEED_VERSION = 5;

export const USERS: SeedUser[] = [
  {
    handle: "pov_navneet",
    name: "Navneet",
    password: "Navneet@7488",
    hue: 168,
    tagline: "Numbers don't lie. People do.",
    role: "Operator",
    status: "Available · encrypted",
  },
  {
    handle: "pov_shreya",
    name: "Shreya",
    password: "Shreya@1234",
    hue: 34,
    tagline: "Ghost mode: ON",
    role: "Handler",
    status: "At the warehouse",
  },
  {
    handle: "pov_navya",
    name: "Navya",
    password: "Navya@5678",
    hue: 196,
    tagline: "If it's not written down, it didn't happen.",
    role: "Logistics",
    status: "Busy · will reply",
  },
  {
    // ← THE 4TH DESIGNATED USER HANDLE (configuration slot)
    handle: "w.o.n.s",
    name: "W.O.N.S",
    password: "Wons@9999",
    hue: 286,
    tagline: "Quiet. Fast. Gone.",
    role: "Runner",
    status: "On a delivery",
  },
];

/** The all-four private group thread. */
export const GROUP_KEY = "core-four";
export const GROUP_TITLE = "Hustlers · Inner Circle";
export const GROUP_SUBJECT = "4 members · end-to-end simulated";

/**
 * Demo aid: when true the login screen can reveal the seeded credentials.
 * Turn this off (`EXPOSE_DEMO_CREDENTIALS=false` in .env) for a real rollout —
 * the passwords then exist only as salted hashes inside Postgres.
 */
export const EXPOSE_DEMO_CREDENTIALS =
  (process.env.EXPOSE_DEMO_CREDENTIALS ?? "true") !== "false";

/** Built-in sticker packs rendered as inline SVG (no network needed). */
export const STICKER_PACKS = [
  { id: "hustle", name: "Hustle", blurb: "House pack" },
  { id: "glyph", name: "Neon Glyphs", blurb: "Imported" },
  { id: "moods", name: "Moods", blurb: "Imported" },
] as const;

/** Canned replies used by the offline companion simulator. */
export const DEMO_REPLIES = [
  "Copy that. 📦",
  "Send me the pin drop, I'm leaving in 10.",
  "Done. Cash or UPI?",
  "Careful — that number doesn't add up.",
  "I'm on it. Don't call me on the open line.",
  "Received. Burning this thread in 48 anyway.",
  "Nice. Screenshot it for the group.",
  "Bro, the truck is stuck at the checkpoint.",
  "74 + 88. You know the drill.",
  "Let's settle this on a call.",
];
