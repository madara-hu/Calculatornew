export const clockTime = (iso: string | Date) =>
  new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false });

export function dayLabel(iso: string | Date) {
  const d = new Date(iso);
  const today = new Date();
  const yesterday = new Date(today.getTime() - 86_400_000);
  const same = (a: Date, b: Date) => a.toDateString() === b.toDateString();
  if (same(d, today)) return "Today";
  if (same(d, yesterday)) return "Yesterday";
  if (today.getTime() - d.getTime() < 6 * 86_400_000)
    return d.toLocaleDateString([], { weekday: "long" });
  return d.toLocaleDateString([], { day: "2-digit", month: "short", year: "numeric" });
}

export function relativeTime(iso: string | Date) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.round(diff / 60_000);
  if (mins < 1) return "now";
  if (mins < 60) return `${mins}m`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h`;
  return `${Math.round(hours / 24)}d`;
}

/** "47h 12m" of life left before the auto-purge burns a message. */
export function ttlLabel(expiresAt: string | Date) {
  const ms = new Date(expiresAt).getTime() - Date.now();
  if (ms <= 0) return "burned";
  const hours = Math.floor(ms / 3_600_000);
  const mins = Math.floor((ms % 3_600_000) / 60_000);
  return `${hours}h ${String(mins).padStart(2, "0")}m`;
}

export function durationLabel(seconds: number) {
  const s = Math.max(0, Math.floor(seconds));
  const m = Math.floor(s / 60);
  return `${m}:${String(s % 60).padStart(2, "0")}`;
}

export function compactNumber(n: number) {
  return new Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 1 }).format(n);
}

export type ResizedImage = {
  dataUri: string;
  mime: string;
  name: string;
  bytes: number;
  width: number;
  height: number;
};

/**
 * Client-side compression so media payloads stay tiny for Postgres text columns
 * (and for any mobile port on a slow connection).
 */
export async function resizeImage(
  file: File | Blob,
  maxEdge = 1280,
  quality = 0.72,
): Promise<ResizedImage> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Could not read that file"));
    reader.readAsDataURL(file);
  });

  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const el = new Image();
    el.onload = () => resolve(el);
    el.onerror = () => reject(new Error("Unsupported image format"));
    el.src = dataUrl;
  });

  const scale = Math.min(1, maxEdge / Math.max(img.width, img.height));
  const width = Math.max(1, Math.round(img.width * scale));
  const height = Math.max(1, Math.round(img.height * scale));

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas unavailable");
  ctx.drawImage(img, 0, 0, width, height);

  const mime = "image/jpeg";
  const out = canvas.toDataURL(mime, quality);
  return {
    dataUri: out,
    mime,
    name: (file instanceof File ? file.name : "photo.jpg").replace(/\.[^.]+$/, "") + ".jpg",
    bytes: Math.round((out.length - `data:${mime};base64,`.length) * 0.75),
    width,
    height,
  };
}

export async function fileToDataUri(file: File | Blob, maxBytes = 1_400_000) {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Could not read that file"));
    reader.readAsDataURL(file);
  });
  if (dataUrl.length > maxBytes * 1.4) {
    const resized = await resizeImage(file, 512, 0.6);
    return resized.dataUri;
  }
  return dataUrl;
}
