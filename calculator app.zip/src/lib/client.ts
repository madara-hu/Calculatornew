import type {
  Bootstrap,
  CallWire,
  MessageWire,
  RosterUser,
  StickerWire,
  SyncPayload,
  UserWire,
} from "@/lib/types";

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    credentials: "same-origin",
    cache: "no-store",
    ...init,
    headers: { "content-type": "application/json", ...(init?.headers ?? {}) },
  });
  const data = (await res.json().catch(() => ({}))) as T & { error?: string };
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

export const Auth = {
  me: () => request<{ me: UserWire | null; roster: RosterUser[] }>("/api/auth"),
  login: (handle: string, password: string) =>
    request<{ me: UserWire }>("/api/auth", {
      method: "POST",
      body: JSON.stringify({ handle, password }),
    }),
  logout: () => request<{ ok: boolean }>("/api/auth", { method: "DELETE" }),
};

export const Vault = {
  bootstrap: () => request<Bootstrap>("/api/bootstrap"),
  sync: (params: { after: number; ac: number; as: number; open?: number }) => {
    const q = new URLSearchParams({
      after: String(params.after),
      ac: String(params.ac),
      as: String(params.as),
    });
    if (params.open) q.set("open", String(params.open));
    return request<SyncPayload>(`/api/sync?${q.toString()}`);
  },
  send: (payload: {
    conversationId: number;
    kind: MessageWire["kind"];
    body?: string;
    mediaData?: string | null;
    mediaMime?: string | null;
    mediaName?: string | null;
    stickerId?: string | null;
    replyToId?: number | null;
  }) =>
    request<{ message: MessageWire }>("/api/messages", {
      method: "POST",
      body: JSON.stringify(payload),
    }),
  simulateReply: (conversationId: number, replyToId?: number) =>
    request<{ message: MessageWire }>("/api/messages/simulate", {
      method: "POST",
      body: JSON.stringify({ conversationId, replyToId }),
    }),
  remove: (id: number) => request<{ ok: boolean }>(`/api/messages/${id}`, { method: "DELETE" }),
  call: (conversationId: number, kind: "audio" | "video") =>
    request<{ call: CallWire; partnerIds: number[] }>("/api/calls", {
      method: "POST",
      body: JSON.stringify({ conversationId, kind }),
    }),
  endCall: (id: number, status: "completed" | "missed" | "declined", durationSeconds: number) =>
    request<{ call: CallWire }>("/api/calls", {
      method: "PATCH",
      body: JSON.stringify({ id, status, durationSeconds }),
    }),
  addSticker: (payload: { label: string; data: string; pack?: string }) =>
    request<{ sticker: StickerWire }>("/api/stickers", {
      method: "POST",
      body: JSON.stringify(payload),
    }),
  removeSticker: (id: number) =>
    request<{ ok: boolean }>("/api/stickers", {
      method: "DELETE",
      body: JSON.stringify({ id }),
    }),
  settings: () =>
    request<{ demoReplies: boolean; purgeHours: number; alive: number; burned: number }>(
      "/api/purge",
    ),
  purge: (demoReplies?: boolean) =>
    request<{ purged: number; ids: number[]; alive: number; burned: number }>("/api/purge", {
      method: "POST",
      body: JSON.stringify({ purge: true, demoReplies }),
    }),
};

/** Tactile feedback where the platform allows it. */
export function haptic(pattern: number | number[] = 12) {
  if (typeof navigator !== "undefined" && "vibrate" in navigator) {
    try {
      navigator.vibrate(pattern);
    } catch {
      /* ignored */
    }
  }
}
