import { eq } from "drizzle-orm";
import { db } from "@/db";
import { conversations } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { getSessionUser, listUsers } from "@/lib/auth";
import { membersOf } from "@/lib/repo";
import type { UserWire } from "@/lib/types";

export class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

export function json(data: unknown, status = 200) {
  return Response.json(data, {
    status,
    headers: { "cache-control": "no-store, max-age=0" },
  });
}

export async function requireUser(): Promise<UserWire> {
  await ensureSeeded();
  const me = await getSessionUser();
  if (!me) throw new HttpError(401, "Vault locked. Sign in again.");
  return me;
}

export type Handler = (req: Request, ctx?: any) => Promise<Response>;

export function route(fn: Handler): Handler {
  return async (req, ctx) => {
    try {
      return await fn(req, ctx);
    } catch (error) {
      if (error instanceof HttpError) return json({ error: error.message }, error.status);
      console.error("[hustler] route error", error);
      return json({ error: "Server error" }, 500);
    }
  };
}

export async function readBody<T>(req: Request): Promise<T> {
  try {
    return (await req.json()) as T;
  } catch {
    throw new HttpError(400, "Malformed JSON body");
  }
}

export async function threadsFor(me: UserWire) {
  await ensureSeeded();
  const all = await listUsers();
  const rows = await db.select().from(conversations);
  return rows
    .filter((row) => membersOf(row, all).includes(me.id))
    .map((row) => ({ row, members: membersOf(row, all), all }));
}

/** Loads one thread and asserts the caller is one of the four members. */
export async function threadFor(me: UserWire, conversationId: number) {
  await ensureSeeded();
  const all = await listUsers();
  const rows = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, conversationId))
    .limit(1);
  const conv = rows[0];
  if (!conv) throw new HttpError(404, "Thread not found");
  const members = membersOf(conv, all);
  if (!members.includes(me.id)) throw new HttpError(403, "Not a member of this thread");
  return { conv, members, all };
}


