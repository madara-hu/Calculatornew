export type UserWire = {
  id: number;
  handle: string;
  name: string;
  hue: number;
  tagline: string;
  role: string;
  status: string;
};

/** Public face of the four fixed seats (no hashes, no salts). */
export type RosterUser = {
  handle: string;
  name: string;
  hue: number;
  role: string;
  tagline: string;
  demoPassword?: string;
};

export type ConversationWire = {
  id: number;
  kind: "dm" | "group";
  key: string;
  title: string | null;
  subject: string | null;
  members: number[];
  lastMessageAt: string;
};

export type MessageKind = "text" | "image" | "sticker" | "voice" | "system";

export type MessageWire = {
  id: number;
  conversationId: number;
  senderId: number;
  kind: MessageKind;
  body: string;
  mediaData: string | null;
  mediaMime: string | null;
  mediaName: string | null;
  stickerId: string | null;
  replyToId: number | null;
  status: "sent" | "delivered" | "read";
  simulated: boolean;
  createdAt: string;
  expiresAt: string;
};

export type CallWire = {
  id: number;
  conversationId: number;
  callerId: number;
  kind: "audio" | "video";
  status: "ringing" | "completed" | "missed" | "declined";
  durationSeconds: number;
  startedAt: string;
};

export type StickerWire = {
  id: number;
  ownerId: number | null;
  pack: string;
  label: string;
  source: "builtin" | "url" | "upload";
  data: string;
  createdAt: string;
};

export type PurgeWire = {
  id: number;
  purged: number;
  trigger: string;
  ranAt: string;
};

export type Bootstrap = {
  me: UserWire;
  users: UserWire[];
  conversations: ConversationWire[];
  messages: MessageWire[];
  calls: CallWire[];
  stickers: StickerWire[];
  purges: PurgeWire[];
  serverTime: string;
  purgeHours: number;
  alive: number;
  burned: number;
};

export type SyncPayload = {
  messages: MessageWire[];
  calls: CallWire[];
  stickers: StickerWire[];
  purges: PurgeWire[];
  deletedMessageIds: number[];
  serverTime: string;
  purgeHours: number;
  alive: number;
  burned: number;
  readIds: { conversationId: number; ids: number[] }[];
};

export type CallSession = {
  conversationId: number;
  partnerIds: number[];
  kind: "audio" | "video";
  direction: "outgoing" | "incoming";
};
