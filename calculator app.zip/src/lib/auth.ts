import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { SESSION_DAYS } from "@/lib/config";
import type { UserWire } from "@/lib/types";

export const COOKIE_NAME = "hustler_session";

const pepper = () => process.env.AUTH_SECRET || "hustler-local-pepper";

/** Fresh per-account salt. Stored alongside the hash, never derived from the handle. */
export function newSalt() {
  return randomBytes(16).toString("hex");
}

/** sha256(salt + handle + password + pepper) — plaintext never touches the DB. */
export function hashPassword(handle: string, password: string, salt: string) {
  return createHash("sha256")
    .update(`${salt}:${handle}:${password}:${pepper()}`)
    .digest("hex");
}

/** Constant-time comparison so a wrong password can't be timed out. */
export function verifyPassword(handle: string, password: string, salt: string, hash: string) {
  const candidate = Buffer.from(hashPassword(handle, password, salt), "hex");
  const stored = Buffer.from(hash, "hex");
  if (candidate.length !== stored.length) return false;
  try {
    return timingSafeEqual(candidate, stored);
  } catch {
    return false;
  }
}

export function toUserWire(row: typeof users.$inferSelect): UserWire {
  return {
    id: row.id,
    handle: row.handle,
    name: row.name,
    hue: row.hue,
    tagline: row.tagline,
    role: row.role,
    status: row.status,
  };
}

export async function createSession(userId: number) {
  const token = randomBytes(24).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86_400_000);
  await db.insert(sessions).values({ token, userId, expiresAt });
  const jar = await cookies();
  jar.set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  });
  return token;
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(COOKIE_NAME)?.value;
  if (token) await db.delete(sessions).where(eq(sessions.token, token));
  jar.delete(COOKIE_NAME);
}

export async function getSessionUser(): Promise<UserWire | null> {
  const jar = await cookies();
  const token = jar.get(COOKIE_NAME)?.value;
  if (!token) return null;
  const rows = await db
    .select({ user: users, session: sessions })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date())))
    .limit(1);
  if (!rows.length) return null;
  return toUserWire(rows[0].user);
}

export async function listUsers(): Promise<UserWire[]> {
  const rows = await db.select().from(users);
  return rows.map(toUserWire);
}
