import {
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/** The 4 hardcoded accounts. Nothing else can ever exist here. */
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    handle: text("handle").notNull(),
    name: text("name").notNull(),
    /** sha256(salt + handle + password + AUTH_SECRET) — never plaintext */
    passwordHash: text("password_hash").notNull(),
    /** random per-account salt */
    salt: text("salt").notNull(),
    hue: integer("hue").notNull().default(160),
    tagline: text("tagline").notNull().default(""),
    role: text("role").notNull().default("Member"),
    status: text("status").notNull().default("Available"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [uniqueIndex("users_handle_idx").on(t.handle)],
);

/** Cookie-backed sessions. No external identity provider. */
export const sessions = pgTable(
  "sessions",
  {
    token: text("token").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  },
  (t) => [index("sessions_user_idx").on(t.userId)],
);

/** dm = a 1:1 thread between two of the four, group = all four. */
export const conversations = pgTable(
  "conversations",
  {
    id: serial("id").primaryKey(),
    kind: text("kind").notNull().default("dm"),
    key: text("key").notNull(),
    title: text("title"),
    subject: text("subject"),
    lastMessageAt: timestamp("last_message_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [uniqueIndex("conversations_key_idx").on(t.key)],
);

export const messages = pgTable(
  "messages",
  {
    id: serial("id").primaryKey(),
    conversationId: integer("conversation_id")
      .notNull()
      .references(() => conversations.id, { onDelete: "cascade" }),
    senderId: integer("sender_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    kind: text("kind").notNull().default("text"), // text | image | sticker | voice | system
    body: text("body").notNull().default(""),
    mediaData: text("media_data"), // inline data URI (resized client-side)
    mediaMime: text("media_mime"),
    mediaName: text("media_name"),
    stickerId: text("sticker_id"),
    replyToId: integer("reply_to_id"),
    status: text("status").notNull().default("sent"), // sent | delivered | read
    simulated: integer("simulated").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  },
  (t) => [
    index("messages_conversation_idx").on(t.conversationId, t.id),
    index("messages_expires_idx").on(t.expiresAt),
  ],
);

export const callLogs = pgTable(
  "call_logs",
  {
    id: serial("id").primaryKey(),
    conversationId: integer("conversation_id")
      .notNull()
      .references(() => conversations.id, { onDelete: "cascade" }),
    callerId: integer("caller_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    kind: text("kind").notNull().default("audio"), // audio | video
    status: text("status").notNull().default("ringing"), // ringing | completed | missed | declined
    durationSeconds: integer("duration_seconds").notNull().default(0),
    startedAt: timestamp("started_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("call_logs_conversation_idx").on(t.conversationId, t.id)],
);

/** Stickers imported from an external app link or uploaded from device. */
export const stickers = pgTable(
  "stickers",
  {
    id: serial("id").primaryKey(),
    ownerId: integer("owner_id").references(() => users.id, {
      onDelete: "cascade",
    }),
    pack: text("pack").notNull().default("My Stickers"),
    label: text("label").notNull().default(""),
    source: text("source").notNull().default("upload"), // builtin | url | upload
    data: text("data").notNull(), // data URI or https URL
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("stickers_pack_idx").on(t.pack)],
);

/** Every auto-purge sweep is logged so the Settings tab can prove it ran. */
export const purgeEvents = pgTable("purge_events", {
  id: serial("id").primaryKey(),
  purged: integer("purged").notNull().default(0),
  trigger: text("trigger").notNull().default("auto"),
  ranAt: timestamp("ran_at", { withTimezone: true }).notNull().defaultNow(),
});

export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
});
