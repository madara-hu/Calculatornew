import { eq } from "drizzle-orm";
import { db } from "@/db";
import {
  callLogs,
  conversations,
  messages,
  purgeEvents,
  sessions,
  settings,
  stickers,
  users,
} from "@/db/schema";
import { GROUP_KEY, GROUP_SUBJECT, GROUP_TITLE, SEED_VERSION, USERS } from "@/lib/config";
import { hashPassword, newSalt } from "@/lib/auth";
import { dmKey, expiryFor } from "@/lib/repo";

/* ── inline SVG assets (zero network dependency) ───────────────── */

const svg = (body: string, w = 128, h = 128) =>
  `data:image/svg+xml,${encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}">${body}</svg>`,
  )}`;

const grad = (id: string, a: string, b: string) =>
  `<defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs>`;

const BUILTIN_STICKERS: { pack: string; label: string; data: string }[] = [
  {
    pack: "Hustle",
    label: "Cash bag",
    data: svg(
      `${grad("g1", "#f7c873", "#c2703d")}<path d="M64 12c14 0 22 10 22 18 0 6-4 10-8 12 20 8 34 26 34 44 0 18-20 30-48 30S16 104 16 86c0-18 14-36 34-44-4-2-8-6-8-12 0-8 8-18 22-18z" fill="url(#g1)" stroke="#2b1a10" stroke-width="4"/><text x="64" y="94" font-family="monospace" font-size="40" font-weight="700" fill="#2b1a10" text-anchor="middle">₹</text>`,
    ),
  },
  {
    pack: "Hustle",
    label: "Night truck",
    data: svg(
      `${grad("g2", "#7dd3fc", "#1d4ed8")}<rect x="8" y="46" width="70" height="40" rx="6" fill="url(#g2)" stroke="#08131f" stroke-width="4"/><path d="M78 58h20l18 18v10H78z" fill="#f8fafc" stroke="#08131f" stroke-width="4"/><circle cx="36" cy="94" r="12" fill="#0f172a" stroke="#f8fafc" stroke-width="4"/><circle cx="100" cy="94" r="12" fill="#0f172a" stroke="#f8fafc" stroke-width="4"/>`,
    ),
  },
  {
    pack: "Hustle",
    label: "Vault lock",
    data: svg(
      `${grad("g3", "#34d399", "#065f46")}<rect x="22" y="56" width="84" height="58" rx="12" fill="url(#g3)" stroke="#052e22" stroke-width="4"/><path d="M42 56V40a22 22 0 0 1 44 0v16" fill="none" stroke="#052e22" stroke-width="8" stroke-linecap="round"/><circle cx="64" cy="84" r="9" fill="#052e22"/><rect x="60" y="86" width="8" height="18" rx="4" fill="#052e22"/>`,
    ),
  },
  {
    pack: "Neon Glyphs",
    label: "Bolt",
    data: svg(
      `${grad("g4", "#fde68a", "#f59e0b")}<path d="M74 8 30 70h26L50 120l48-66H70z" fill="url(#g4)" stroke="#3b2405" stroke-width="4" stroke-linejoin="round"/>`,
    ),
  },
  {
    pack: "Neon Glyphs",
    label: "Signal",
    data: svg(
      `${grad("g5", "#a7f3d0", "#0d9488")}<g stroke="url(#g5)" stroke-width="10" stroke-linecap="round" fill="none"><path d="M64 104V84"/><path d="M44 74a28 28 0 0 1 40 0"/><path d="M28 58a50 50 0 0 1 72 0"/><path d="M14 42a70 70 0 0 1 100 0"/></g>`,
    ),
  },
  {
    pack: "Neon Glyphs",
    label: "Watchful eye",
    data: svg(
      `${grad("g6", "#c4b5fd", "#4c1d95")}<path d="M8 64s22-34 56-34 56 34 56 34-22 34-56 34S8 64 8 64z" fill="url(#g6)" stroke="#1e1240" stroke-width="4"/><circle cx="64" cy="64" r="18" fill="#1e1240"/><circle cx="70" cy="58" r="6" fill="#f5f3ff"/>`,
    ),
  },
  {
    pack: "Moods",
    label: "Smirk",
    data: svg(
      `${grad("g7", "#fcd34d", "#ea580c")}<circle cx="64" cy="64" r="52" fill="url(#g7)" stroke="#3b1607" stroke-width="4"/><circle cx="46" cy="52" r="6" fill="#3b1607"/><circle cx="82" cy="52" r="6" fill="#3b1607"/><path d="M40 78c10 14 34 16 48 2" fill="none" stroke="#3b1607" stroke-width="6" stroke-linecap="round"/>`,
    ),
  },
  {
    pack: "Moods",
    label: "On fire",
    data: svg(
      `${grad("g8", "#fda4af", "#b91c1c")}<path d="M64 8c22 26 40 40 40 62a40 40 0 1 1-80 0c0-14 8-22 16-32 4 10 10 14 14 14 0-16-2-28 10-44z" fill="url(#g8)" stroke="#3f0d0d" stroke-width="4"/>`,
    ),
  },
  {
    pack: "Moods",
    label: "Ghost mode",
    data: svg(
      `${grad("g9", "#e2e8f0", "#64748b")}<path d="M64 12c24 0 40 18 40 42v54l-14-10-13 10-13-10-13 10-14-10v-54c0-24 16-42 40-42z" fill="url(#g9)" stroke="#0f172a" stroke-width="4"/><circle cx="50" cy="56" r="7" fill="#0f172a"/><circle cx="78" cy="56" r="7" fill="#0f172a"/>`,
    ),
  },
];

const PHOTO_RATE_CARD = svg(
  `${grad("p1", "#0f2f26", "#05201a")}<rect width="640" height="480" fill="url(#p1)"/><rect x="34" y="34" width="572" height="412" rx="18" fill="none" stroke="#34d399" stroke-width="3" opacity=".6"/><text x="60" y="120" font-family="monospace" font-size="34" fill="#a7f3d0">RATE CARD · CRATE 42</text><text x="60" y="190" font-family="monospace" font-size="26" fill="#f8fafc">Unit  1 250</text><text x="60" y="234" font-family="monospace" font-size="26" fill="#f8fafc">Qty    42</text><text x="60" y="278" font-family="monospace" font-size="26" fill="#fbbf24">Total  52 500</text><text x="60" y="392" font-family="monospace" font-size="20" fill="#5eead4" opacity=".8">burn after reading · 48h</text>`,
  640,
  480,
);

/* ── seeding ───────────────────────────────────────────────────── */

let attempted = false;

export async function ensureSeeded() {
  if (attempted) return;
  attempted = true;
  try {
    await runSeed();
  } catch (error) {
    attempted = false;
    console.error("[hustler] seed failed", error);
  }
}

async function runSeed() {
  const current = await db
    .select()
    .from(settings)
    .where(eq(settings.key, "seed_version"))
    .limit(1);
  if (current[0]?.value === String(SEED_VERSION)) return;

  await db.transaction(async (tx) => {

    await tx.delete(purgeEvents);
    await tx.delete(callLogs);
    await tx.delete(messages);
    await tx.delete(stickers);
    await tx.delete(conversations);
    await tx.delete(sessions);
    await tx.delete(users);
    await tx.delete(settings);

    const ids: Record<string, number> = {};
    for (const u of USERS) {
      const salt = newSalt();
      const [row] = await tx
        .insert(users)
        .values({
          handle: u.handle,
          name: u.name,
          salt,
          passwordHash: hashPassword(u.handle, u.password, salt),
          hue: u.hue,
          tagline: u.tagline,
          role: u.role,
          status: u.status,
        })
        .returning();
      ids[u.handle] = row.id;
    }

    const stickerIds: Record<string, number> = {};
    for (const s of BUILTIN_STICKERS) {
      const [row] = await tx
        .insert(stickers)
        .values({
          ownerId: null,
          pack: s.pack,
          label: s.label,
          source: "builtin",
          data: s.data,
        })
        .returning();
      stickerIds[s.label] = row.id;
    }

    // conversations: the group + all six 1:1 threads
    const [group] = await tx
      .insert(conversations)
      .values({ kind: "group", key: GROUP_KEY, title: GROUP_TITLE, subject: GROUP_SUBJECT })
      .returning();
    const conv: Record<string, number> = { group: group.id };

    const handles = USERS.map((u) => u.handle);
    for (let i = 0; i < handles.length; i++) {
      for (let j = i + 1; j < handles.length; j++) {
        const key = dmKey(handles[i], handles[j]);
        const [row] = await tx
          .insert(conversations)
          .values({ kind: "dm", key })
          .returning();
        conv[key] = row.id;
      }
    }

    const now = Date.now();
    const at = (minsAgo: number) => new Date(now - minsAgo * 60_000);

    const insertMessage = async (
      conversationId: number,
      handle: string | null,
      kind: string,
      body: string,
      minsAgo: number,
      extra: Partial<typeof messages.$inferInsert> = {},
    ) => {
      const createdAt = at(minsAgo);
      const [row] = await tx
        .insert(messages)
        .values({
          conversationId,
          senderId: handle ? ids[handle] : ids["pov_navneet"],
          kind,
          body,
          status: "read",
          createdAt,
          expiresAt: extra.expiresAt ?? expiryFor(createdAt),
          ...extra,
        })
        .returning();
      await tx
        .update(conversations)
        .set({ lastMessageAt: createdAt })
        .where(eq(conversations.id, conversationId));
      return row;
    };

    /* group thread */
    await insertMessage(
      group.id,
      null,
      "system",
      "Inner Circle opened. Messages self-destruct 48h after delivery.",
      260,
      { status: "read" },
    );
    await insertMessage(
      group.id,
      "pov_shreya",
      "text",
      "Truck loaded. 42 crates, seals intact.",
      248,
    );
    await insertMessage(
      group.id,
      "pov_navya",
      "image",
      "Rate card for tonight. Do not forward.",
      240,
      { mediaData: PHOTO_RATE_CARD, mediaMime: "image/svg+xml", mediaName: "rate-card.jpg" },
    );
    await insertMessage(group.id, "w.o.n.s", "text", "Pin drop received. ETA 25 min.", 196);
    await insertMessage(
      group.id,
      "pov_navneet",
      "sticker",
      "",
      190,
      { stickerId: String(stickerIds["Vault lock"]) },
    );
    await insertMessage(
      group.id,
      "pov_navneet",
      "text",
      "Rates stay off the thread. Call me on the secure line.",
      184,
    );
    await insertMessage(group.id, "pov_shreya", "text", "Copy. Ringing you in 5.", 33);

    /* this one is older than the 48h TTL — the first sweep will burn it */
    await insertMessage(
      group.id,
      "pov_navya",
      "text",
      "[expired] Old manifest reference — should already be gone.",
      52 * 60,
      { expiresAt: new Date(now - 4 * 3_600_000) },
    );

    /* dm: navneet ↔ shreya */
    const ns = conv[dmKey("pov_navneet", "pov_shreya")];
    await insertMessage(ns, "pov_shreya", "text", "You awake? Gate 3 is short two boxes.", 300);
    await insertMessage(ns, "pov_navneet", "text", "Awake. Recount and send me the seal numbers.", 292);
    await insertMessage(ns, "pov_shreya", "text", "Done — matched. My mistake.", 120);
    await insertMessage(ns, "pov_navneet", "voice", "Voice note · 0:14", 22, { status: "delivered" });

    /* dm: navneet ↔ aarav */
    const na = conv[dmKey("w.o.n.s", "pov_navneet")];
    await insertMessage(na, "w.o.n.s", "text", "Fuel stop. 15 min behind schedule.", 90);
    await insertMessage(na, "pov_navneet", "text", "Send live location when you're back on the highway.", 86);
    await insertMessage(na, "w.o.n.s", "sticker", "", 40, {
      stickerId: String(stickerIds["Night truck"]),
    });

    /* dm: shreya ↔ nabhya */
    const sn = conv[dmKey("pov_navya", "pov_shreya")];
    await insertMessage(sn, "pov_navya", "text", "Ledger updated for week 12.", 640);
    await insertMessage(sn, "pov_shreya", "text", "Perfect. Printing one copy only.", 636);

    /* call history */
    await tx.insert(callLogs).values([
      {
        conversationId: ns,
        callerId: ids["pov_navneet"],
        kind: "audio",
        status: "completed",
        durationSeconds: 312,
        startedAt: at(150),
      },
      {
        conversationId: group.id,
        callerId: ids["pov_shreya"],
        kind: "video",
        status: "missed",
        durationSeconds: 0,
        startedAt: at(300),
      },
      {
        conversationId: conv[dmKey("pov_navya", "pov_navneet")],
        callerId: ids["pov_navya"],
        kind: "video",
        status: "completed",
        durationSeconds: 1465,
        startedAt: at(26 * 60),
      },
      {
        conversationId: na,
        callerId: ids["w.o.n.s"],
        kind: "audio",
        status: "declined",
        durationSeconds: 0,
        startedAt: at(70),
      },
    ]);

    await tx.insert(settings).values([
      { key: "seed_version", value: String(SEED_VERSION) },
      { key: "demo_replies", value: "on" },
    ]);
  });
}
