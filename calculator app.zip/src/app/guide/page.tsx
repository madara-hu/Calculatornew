import { readFile } from "node:fs/promises";
import path from "node:path";
import Link from "next/link";
import Markdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { IconChevronLeft, IconDownload } from "@/components/ui/icons";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Build manual · Hustler Calculator",
};

const DOWNLOADS = [
  { key: "all", label: "hustler-handover.zip" },
  { key: "setup-guide", label: "SETUP_GUIDE.md" },
  { key: "env-example", label: ".env.example" },
  { key: "termux-sh", label: "termux.sh (phone build)" },
  { key: "codespace-sh", label: "codespace.sh (SSH build)" },
  { key: "app-json", label: "expo app.json" },
  { key: "eas-json", label: "expo eas.json" },
  { key: "app-tsx", label: "expo App.tsx" },
  { key: "backend-ts", label: "backend.ts adapter" },
  { key: "cf-worker", label: "cloudflare worker.ts" },
  { key: "cf-wrangler", label: "wrangler.toml" },
  { key: "firestore-rules", label: "firestore.rules" },
  { key: "firebase-functions", label: "firebase functions.ts" },
  { key: "rn-firestore", label: "rn-firestore.ts (Expo realtime)" },
];

const CONTENTS = [
  "1. Run the reference build",
  "2. API surface",
  "3. Exact code insertion points",
  "4. Porting to React Native / Expo SDK 51",
  "5. Auto-purge routine",
  "6. Security notes",
  "7. Realtime — Cloudflare + Firebase",
  "8. Easiest build path (Termux / Codespace)",
];

export default async function GuidePage() {
  let markdown = "";
  try {
    markdown = await readFile(path.join(process.cwd(), "SETUP_GUIDE.md"), "utf8");
  } catch {
    markdown = "# SETUP_GUIDE.md not found\n\nThe handover document is missing from the project root.";
  }

  return (
    <div className="cover-ambient min-h-dvh">
      <header className="sticky top-0 z-30 border-b border-white/8 bg-graphite-950/88 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1080px] items-center gap-4 px-4 py-3">
          <Link
            href="/"
            className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/4 px-3 py-1.5 font-mono text-[11px] tracking-[0.16em] text-mint-text/70 uppercase transition hover:border-amber-glow/45 hover:text-amber-glow"
          >
            <IconChevronLeft size={13} /> calculator
          </Link>
          <div className="min-w-0">
            <h1 className="truncate font-display text-[14px] tracking-[0.3em] text-amber-glow uppercase">
              Build manual
            </h1>
            <p className="truncate font-mono text-[10.5px] tracking-[0.16em] text-mint-text/35 uppercase">
              termux · codespace ssh · expo sdk 51 · realtime sse · firebase · cloudflare
            </p>
          </div>
          <div className="ml-auto hidden gap-2 md:flex">
            {DOWNLOADS.slice(0, 3).map((d) => (
              <a
                key={d.key}
                href={`/api/download/${d.key}`}
                className="flex items-center gap-1.5 rounded-full border border-white/10 px-3 py-1.5 font-mono text-[10.5px] tracking-[0.14em] text-mint-text/60 uppercase transition hover:border-jade-500/45 hover:text-jade-300"
              >
                <IconDownload size={12} /> {d.label}
              </a>
            ))}
          </div>
        </div>
      </header>

      <div className="mx-auto grid max-w-[1080px] gap-8 px-4 py-8 lg:grid-cols-[220px_1fr]">
        <aside className="hidden lg:block">
          <div className="sticky top-24 space-y-4">
            <nav className="rounded-3xl border border-white/8 bg-graphite-900/70 p-4 backdrop-blur">
              <p className="font-mono text-[10px] tracking-[0.24em] text-mint-text/35 uppercase">
                contents
              </p>
              <ul className="mt-3 space-y-2">
                {CONTENTS.map((c) => (
                  <li key={c} className="font-mono text-[11.5px] leading-relaxed text-mint-text/60">
                    {c}
                  </li>
                ))}
              </ul>
            </nav>
            <div className="rounded-3xl border border-jade-500/20 bg-jade-500/6 p-4">
              <p className="font-mono text-[10px] tracking-[0.24em] text-jade-300/80 uppercase">
                handover bundle
              </p>
              <div className="mt-3 space-y-1.5">
                {DOWNLOADS.map((d) => (
                  <a
                    key={d.key}
                    href={`/api/download/${d.key}`}
                    className="flex items-center gap-2 rounded-xl border border-white/8 bg-vault-900/40 px-3 py-2 font-mono text-[11px] text-mint-text/70 transition hover:border-jade-500/40 hover:text-jade-300"
                  >
                    <IconDownload size={12} /> {d.label}
                  </a>
                ))}
              </div>
            </div>
          </div>
        </aside>

        <article className="min-w-0 rounded-[30px] border border-white/8 bg-graphite-900/72 p-5 backdrop-blur-xl sm:p-8">
          <Markdown
            remarkPlugins={[remarkGfm]}
            components={{
              h1: ({ children }) => (
                <h1 className="font-display text-[30px] leading-tight font-semibold text-mint-text sm:text-[36px]">
                  {children}
                </h1>
              ),
              h2: ({ children }) => (
                <h2 className="mt-10 border-l-2 border-amber-glow/70 pl-3.5 font-display text-[21px] font-semibold text-mint-text">
                  {children}
                </h2>
              ),
              h3: ({ children }) => (
                <h3 className="mt-7 font-display text-[16px] font-semibold tracking-wide text-amber-glow/90">
                  {children}
                </h3>
              ),
              p: ({ children }) => (
                <p className="mt-3 text-[14px] leading-relaxed text-mint-text/72">{children}</p>
              ),
              ul: ({ children }) => <ul className="mt-3 space-y-1.5 pl-5">{children}</ul>,
              ol: ({ children }) => <ol className="mt-3 list-decimal space-y-1.5 pl-5">{children}</ol>,
              li: ({ children }) => (
                <li className="list-disc text-[13.5px] leading-relaxed text-mint-text/72 marker:text-amber-glow/70">
                  {children}
                </li>
              ),
              strong: ({ children }) => <strong className="font-semibold text-mint-text">{children}</strong>,
              em: ({ children }) => <em className="text-jade-300/90 not-italic">{children}</em>,
              a: ({ children, href }) => (
                <a
                  href={href}
                  className="font-medium text-jade-300 underline decoration-jade-500/40 underline-offset-2 hover:text-jade-400"
                >
                  {children}
                </a>
              ),
              code: ({ children }) => (
                <code className="rounded-md bg-white/8 px-1.5 py-0.5 font-mono text-[12.5px] text-amber-glow">
                  {children}
                </code>
              ),
              pre: ({ children }) => (
                <pre className="scroll-thin mt-4 overflow-x-auto rounded-2xl border border-white/8 bg-graphite-950/85 p-4 font-mono text-[12.5px] leading-relaxed [&_code]:bg-transparent [&_code]:p-0 [&_code]:text-jade-300">
                  {children}
                </pre>
              ),
              blockquote: ({ children }) => (
                <blockquote className="mt-4 border-l-2 border-jade-500/60 bg-jade-500/6 py-2 pl-4 text-[13.5px] text-mint-text/75">
                  {children}
                </blockquote>
              ),
              hr: () => <hr className="my-8 border-white/8" />,
              table: ({ children }) => (
                <div className="scroll-thin mt-4 overflow-x-auto rounded-2xl border border-white/8">
                  <table className="w-full border-collapse text-left">{children}</table>
                </div>
              ),
              thead: ({ children }) => <thead className="bg-white/5">{children}</thead>,
              th: ({ children }) => (
                <th className="border-b border-white/8 px-3 py-2 font-mono text-[10.5px] tracking-[0.14em] text-mint-text/55 uppercase">
                  {children}
                </th>
              ),
              td: ({ children }) => (
                <td className="border-b border-white/5 px-3 py-2 text-[12.5px] text-mint-text/72">
                  {children}
                </td>
              ),
            }}
          >
            {markdown}
          </Markdown>
        </article>
      </div>
    </div>
  );
}
