import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { callLogs, settings } from "@/db/schema";
import { HttpError, json, readBody, requireUser, route, threadFor } from "@/lib/http";
import { broadcast } from "@/lib/realtime";
import { toCallWire } from "@/lib/repo";

export const dynamic = "force-dynamic";

/**
 * POST /api/calls — ring someone (audio or video).
 * With `demoIncoming` the simulator rings *you* on behalf of another member,
 * so the incoming-call UI is exercised exactly like a real device-to-device call.
 */
export const POST = route(async (req) => {
  const me = await requireUser();
  const b = await readBody<{
    conversationId?: number;
    kind?: string;
    demoIncoming?: boolean;
  }>(req);
  const conversationId = Number(b.conversationId ?? 0);
  if (!conversationId) throw new HttpError(400, "conversationId is required");
  const { conv, members } = await threadFor(me, conversationId);
  const others = members.filter((id) => id !== me.id);
  if (!others.length) throw new HttpError(409, "Nobody to call");

  const kind = b.kind === "video" ? "video" : "audio";
  let callerId = me.id;
  if (b.demoIncoming) {
    const flag = await db
      .select()
      .from(settings)
      .where(eq(settings.key, "demo_replies"))
      .limit(1);
    if ((flag[0]?.value ?? "on") !== "on") throw new HttpError(409, "Simulator is off");
    callerId = others[Math.floor(Math.random() * others.length)];
  }

  const [row] = await db
    .insert(callLogs)
    .values({ conversationId: conv.id, callerId, kind, status: "ringing" })
    .returning();

  const wire = toCallWire(row);
  broadcast({ type: "call", conversationId: conv.id, call: wire }, members);
  return json({ call: wire, partnerIds: others });
});

/** PATCH /api/calls — end / miss / decline + record duration. */
export const PATCH = route(async (req) => {
  const me = await requireUser();
  const b = await readBody<{ id?: number; status?: string; durationSeconds?: number }>(req);
  const id = Number(b.id ?? 0);
  if (!id) throw new HttpError(400, "id is required");
  const status = ["completed", "missed", "declined"].includes(String(b.status))
    ? String(b.status)
    : "completed";

  const existing = await db.select().from(callLogs).where(eq(callLogs.id, id)).limit(1);
  if (!existing[0]) throw new HttpError(404, "Call not found");
  const { conv, members } = await threadFor(me, existing[0].conversationId); // membership check

  const [row] = await db
    .update(callLogs)
    .set({
      status,
      durationSeconds: Math.max(0, Math.min(86_400, Number(b.durationSeconds ?? 0) || 0)),
    })
    .where(and(eq(callLogs.id, id), eq(callLogs.callerId, existing[0].callerId)))
    .returning();
  if (!row) throw new HttpError(404, "Call not found");

  const wire = toCallWire(row);
  broadcast({ type: "call", conversationId: conv.id, call: wire }, members);
  return json({ call: wire });
});
