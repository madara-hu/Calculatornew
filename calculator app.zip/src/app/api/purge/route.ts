import { eq } from "drizzle-orm";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { PURGE_HOURS } from "@/lib/config";
import { json, readBody, requireUser, route } from "@/lib/http";
import { broadcast } from "@/lib/realtime";
import { counters, purgeExpired } from "@/lib/repo";

export const dynamic = "force-dynamic";

/** GET /api/settings — simulator flag + purge telemetry. */
export const GET = route(async () => {
  await requireUser();
  const rows = await db.select().from(settings).where(eq(settings.key, "demo_replies")).limit(1);
  const { alive, burned } = await counters();
  return json({ demoReplies: (rows[0]?.value ?? "on") === "on", purgeHours: PURGE_HOURS, alive, burned });
});

/** POST /api/purge — manual sweep, or flip the simulator, or both. */
export const POST = route(async (req) => {
  await requireUser();
  const b = await readBody<{ purge?: boolean; demoReplies?: boolean }>(req);

  if (typeof b.demoReplies === "boolean") {
    const value = b.demoReplies ? "on" : "off";
    const existing = await db.select().from(settings).where(eq(settings.key, "demo_replies")).limit(1);
    if (existing.length) {
      await db.update(settings).set({ value }).where(eq(settings.key, "demo_replies"));
    } else {
      await db.insert(settings).values({ key: "demo_replies", value });
    }
  }

  const purge = await purgeExpired("manual");
  if (purge.ids.length) {
    broadcast({ type: "purge", ids: purge.ids, purged: purge.purged }, null);
  }
  const { alive, burned } = await counters();
  return json({
    purged: purge.purged,
    ids: purge.ids,
    event: purge.event,
    alive,
    burned,
    demoReplies: b.demoReplies ?? undefined,
  });
});
