import { and, eq, gt, inArray, lt, sql } from "drizzle-orm";
import { db } from "@/db";
import { callLogs, messages, purgeEvents, stickers } from "@/db/schema";
import { PURGE_HOURS } from "@/lib/config";
import { json, requireUser, route, threadFor, threadsFor } from "@/lib/http";
import { broadcast } from "@/lib/realtime";
import { counters, purgeExpired, toCallWire, toMessageWire, toPurgeWire, toStickerWire } from "@/lib/repo";

export const dynamic = "force-dynamic";

/**
 * GET /api/sync?after=<msgId>&ac=<callId>&as=<stickerId>&open=<conversationId>
 * Long-poll-ish delta feed. Every call also runs the 48h auto-purge sweep.
 */
export const GET = route(async (req) => {
  const me = await requireUser();
  const url = new URL(req.url);
  const after = Number(url.searchParams.get("after") ?? 0) || 0;
  const afterCall = Number(url.searchParams.get("ac") ?? 0) || 0;
  const afterSticker = Number(url.searchParams.get("as") ?? 0) || 0;
  const open = Number(url.searchParams.get("open") ?? 0) || 0;

  const purge = await purgeExpired("auto");
  const threads = await threadsFor(me);
  const convIds = threads.map((t) => t.row.id);

  /* read receipts + delivery ticks for the thread the user is looking at */
  let readIds: { conversationId: number; ids: number[] }[] = [];
  if (open && convIds.includes(open)) {
    const { conv, members } = await threadFor(me, open);
    const eightSecondsAgo = new Date(Date.now() - 8_000);
    // incoming → I read them
    await db
      .update(messages)
      .set({ status: "read" })
      .where(
        and(
          eq(messages.conversationId, conv.id),
          sql`${messages.senderId} <> ${me.id}`,
          sql`${messages.status} <> 'read'`,
        ),
      );
    // outgoing → delivered instantly, read after ~8s (counterpart is "watching")
    await db
      .update(messages)
      .set({ status: "delivered" })
      .where(
        and(
          eq(messages.conversationId, conv.id),
          eq(messages.senderId, me.id),
          eq(messages.status, "sent"),
        ),
      );
    await db
      .update(messages)
      .set({ status: "read" })
      .where(
        and(
          eq(messages.conversationId, conv.id),
          eq(messages.senderId, me.id),
          lt(messages.createdAt, eightSecondsAgo),
          sql`${messages.status} <> 'read'`,
        ),
      );

    const read = await db
      .select({ id: messages.id })
      .from(messages)
      .where(and(eq(messages.conversationId, conv.id), eq(messages.status, "read")));
    readIds = [{ conversationId: conv.id, ids: read.map((r) => r.id) }];
    if (readIds[0].ids.length) {
      broadcast({ type: "read", conversationId: conv.id, ids: readIds[0].ids }, members);
    }
  }

  const [msgRows, callRows, stickerRows, purgeRows] = await Promise.all([
    convIds.length
      ? db
          .select()
          .from(messages)
          .where(and(inArray(messages.conversationId, convIds), gt(messages.id, after)))
          .orderBy(messages.id)
      : Promise.resolve([]),
    convIds.length
      ? db
          .select()
          .from(callLogs)
          .where(and(inArray(callLogs.conversationId, convIds), gt(callLogs.id, afterCall)))
          .orderBy(callLogs.id)
      : Promise.resolve([]),
    db.select().from(stickers).where(gt(stickers.id, afterSticker)).orderBy(stickers.id),
    db.select().from(purgeEvents).orderBy(purgeEvents.ranAt).limit(10),
  ]);

  const { alive, burned } = await counters();

  return json({
    messages: msgRows.map(toMessageWire),
    calls: callRows.map(toCallWire),
    stickers: stickerRows.map(toStickerWire),
    purges: purgeRows.map(toPurgeWire),
    deletedMessageIds: purge.ids,
    serverTime: new Date().toISOString(),
    purgeHours: PURGE_HOURS,
    alive,
    burned,
    readIds,
  });
});
