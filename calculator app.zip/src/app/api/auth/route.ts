import {
  createSession,
  destroySession,
  getSessionUser,
  toUserWire,
  verifyPassword,
} from "@/lib/auth";
import { HttpError, json, readBody, route } from "@/lib/http";
import { findUserByHandle } from "@/lib/repo";
import { ensureSeeded } from "@/db/seed";
import { EXPOSE_DEMO_CREDENTIALS, USERS } from "@/lib/config";

export const dynamic = "force-dynamic";

const attempts = new Map<string, { count: number; until: number }>();

/**
 * Public roster — usernames, names, roles and colours only.
 * `demoPassword` is included solely while EXPOSE_DEMO_CREDENTIALS is on, so a
 * reviewer can get in. Flip it off and the passwords exist only as salted
 * hashes inside Postgres.
 */
const roster = () =>
  USERS.map((u) => ({
    handle: u.handle,
    name: u.name,
    hue: u.hue,
    role: u.role,
    tagline: u.tagline,
    demoPassword: EXPOSE_DEMO_CREDENTIALS ? u.password : undefined,
  }));

/** GET /api/auth — who am I (if anyone) + the four-seat roster */
export const GET = route(async () => {
  await ensureSeeded();
  const me = await getSessionUser();
  return json({ me, roster: roster() });
});

/** POST /api/auth — direct local login. No OAuth, no Gmail, no sign-ups. */
export const POST = route(async (req) => {
  const body = await readBody<{ handle?: string; password?: string; pin?: string }>(req);
  await ensureSeeded();

  const handle = String(body.handle ?? "")
    .trim()
    .toLowerCase();
  const password = String(body.password ?? body.pin ?? "");
  const row = await findUserByHandle(handle);

  const rec = attempts.get(handle);
  if (rec && rec.until > Date.now()) {
    const wait = Math.ceil((rec.until - Date.now()) / 1000);
    throw new HttpError(429, `Too many failed attempts. Retry in ${wait}s.`);
  }

  // Uniform error for unknown handle and wrong password (no account enumeration).
  const ok = row ? verifyPassword(row.handle, password, row.salt, row.passwordHash) : false;
  if (!row || !ok) {
    const count = (rec?.count ?? 0) + 1;
    attempts.set(handle, { count, until: count >= 5 ? Date.now() + 30_000 : 0 });
    throw new HttpError(
      401,
      count >= 5
        ? "Locked for 30 seconds after 5 failed attempts."
        : `Wrong username or password — ${5 - count} attempt${5 - count === 1 ? "" : "s"} left.`,
    );
  }

  attempts.delete(handle);
  await createSession(row.id);
  return json({ me: toUserWire(row) });
});

/** DELETE /api/auth — burn the session cookie */
export const DELETE = route(async () => {
  await destroySession();
  return json({ ok: true });
});
