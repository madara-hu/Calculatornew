import { subscribe } from "@/lib/realtime/bus";
import { json, requireUser, route, threadsFor } from "@/lib/http";

export const dynamic = "force-dynamic";

/**
 * GET /api/stream — Server-Sent Events.
 * Zero-config realtime: the moment a message, call, sticker, read receipt or
 * purge sweep happens, every connected member of that thread gets it pushed.
 * A `ping` every 20s keeps proxies honest and lets the client detect a dead
 * socket, at which point it falls back to /api/sync polling automatically.
 */
export const GET = route(async () => {
  const me = await requireUser();
  const threads = await threadsFor(me);
  const threadIds = threads.map((t) => t.row.id);

  const encoder = new TextEncoder();
  let unsubscribe: (() => void) | null = null;
  let heartbeat: ReturnType<typeof setInterval> | null = null;
  let closed = false;

  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      const send = (event: string, data: unknown) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));
        } catch {
          closed = true;
        }
      };

      send("hello", {
        ok: true,
        as: me.handle,
        threads: threadIds,
        at: Date.now(),
        note: "postgres-sse live · cloudflare/firebase adapters engage when their env keys exist",
      });

      unsubscribe = subscribe((envelope) => {
        if (envelope.audience && !envelope.audience.includes(me.id)) return;
        send("vault", envelope.event);
      });

      heartbeat = setInterval(() => send("ping", { at: Date.now() }), 20_000);
    },
    cancel() {
      closed = true;
      unsubscribe?.();
      if (heartbeat) clearInterval(heartbeat);
    },
  });

  return new Response(stream, {
    headers: {
      "content-type": "text/event-stream; charset=utf-8",
      "cache-control": "no-cache, no-transform",
      connection: "keep-alive",
      "x-accel-buffering": "no",
    },
  });
});

/** HEAD-style liveness probe for tooling that cannot hold a stream open. */
export const HEAD = route(async () => {
  await requireUser();
  return json({ ok: true });
});
