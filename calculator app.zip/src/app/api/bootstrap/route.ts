import { and, desc, gt, inArray } from "drizzle-orm";
import { db } from "@/db";
import { callLogs, messages, purgeEvents, stickers } from "@/db/schema";
import { PURGE_HOURS } from "@/lib/config";
import { HttpError, json, requireUser, route, threadsFor } from "@/lib/http";
import { counters, purgeExpired, toCallWire, toConversationWire, toMessageWire, toPurgeWire, toStickerWire } from "@/lib/repo";

export const dynamic = "force-dynamic";

/** GET /api/bootstrap — everything the vault needs on first paint. */
export const GET = route(async () => {
  const me = await requireUser();
  await purgeExpired("auto");

  const threads = await threadsFor(me);
  if (!threads.length) throw new HttpError(500, "No threads provisioned");
  const convIds = threads.map((t) => t.row.id);

  const [msgRows, callRows, stickerRows, purgeRows] = await Promise.all([
    db
      .select()
      .from(messages)
      .where(and(inArray(messages.conversationId, convIds), gt(messages.expiresAt, new Date())))
      .orderBy(messages.id),
    db
      .select()
      .from(callLogs)
      .where(inArray(callLogs.conversationId, convIds))
      .orderBy(desc(callLogs.startedAt))
      .limit(60),
    db.select().from(stickers).orderBy(stickers.id),
    db.select().from(purgeEvents).orderBy(desc(purgeEvents.ranAt)).limit(10),
  ]);

  const { alive, burned } = await counters();

  return json({
    me,
    users: threads[0].all,
    conversations: threads.map((t) => toConversationWire(t.row, t.all)),
    messages: msgRows.map(toMessageWire),
    calls: callRows.map(toCallWire),
    stickers: stickerRows.map(toStickerWire),
    purges: purgeRows.map(toPurgeWire),
    serverTime: new Date().toISOString(),
    purgeHours: PURGE_HOURS,
    alive,
    burned,
  });
});
