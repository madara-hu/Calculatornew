import { readFile } from "node:fs/promises";
import path from "node:path";
import { createZip, type ZipEntry } from "@/lib/zip";
import { HttpError, json, route } from "@/lib/http";

export const dynamic = "force-dynamic";

const root = process.cwd();

/**
 * Explicit, statically scoped list so the bundler never traces the whole repo.
 * Add new handover files here and they appear in the zip automatically.
 */
const BUNDLE: string[] = [
  "SETUP_GUIDE.md",
  "handover/.env.example",
  "handover/app.json",
  "handover/eas.json",
  "handover/App.tsx",
  "handover/backend.ts",
  "handover/termux.sh",
  "handover/codespace.sh",
  "handover/cloudflare/worker.ts",
  "handover/cloudflare/wrangler.toml",
  "handover/firebase/firestore.rules",
  "handover/firebase/functions.ts",
  "handover/firebase/rn-firestore.ts",
  "src/lib/config.ts",
  "src/lib/realtime/firebase.ts",
  "src/lib/realtime/cloudflare.ts",
  "src/lib/realtime/bus.ts",
  "src/db/schema.ts",
];

/** GET /api/download/all — hustler-handover.zip */
export const GET = route(async () => {
  const entries: ZipEntry[] = [];
  const missing: string[] = [];

  for (const rel of BUNDLE) {
    try {
      entries.push({ name: `hustler-handover/${rel}`, data: await readFile(path.join(root, rel)) });
    } catch {
      missing.push(rel);
    }
  }

  if (!entries.length) throw new HttpError(404, "Handover bundle is empty");

  const archive = createZip(entries);
  return new Response(new Uint8Array(archive), {
    headers: {
      "content-type": "application/zip",
      "content-disposition": 'attachment; filename="hustler-handover.zip"',
      "content-length": String(archive.length),
      "cache-control": "no-store",
      "x-bundle-files": String(entries.length),
      ...(missing.length ? { "x-bundle-missing": missing.join(",") } : {}),
    },
  });
});

/** Handy for debugging what the archive contains. */
export const HEAD = route(async () => json({ files: BUNDLE }));
