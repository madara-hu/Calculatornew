import { readFile } from "node:fs/promises";
import path from "node:path";
import { HttpError, json, route } from "@/lib/http";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ file: string }> };

type Entry = { type: string; name: string; read: () => Promise<Buffer> };

const root = process.cwd();
const text = "text/plain; charset=utf-8";

/**
 * Developer handover bundle. Every path is a literal so the bundler only traces
 * these files (no whole-project NFT warning). `all` returns a real .zip.
 */
const HANDOVER: Record<string, Entry> = {
  "setup-guide": {
    type: "text/markdown; charset=utf-8",
    name: "SETUP_GUIDE.md",
    read: () => readFile(path.join(root, "SETUP_GUIDE.md")),
  },
  "env-example": {
    type: text,
    name: ".env.example",
    read: () => readFile(path.join(root, "handover", ".env.example")),
  },
  "app-json": {
    type: "application/json",
    name: "app.json",
    read: () => readFile(path.join(root, "handover", "app.json")),
  },
  "eas-json": {
    type: "application/json",
    name: "eas.json",
    read: () => readFile(path.join(root, "handover", "eas.json")),
  },
  "app-tsx": { type: text, name: "App.tsx", read: () => readFile(path.join(root, "handover", "App.tsx")) },
  "backend-ts": {
    type: text,
    name: "backend.ts",
    read: () => readFile(path.join(root, "handover", "backend.ts")),
  },
  "termux-sh": {
    type: "text/x-shellscript; charset=utf-8",
    name: "termux.sh",
    read: () => readFile(path.join(root, "handover", "termux.sh")),
  },
  "codespace-sh": {
    type: "text/x-shellscript; charset=utf-8",
    name: "codespace.sh",
    read: () => readFile(path.join(root, "handover", "codespace.sh")),
  },
  "cf-worker": {
    type: text,
    name: "worker.ts",
    read: () => readFile(path.join(root, "handover", "cloudflare", "worker.ts")),
  },
  "cf-wrangler": {
    type: text,
    name: "wrangler.toml",
    read: () => readFile(path.join(root, "handover", "cloudflare", "wrangler.toml")),
  },
  "firestore-rules": {
    type: text,
    name: "firestore.rules",
    read: () => readFile(path.join(root, "handover", "firebase", "firestore.rules")),
  },
  "firebase-functions": {
    type: text,
    name: "functions.ts",
    read: () => readFile(path.join(root, "handover", "firebase", "functions.ts")),
  },
  "rn-firestore": {
    type: text,
    name: "rn-firestore.ts",
    read: () => readFile(path.join(root, "handover", "firebase", "rn-firestore.ts")),
  },
};

export const GET = route(async (_req: Request, ctx: Ctx) => {
  const { file } = await ctx.params;
  const entry = HANDOVER[file];
  if (!entry) return json({ error: "Unknown file", available: Object.keys(HANDOVER) }, 404);

  try {
    const buf = await entry.read();
    return new Response(new Uint8Array(buf), {
      headers: {
        "content-type": entry.type,
        "content-disposition": `attachment; filename="${entry.name}"`,
        "cache-control": "no-store",
      },
    });
  } catch {
    throw new HttpError(404, `${entry.name} is missing from the project root`);
  }
});
