import { broadcast, realtimeStatus } from "@/lib/realtime";
import { json, requireUser, route } from "@/lib/http";

export const dynamic = "force-dynamic";

/** GET /api/realtime — live transport diagnostics for the Settings panel. */
export const GET = route(async () => {
  await requireUser();
  return json({ status: await realtimeStatus() });
});

/**
 * POST /api/realtime — fire a test event through every configured transport so
 * you can watch it land on a second device (or in the panel counter) right
 * after pasting your Cloudflare / Firebase keys.
 */
export const POST = route(async () => {
  await requireUser();
  broadcast({ type: "ping", at: new Date().toISOString() }, null);
  // give the fire-and-forget adapters a moment before reporting
  await new Promise((r) => setTimeout(r, 900));
  return json({ status: await realtimeStatus() });
});
