import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { stickers } from "@/db/schema";
import { HttpError, json, readBody, requireUser, route } from "@/lib/http";
import { broadcast } from "@/lib/realtime";
import { toStickerWire } from "@/lib/repo";

export const dynamic = "force-dynamic";

/** POST /api/stickers — import a sticker from an external app link or device upload. */
export const POST = route(async (req) => {
  const me = await requireUser();
  const b = await readBody<{
    label?: string;
    data?: string;
    source?: string;
    pack?: string;
  }>(req);

  const data = String(b.data ?? "").trim();
  if (!data) throw new HttpError(400, "Sticker source is empty");
  const isUrl = /^https?:\/\//i.test(data);
  const isDataUri = /^data:image\/(png|jpeg|jpg|webp|gif|svg\+xml);/i.test(data);
  if (!isUrl && !isDataUri) {
    throw new HttpError(400, "Paste an image URL or upload a PNG/WEBP/SVG");
  }
  if (isDataUri && data.length > 3_000_000) {
    throw new HttpError(413, "Sticker too heavy — keep it under ~2MB");
  }

  const [row] = await db
    .insert(stickers)
    .values({
      ownerId: me.id,
      pack: String(b.pack ?? "My Stickers").slice(0, 40),
      label: String(b.label ?? (isUrl ? "Linked sticker" : "Uploaded sticker")).slice(0, 40),
      source: isUrl ? "url" : "upload",
      data,
    })
    .returning();

  const wire = toStickerWire(row);
  broadcast({ type: "sticker", sticker: wire }, null);
  return json({ sticker: wire });
});

/** DELETE /api/stickers — remove one of *your* imported stickers. */
export const DELETE = route(async (req) => {
  const me = await requireUser();
  const b = await readBody<{ id?: number }>(req);
  const id = Number(b.id ?? 0);
  if (!id) throw new HttpError(400, "id is required");
  const rows = await db
    .delete(stickers)
    .where(and(eq(stickers.id, id), eq(stickers.ownerId, me.id)))
    .returning();
  if (!rows.length) throw new HttpError(404, "Sticker not found (or not yours)");

  broadcast({ type: "sticker:delete", id }, null);
  return json({ ok: true, id });
});
