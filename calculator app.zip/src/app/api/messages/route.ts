import { db } from "@/db";
import { messages } from "@/db/schema";
import { HttpError, json, readBody, requireUser, route, threadFor } from "@/lib/http";
import { broadcast } from "@/lib/realtime";
import { expiryFor, toMessageWire, touchConversation } from "@/lib/repo";
import type { MessageWire } from "@/lib/types";

export const dynamic = "force-dynamic";

const KINDS: MessageWire["kind"][] = ["text", "image", "sticker", "voice", "system"];
const MAX_MEDIA = 6_000_000;

/** POST /api/messages — send into one of the four-person threads. */
export const POST = route(async (req) => {
  const me = await requireUser();
  const b = await readBody<{
    conversationId?: number;
    kind?: string;
    body?: string;
    mediaData?: string | null;
    mediaMime?: string | null;
    mediaName?: string | null;
    stickerId?: string | null;
    replyToId?: number | null;
  }>(req);

  const conversationId = Number(b.conversationId ?? 0);
  if (!conversationId) throw new HttpError(400, "conversationId is required");
  const { conv, members } = await threadFor(me, conversationId);

  const kind = (KINDS.includes(b.kind as MessageWire["kind"]) ? b.kind : "text") as MessageWire["kind"];
  const body = String(b.body ?? "").slice(0, 4_000);
  const mediaData = typeof b.mediaData === "string" ? b.mediaData : null;
  if (mediaData && mediaData.length > MAX_MEDIA) {
    throw new HttpError(413, "Media too heavy — compress it and try again");
  }
  if (kind !== "image" && kind !== "sticker" && !body.trim()) {
    throw new HttpError(400, "Nothing to send");
  }

  const createdAt = new Date();
  const [row] = await db
    .insert(messages)
    .values({
      conversationId: conv.id,
      senderId: me.id,
      kind,
      body,
      mediaData,
      mediaMime: mediaData ? String(b.mediaMime ?? "image/jpeg") : null,
      mediaName: mediaData ? String(b.mediaName ?? "photo.jpg") : null,
      stickerId: b.stickerId ? String(b.stickerId) : null,
      replyToId: b.replyToId ? Number(b.replyToId) : null,
      status: "sent",
      expiresAt: expiryFor(createdAt),
      createdAt,
    })
    .returning();

  await touchConversation(conv.id, createdAt);

  const wire = toMessageWire(row);
  broadcast({ type: "message", conversationId: conv.id, message: wire }, members);
  return json({ message: wire });
});
