import { eq } from "drizzle-orm";
import { db } from "@/db";
import { messages, settings, stickers } from "@/db/schema";
import { DEMO_REPLIES } from "@/lib/config";
import { HttpError, json, readBody, requireUser, route, threadFor } from "@/lib/http";
import { broadcast } from "@/lib/realtime";
import { expiryFor, toMessageWire, touchConversation } from "@/lib/repo";

export const dynamic = "force-dynamic";

/**
 * POST /api/messages/simulate
 * Offline companion: makes one of the *other three* hardcoded users answer,
 * so a single-device demo still feels like a live four-person vault.
 * Controlled by the `demo_replies` setting (Settings → Simulator).
 */
export const POST = route(async (req) => {
  const me = await requireUser();
  const b = await readBody<{ conversationId?: number; replyToId?: number }>(req);
  const conversationId = Number(b.conversationId ?? 0);
  if (!conversationId) throw new HttpError(400, "conversationId is required");

  const flag = await db.select().from(settings).where(eq(settings.key, "demo_replies")).limit(1);
  if ((flag[0]?.value ?? "on") !== "on") throw new HttpError(409, "Simulator is off");

  const { conv, members } = await threadFor(me, conversationId);
  const others = members.filter((id) => id !== me.id);
  if (!others.length) throw new HttpError(409, "Nobody else in this thread");

  const senderId = others[Math.floor(Math.random() * others.length)];
  const body = DEMO_REPLIES[Math.floor(Math.random() * DEMO_REPLIES.length)];
  const wantsSticker = Math.random() < 0.22;

  const createdAt = new Date();
  let stickerId: string | null = null;
  if (wantsSticker) {
    const pool = await db.select().from(stickers).orderBy(stickers.id);
    if (pool.length) {
      stickerId = String(pool[Math.floor(Math.random() * pool.length)].id);
    }
  }

  const [row] = await db
    .insert(messages)
    .values({
      conversationId: conv.id,
      senderId,
      kind: stickerId ? "sticker" : "text",
      body: stickerId ? "" : body,
      stickerId,
      replyToId: b.replyToId ? Number(b.replyToId) : null,
      status: "delivered",
      simulated: 1,
      expiresAt: expiryFor(createdAt),
      createdAt,
    })
    .returning();

  await touchConversation(conv.id, createdAt);

  const wire = toMessageWire(row);
  broadcast({ type: "message", conversationId: conv.id, message: wire }, members);
  return json({ message: wire });
});
