import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { messages } from "@/db/schema";
import { HttpError, json, requireUser, route } from "@/lib/http";
import { broadcast } from "@/lib/realtime";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

/** DELETE /api/messages/:id — "Delete for everyone" inside the vault. */
export const DELETE = route(async (req, ctx: Ctx) => {
  const me = await requireUser();
  const { id } = await ctx.params;
  const messageId = Number(id);
  if (!messageId) throw new HttpError(400, "Bad message id");

  const rows = await db
    .delete(messages)
    .where(and(eq(messages.id, messageId), eq(messages.senderId, me.id)))
    .returning();
  if (!rows.length) throw new HttpError(404, "Message not found (or not yours)");

  broadcast(
    { type: "message:delete", conversationId: rows[0].conversationId, id: messageId },
    null,
  );
  return json({ ok: true, id: messageId });
});
