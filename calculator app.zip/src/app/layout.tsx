import type { Metadata, Viewport } from "next";
import { Chakra_Petch, JetBrains_Mono, Manrope } from "next/font/google";
import type { ReactNode } from "react";
import "./globals.css";

const chakra = Chakra_Petch({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-chakra",
  display: "swap",
});

const manrope = Manrope({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800"],
  variable: "--font-manrope",
  display: "swap",
});

const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["200", "300", "400", "500", "700"],
  variable: "--font-jetbrains",
  display: "swap",
});

/* Deliberately boring metadata — the cover story must hold up. */
export const metadata: Metadata = {
  title: "Hustler Calculator",
  description:
    "A fast, precise calculator with expression history, percentage math and a glowing display. Works offline on phones and tablets.",
  applicationName: "Hustler Calculator",
  keywords: ["calculator", "math", "percentage", "history"],
};

export const viewport: Viewport = {
  themeColor: "#080b0c",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="en"
      className={`${chakra.variable} ${manrope.variable} ${jetbrains.variable}`}
    >
      <body className="bg-graphite-950 font-sans text-mint-text antialiased">
        {children}
      </body>
    </html>
  );
}
