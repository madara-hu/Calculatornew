"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import Calculator from "@/components/calculator/Calculator";
import VaultLogin from "@/components/vault/VaultLogin";
import VaultApp from "@/components/vault/VaultApp";
import { Auth } from "@/lib/client";
import { VaultProvider } from "@/lib/vault-store";
import type { RosterUser, UserWire } from "@/lib/types";

type Phase = "cover" | "login" | "vault";

/**
 * The stealth state machine.
 * The app ALWAYS boots to the calculator — even with a live session — so a
 * bystander never sees anything but a calculator. The secret expression
 * `74 + 88 =` is the only door in.
 */
export default function AppShell() {
  const [phase, setPhase] = useState<Phase>("cover");
  const [me, setMe] = useState<UserWire | null>(null);
  const [roster, setRoster] = useState<RosterUser[]>([]);

  useEffect(() => {
    let alive = true;
    Auth.me()
      .then((res) => {
        if (!alive) return;
        setRoster(res.roster ?? []);
        if (res.me) setMe(res.me);
      })
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, []);

  const unlock = () => setPhase(me ? "vault" : "login");

  return (
    <main className="relative min-h-dvh w-full overflow-hidden bg-graphite-950">
      <AnimatePresence mode="wait">
        {phase === "cover" && (
          <motion.div
            key="cover"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 1.04, filter: "blur(10px)" }}
            transition={{ duration: 0.34, ease: [0.22, 1, 0.36, 1] }}
            className="min-h-dvh"
          >
            <Calculator onUnlock={unlock} />
          </motion.div>
        )}

        {phase === "login" && (
          <motion.div
            key="login"
            initial={{ opacity: 0, scale: 0.96, filter: "blur(12px)" }}
            animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
            exit={{ opacity: 0, scale: 1.05, filter: "blur(14px)" }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            className="min-h-dvh"
          >
            <VaultLogin
              roster={roster}
              onSuccess={(user) => {
                setMe(user);
                setPhase("vault");
              }}
              onBack={() => setPhase("cover")}
            />
          </motion.div>
        )}

        {phase === "vault" && me && (
          <motion.div
            key="vault"
            initial={{ opacity: 0, y: 26, filter: "blur(14px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            exit={{ opacity: 0, scale: 0.97, filter: "blur(10px)" }}
            transition={{ duration: 0.42, ease: [0.22, 1, 0.36, 1] }}
            className="h-dvh"
          >
            <VaultProvider me={me}>
              <VaultApp me={me} />
            </VaultProvider>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
