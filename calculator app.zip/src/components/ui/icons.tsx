import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement> & { size?: number };

function S({ size = 22, children, ...rest }: P) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      {...rest}
    >
      {children}
    </svg>
  );
}

export const IconHistory = (p: P) => (
  <S {...p}>
    <path d="M3.5 9A9 9 0 1 1 3 12" />
    <path d="M3 4.5V9h4.5" />
    <path d="M12 7.5V12l3 1.8" />
  </S>
);

export const IconBackspace = (p: P) => (
  <S {...p}>
    <path d="M8.5 5h11a1.5 1.5 0 0 1 1.5 1.5v11A1.5 1.5 0 0 1 19.5 19h-11L3 12z" />
    <path d="M12 9.5l5 5M17 9.5l-5 5" />
  </S>
);

export const IconTrash = (p: P) => (
  <S {...p}>
    <path d="M4 7h16M9.5 7V4.8h5V7M6.5 7l.9 12.2a1.6 1.6 0 0 0 1.6 1.5h6a1.6 1.6 0 0 0 1.6-1.5L17.5 7" />
    <path d="M10.5 11v6M13.5 11v6" />
  </S>
);

export const IconLock = (p: P) => (
  <S {...p}>
    <rect x="4.5" y="10" width="15" height="10.5" rx="2.5" />
    <path d="M8 10V7.2a4 4 0 0 1 8 0V10" />
    <circle cx="12" cy="15.2" r="1.4" fill="currentColor" stroke="none" />
  </S>
);

export const IconChats = (p: P) => (
  <S {...p}>
    <path d="M3.5 6.4A2.4 2.4 0 0 1 5.9 4h8.7a2.4 2.4 0 0 1 2.4 2.4v5.2a2.4 2.4 0 0 1-2.4 2.4H8.9L5 17.4v-3.4a2.4 2.4 0 0 1-1.5-2.2z" />
    <path d="M18.6 8.4h.9A2.4 2.4 0 0 1 22 10.8v5.6a2.4 2.4 0 0 1-2.4 2.4H19v2.6l-3.4-2.6h-3.4" />
  </S>
);

export const IconPhone = (p: P) => (
  <S {...p}>
    <path d="M6.2 3.5h3l1.4 3.6-2 1.4a12 12 0 0 0 5.9 5.9l1.4-2 3.6 1.4v3a2 2 0 0 1-2.2 2A16.6 16.6 0 0 1 4.2 5.7a2 2 0 0 1 2-2.2z" />
  </S>
);

export const IconCallEnd = (p: P) => (
  <S {...p}>
    <path d="M3.4 13.6c4.6-4 12.6-4 17.2 0l1-2.4c-4.9-4.3-14.5-4.3-19.2 0z" />
    <path d="M4.6 14.4 3 17.6l3.4 1 1-2.6zM19.4 14.4 21 17.6l-3.4 1-1-2.6z" />
  </S>
);

export const IconVideo = (p: P) => (
  <S {...p}>
    <rect x="2.8" y="6" width="12.6" height="12" rx="2.6" />
    <path d="M15.4 11l5.8-3.6v9.2L15.4 13z" />
  </S>
);

export const IconVideoOff = (p: P) => (
  <S {...p}>
    <path d="M15.4 11l5.8-3.6v9.2L17 14.4" />
    <path d="M13.6 6.2H5.4A2.6 2.6 0 0 0 2.8 8.8v6.4a2.6 2.6 0 0 0 2.6 2.6h7.6" />
    <path d="M3 3l18 18" />
  </S>
);

export const IconSticker = (p: P) => (
  <S {...p}>
    <path d="M20.5 12.4V6.2A2.7 2.7 0 0 0 17.8 3.5H6.2A2.7 2.7 0 0 0 3.5 6.2v11.6a2.7 2.7 0 0 0 2.7 2.7h6.2z" />
    <path d="M20.5 12.4h-5.3a2.7 2.7 0 0 0-2.8 2.7v5.4" />
    <path d="M8.4 9.2h.01M13 9.2h.01M8.6 12.8c1 1 2.6 1.4 3.8.6" />
  </S>
);

export const IconGear = (p: P) => (
  <S {...p}>
    <circle cx="12" cy="12" r="3.1" />
    <path d="M19.6 14.2a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.1v.2a2 2 0 1 1-4 0v-.1a1.6 1.6 0 0 0-2.8-1.1l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0-1.1-2.7H3.6a2 2 0 1 1 0-4h.1a1.6 1.6 0 0 0 1.1-2.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 2.7-1.1V3.6a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 2.8 1.1l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0 1.1 2.7h.2a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z" />
  </S>
);

export const IconCamera = (p: P) => (
  <S {...p}>
    <path d="M3.5 8.8A2.3 2.3 0 0 1 5.8 6.5h1.6l1.3-2h6.6l1.3 2h1.6a2.3 2.3 0 0 1 2.3 2.3v8a2.3 2.3 0 0 1-2.3 2.3H5.8a2.3 2.3 0 0 1-2.3-2.3z" />
    <circle cx="12" cy="12.8" r="3.4" />
  </S>
);

export const IconImage = (p: P) => (
  <S {...p}>
    <rect x="3.2" y="4.6" width="17.6" height="14.8" rx="2.6" />
    <circle cx="8.6" cy="9.8" r="1.6" />
    <path d="M4 17l4.6-4.4 3.4 3 3-2.6L20 17" />
  </S>
);

export const IconMic = (p: P) => (
  <S {...p}>
    <rect x="9.2" y="2.8" width="5.6" height="10.4" rx="2.8" />
    <path d="M5.6 11.4a6.4 6.4 0 0 0 12.8 0M12 17.8v3.4M8.8 21.2h6.4" />
  </S>
);

export const IconMicOff = (p: P) => (
  <S {...p}>
    <path d="M14.8 5.6v5.6a2.8 2.8 0 0 1-4.5 2.2M9.2 8.2V5.6a2.8 2.8 0 0 1 5.3-1.2" />
    <path d="M5.6 11.4a6.4 6.4 0 0 0 9.9 5.5M18.4 11.4v.8M12 17.8v3.4M8.8 21.2h6.4M3 3l18 18" />
  </S>
);

export const IconSpeaker = (p: P) => (
  <S {...p}>
    <rect x="5.6" y="2.8" width="12.8" height="18.4" rx="3" />
    <circle cx="12" cy="15.4" r="3" />
    <path d="M10 6.6h4" />
  </S>
);

export const IconFlip = (p: P) => (
  <S {...p}>
    <path d="M4 8.4A8 8 0 0 1 18.4 6.2L21 8.4" />
    <path d="M21 4v4.4h-4.4" />
    <path d="M20 15.6A8 8 0 0 1 5.6 17.8L3 15.6" />
    <path d="M3 20v-4.4h4.4" />
  </S>
);

export const IconSend = (p: P) => (
  <S {...p}>
    <path d="M21 3 10.6 13.4" />
    <path d="M21 3l-6.8 18-3.6-7.6L3 9.8z" />
  </S>
);

export const IconAttach = (p: P) => (
  <S {...p}>
    <path d="M20 11.4 12.3 19a4.7 4.7 0 0 1-6.7-6.6l7.9-7.8a3.1 3.1 0 1 1 4.4 4.4l-7.8 7.8a1.6 1.6 0 0 1-2.2-2.2l7.2-7.1" />
  </S>
);

export const IconSmile = (p: P) => (
  <S {...p}>
    <circle cx="12" cy="12" r="8.8" />
    <path d="M8.6 14.2a4.4 4.4 0 0 0 6.8 0" />
    <path d="M9.2 9.4h.01M14.8 9.4h.01" strokeWidth={2.6} />
  </S>
);

export const IconSearch = (p: P) => (
  <S {...p}>
    <circle cx="10.8" cy="10.8" r="6.6" />
    <path d="M15.8 15.8 21 21" />
  </S>
);

export const IconCheck = (p: P) => (
  <S {...p} strokeWidth={2.2}>
    <path d="M4.5 12.8 9 17 19.5 6.5" />
  </S>
);

export const IconChecks = (p: P) => (
  <S {...p} strokeWidth={2.1}>
    <path d="M2 12.8 6.2 17 15.6 7" />
    <path d="M9.4 15.4 11.6 17.4 21.4 6.8" />
  </S>
);

export const IconPlus = (p: P) => (
  <S {...p} strokeWidth={2}>
    <path d="M12 5v14M5 12h14" />
  </S>
);

export const IconClose = (p: P) => (
  <S {...p} strokeWidth={2}>
    <path d="M5.5 5.5l13 13M18.5 5.5l-13 13" />
  </S>
);

export const IconChevronLeft = (p: P) => (
  <S {...p} strokeWidth={2}>
    <path d="M14.5 5 8 12l6.5 7" />
  </S>
);

export const IconChevronRight = (p: P) => (
  <S {...p} strokeWidth={2}>
    <path d="M9.5 5 16 12l-6.5 7" />
  </S>
);

export const IconLogout = (p: P) => (
  <S {...p}>
    <path d="M14.5 4.5H6.8A2.3 2.3 0 0 0 4.5 6.8v10.4a2.3 2.3 0 0 0 2.3 2.3h7.7" />
    <path d="M16.5 8.5 20 12l-3.5 3.5M20 12H9.6" />
  </S>
);

export const IconShield = (p: P) => (
  <S {...p}>
    <path d="M12 3 5 5.8v5.4c0 4.3 2.9 8.2 7 9.4 4.1-1.2 7-5.1 7-9.4V5.8z" />
    <path d="M9.2 12.2l2 2 3.6-3.9" />
  </S>
);

export const IconFlame = (p: P) => (
  <S {...p}>
    <path d="M12 3c3.4 3.6 6 6 6 9.4A6 6 0 0 1 6 12.6c0-1.9.9-3.2 2.2-4.6.4 1.4 1.2 2.2 2.2 2.2 0-2.6-.2-4.4 1.6-7.2z" />
  </S>
);

export const IconLink = (p: P) => (
  <S {...p}>
    <path d="M10.4 13.6a3.6 3.6 0 0 0 5.2 0l2.8-2.8a3.7 3.7 0 0 0-5.2-5.2l-1.4 1.4" />
    <path d="M13.6 10.4a3.6 3.6 0 0 0-5.2 0l-2.8 2.8a3.7 3.7 0 0 0 5.2 5.2l1.4-1.4" />
  </S>
);

export const IconDots = (p: P) => (
  <S {...p} strokeWidth={0} fill="currentColor">
    <circle cx="12" cy="5.4" r="1.7" />
    <circle cx="12" cy="12" r="1.7" />
    <circle cx="12" cy="18.6" r="1.7" />
  </S>
);

export const IconUsers = (p: P) => (
  <S {...p}>
    <circle cx="9.4" cy="8.6" r="3.4" />
    <path d="M3.4 19.4c.6-3.2 3-5 6-5s5.4 1.8 6 5" />
    <path d="M16.4 5.6a3.2 3.2 0 0 1 0 6.2M17.6 14.8c2.2.5 3.6 2.2 4 4.6" />
  </S>
);

export const IconKeyboard = (p: P) => (
  <S {...p}>
    <rect x="2.6" y="6" width="18.8" height="12" rx="2.4" />
    <path d="M6.4 9.6h.01M9.6 9.6h.01M12.8 9.6h.01M16 9.6h.01M6.4 12.8h.01M9.6 12.8h.01M12.8 12.8h.01M16 12.8h.01" strokeWidth={2.4} />
    <path d="M8.4 15.6h7.2" />
  </S>
);

export const IconDownload = (p: P) => (
  <S {...p}>
    <path d="M12 3.6v11M7.8 10.6 12 14.8l4.2-4.2" />
    <path d="M4.4 17.4v1.4a1.8 1.8 0 0 0 1.8 1.8h11.6a1.8 1.8 0 0 0 1.8-1.8v-1.4" />
  </S>
);

export const IconBolt = (p: P) => (
  <S {...p}>
    <path d="M13.6 2.6 5.4 13.4h5.2L9.8 21.4l8.4-11.2h-5.4z" />
  </S>
);

export const IconEye = (p: P) => (
  <S {...p}>
    <path d="M2.6 12S6 6.2 12 6.2 21.4 12 21.4 12 18 17.8 12 17.8 2.6 12 2.6 12z" />
    <circle cx="12" cy="12" r="2.9" />
  </S>
);
