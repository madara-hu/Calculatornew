import { motion } from "framer-motion";
import type { UserWire } from "@/lib/types";

const initials = (name: string) =>
  name
    .replace(/[._\-]+/g, " ")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((n) => n[0]?.toUpperCase() ?? "")
    .join("");

export function Avatar({
  user,
  size = 48,
  ring = false,
  presence = false,
  group = false,
  title,
  className = "",
}: {
  user?: Pick<UserWire, "name" | "hue"> | null;
  size?: number;
  ring?: boolean;
  presence?: boolean;
  group?: boolean;
  title?: string;
  className?: string;
}) {
  const hue = user?.hue ?? 160;
  const label = title ?? user?.name ?? "?";
  const bg = group
    ? `linear-gradient(140deg, hsl(${hue} 62% 34%), hsl(${(hue + 42) % 360} 58% 18%))`
    : `linear-gradient(145deg, hsl(${hue} 72% 46%), hsl(${(hue + 28) % 360} 68% 26%))`;

  return (
    <span className={`relative inline-flex shrink-0 ${className}`} style={{ width: size, height: size }}>
      <motion.span
        layout="position"
        className="grid place-items-center overflow-hidden rounded-full"
        style={{
          width: size,
          height: size,
          background: bg,
          boxShadow: ring
            ? `0 0 0 2px hsl(${hue} 80% 60% / .55), 0 0 18px -2px hsl(${hue} 80% 55% / .6)`
            : `inset 0 1px 0 hsl(${hue} 90% 80% / .28), 0 6px 14px -8px #000`,
          fontFamily: "var(--font-display)",
          fontSize: Math.max(11, size * 0.36),
          fontWeight: 600,
          letterSpacing: "0.02em",
          color: `hsl(${hue} 60% 96%)`,
          textShadow: "0 1px 2px rgba(0,0,0,.45)",
        }}
      >
        {initials(label)}
      </motion.span>
      {presence && (
        <span
          className="absolute bottom-0 right-0 rounded-full border-2 border-vault-900 bg-jade-400"
          style={{
            width: Math.max(9, size * 0.26),
            height: Math.max(9, size * 0.26),
            boxShadow: "0 0 10px rgba(37,211,102,.9)",
          }}
        />
      )}
    </span>
  );
}
