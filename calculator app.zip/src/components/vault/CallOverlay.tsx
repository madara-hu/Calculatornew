"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { Avatar } from "@/components/ui/Avatar";
import {
  IconCallEnd,
  IconFlip,
  IconMic,
  IconMicOff,
  IconPhone,
  IconSpeaker,
  IconVideo,
  IconVideoOff,
} from "@/components/ui/icons";
import { haptic } from "@/lib/client";
import { durationLabel } from "@/lib/format";
import { useVault, type ActiveCall } from "@/lib/vault-store";

/**
 * >>> LIVE MEDIA INSERTION POINT
 * The self-view below uses the browser camera. Swap `getUserMedia` for a
 * WebRTC / Agora / Zegocloud track and render the remote peer into the
 * `remoteRef` element — every control below is already wired to state.
 */
export default function CallOverlay({ call }: { call: ActiveCall }) {
  const { userById, titleFor, threads, answerCall, declineCall, endCall } = useVault();
  const conv = threads.find((c) => c.id === call.conversationId);
  const partner = userById(call.partnerIds[0]);
  const name = conv?.kind === "group" ? titleFor(conv) : (partner?.name ?? "Unknown");
  const hue = partner?.hue ?? 158;

  const [muted, setMuted] = useState(false);
  const [speaker, setSpeaker] = useState(call.kind === "audio");
  const [cameraOn, setCameraOn] = useState(call.kind === "video");
  const [facing, setFacing] = useState<"user" | "environment">("user");
  const [seconds, setSeconds] = useState(0);
  const [mediaError, setMediaError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  /* outgoing calls are "answered" by the simulator after a few rings */
  useEffect(() => {
    if (call.direction !== "outgoing" || call.phase !== "ringing") return;
    const t = window.setTimeout(() => {
      haptic([24, 60, 24]);
      answerCall();
    }, 3200 + Math.random() * 1800);
    return () => window.clearTimeout(t);
  }, [call.direction, call.phase, answerCall]);

  /* incoming calls time out as "missed" */
  useEffect(() => {
    if (call.direction !== "incoming" || call.phase !== "ringing") return;
    const t = window.setTimeout(() => void endCall("missed"), 22_000);
    return () => window.clearTimeout(t);
  }, [call.direction, call.phase, endCall]);

  useEffect(() => {
    if (call.phase !== "connected") return;
    const t = window.setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => window.clearInterval(t);
  }, [call.phase]);

  useEffect(() => {
    if (!cameraOn || call.phase !== "connected") {
      streamRef.current?.getTracks().forEach((tr) => tr.stop());
      streamRef.current = null;
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: facing },
          audio: false,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => undefined);
        }
        setMediaError(null);
      } catch {
        if (!cancelled) setMediaError("Camera unavailable — showing avatar feed");
      }
    })();
    return () => {
      cancelled = true;
      streamRef.current?.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    };
  }, [cameraOn, facing, call.phase]);

  const ringing = call.phase === "ringing";
  const connected = call.phase === "connected";

  const controls = [
    {
      key: "mute",
      label: muted ? "Unmute" : "Mute",
      icon: muted ? <IconMicOff size={20} /> : <IconMic size={20} />,
      active: muted,
      hidden: false,
      fn: () => setMuted((m) => !m),
    },
    {
      key: "video",
      label: cameraOn ? "Cam off" : "Cam on",
      icon: cameraOn ? <IconVideo size={20} /> : <IconVideoOff size={20} />,
      active: !cameraOn,
      hidden: false,
      fn: () => setCameraOn((c) => !c),
    },
    {
      key: "flip",
      label: "Flip",
      icon: <IconFlip size={20} />,
      active: false,
      hidden: !cameraOn,
      fn: () => setFacing((f) => (f === "user" ? "environment" : "user")),
    },
    {
      key: "speaker",
      label: speaker ? "Speaker on" : "Speaker",
      icon: <IconSpeaker size={20} />,
      active: speaker,
      hidden: false,
      fn: () => setSpeaker((s) => !s),
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[80] overflow-hidden bg-vault-950"
    >
      {/* remote frame */}
      <div
        className="absolute inset-0 transition-opacity duration-500"
        style={{
          opacity: cameraOn && connected ? 0.28 : 1,
          background: `radial-gradient(120% 90% at 50% 0%, hsl(${hue} 48% 22%) 0%, #050b0e 62%), linear-gradient(180deg,#071116 0%, #04090b 100%)`,
        }}
      />
      {connected && (
        <div className="pointer-events-none absolute inset-0 opacity-45">
          <motion.div
            animate={{ y: [0, -14, 0], opacity: [0.25, 0.5, 0.25] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -top-24 left-1/2 h-80 w-80 -translate-x-1/2 rounded-full blur-3xl"
            style={{ background: `hsl(${hue} 70% 45% / .35)` }}
          />
        </div>
      )}

      {/* self view (PiP) */}
      <AnimatePresence>
        {cameraOn && connected && (
          <motion.div
            initial={{ opacity: 0, scale: 0.85, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="absolute right-4 top-20 h-[190px] w-[132px] overflow-hidden rounded-3xl border border-white/15 bg-vault-900 shadow-2xl sm:right-8 sm:h-[240px] sm:w-[168px]"
          >
            <video ref={videoRef} muted playsInline className="h-full w-full object-cover" />
            {mediaError && (
              <div className="absolute inset-0 grid place-items-center bg-vault-900/90 px-3 text-center">
                <p className="font-mono text-[10.5px] leading-relaxed text-vault-muted">{mediaError}</p>
              </div>
            )}
            <span className="absolute bottom-2 left-2 rounded-full bg-black/55 px-2 py-0.5 font-mono text-[9.5px] tracking-[0.12em] text-white/80 uppercase">
              you · {facing === "user" ? "front" : "rear"}
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* top bar */}
      <div className="absolute inset-x-0 top-0 flex items-start justify-between p-5">
        <div>
          <p className="font-mono text-[10.5px] tracking-[0.24em] text-white/55 uppercase">
            {call.kind === "video" ? "encrypted video call" : "encrypted voice call"}
          </p>
          <AnimatePresence mode="wait">
            <motion.p
              key={ringing ? "ring" : "live"}
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 6 }}
              className={[
                "mt-1 font-mono text-[13px]",
                ringing ? "text-amber-glow" : "text-jade-300",
              ].join(" ")}
            >
              {ringing
                ? call.direction === "incoming"
                  ? "Incoming call…"
                  : "Ringing…"
                : durationLabel(seconds)}
            </motion.p>
          </AnimatePresence>
        </div>
        <span className="flex items-center gap-1.5 rounded-full border border-white/12 bg-black/35 px-3 py-1.5 font-mono text-[10px] tracking-[0.16em] text-white/70 uppercase backdrop-blur">
          <span className={`h-1.5 w-1.5 rounded-full ${connected ? "bg-jade-400" : "bg-amber-glow"} animate-pulse`} />
          {connected ? "live" : "handshake"}
        </span>
      </div>

      {/* centre identity */}
      <div className="absolute inset-0 grid place-items-center px-6">
        <div className="flex flex-col items-center">
          <div className="relative grid place-items-center">
            {ringing && (
              <>
                <span className="animate-pulsering absolute h-40 w-40 rounded-full border border-white/20" />
                <span className="animate-pulsering absolute h-40 w-40 rounded-full border border-white/12 [animation-delay:.6s]" />
              </>
            )}
            <motion.div
              animate={connected ? { scale: [1, 1.03, 1] } : {}}
              transition={{ duration: 2.6, repeat: Infinity, ease: "easeInOut" }}
              className="animate-floaty"
            >
              <Avatar user={partner ?? { name, hue }} title={name} size={128} ring />
            </motion.div>
          </div>
          <h2 className="mt-6 font-display text-[30px] font-semibold text-white drop-shadow">{name}</h2>
          <p className="mt-1 font-mono text-[11.5px] tracking-[0.18em] text-white/50 uppercase">
            {partner?.role ?? "Inner circle"} · {conv?.kind === "group" ? "group line" : "direct line"}
          </p>

          {connected && (
            <div className="mt-6 flex h-10 items-end gap-[4px]">
              {Array.from({ length: 22 }, (_, i) => (
                <span
                  key={i}
                  className="w-[3px] rounded-full bg-jade-300/70"
                  style={{
                    height: `${20 + ((i * 41) % 70)}%`,
                    animation: muted ? undefined : `wavebar ${0.9 + (i % 5) * 0.12}s ease-in-out ${i * 0.05}s infinite`,
                  }}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* bottom controls */}
      <div className="absolute inset-x-0 bottom-0 flex flex-col items-center gap-6 p-7">
        {ringing && call.direction === "incoming" ? (
          <div className="flex w-full max-w-[320px] items-center justify-between">
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => void declineCall()}
              className="grid h-[70px] w-[70px] place-items-center rounded-full bg-red-500/90 text-white shadow-[0_0_36px_-6px_rgba(239,68,68,.9)]"
              aria-label="Decline call"
            >
              <IconCallEnd size={28} />
            </motion.button>
            <span className="font-mono text-[10.5px] tracking-[0.2em] text-white/50 uppercase">
              tap to answer
            </span>
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => {
                haptic([18, 40, 18]);
                answerCall();
              }}
              className="jade-glow grid h-[70px] w-[70px] place-items-center rounded-full bg-jade-500 text-vault-950"
              aria-label="Answer call"
            >
              {call.kind === "video" ? <IconVideo size={28} /> : <IconPhone size={28} />}
            </motion.button>
          </div>
        ) : (
          <div className="flex items-center gap-3.5">
            {controls
              .filter((c) => !c.hidden)
              .map((c) => (
                <motion.button
                  key={c.key}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => {
                    haptic(9);
                    c.fn();
                  }}
                  className={[
                    "grid h-[58px] w-[58px] place-items-center rounded-full border backdrop-blur transition",
                    c.active
                      ? "border-white/25 bg-white text-vault-950"
                      : "border-white/14 bg-white/8 text-white hover:bg-white/16",
                  ].join(" ")}
                  aria-label={c.label}
                >
                  {c.icon}
                </motion.button>
              ))}
            <motion.button
              whileTap={{ scale: 0.88 }}
              onClick={() => void endCall(connected ? "completed" : call.direction === "incoming" ? "declined" : "missed")}
              className="grid h-[70px] w-[70px] place-items-center rounded-full bg-red-500 text-white shadow-[0_0_40px_-6px_rgba(239,68,68,.95)]"
              aria-label="End call"
            >
              <IconCallEnd size={30} />
            </motion.button>
          </div>
        )}
        <p className="font-mono text-[10px] tracking-[0.18em] text-white/35 uppercase">
          {muted ? "microphone muted" : "microphone live"} · {speaker ? "speaker" : "earpiece"} ·{" "}
          {cameraOn ? "camera on" : "camera off"}
        </p>
      </div>
    </motion.div>
  );
}
