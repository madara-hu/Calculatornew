"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useMemo, useState } from "react";
import { Avatar } from "@/components/ui/Avatar";
import { IconCamera, IconChecks, IconFlame, IconMic, IconSearch, IconSticker, IconUsers } from "@/components/ui/icons";
import { haptic } from "@/lib/client";
import { relativeTime, ttlLabel } from "@/lib/format";
import { useVault } from "@/lib/vault-store";
import type { ConversationWire, MessageWire } from "@/lib/types";

type Filter = "all" | "unread" | "group";

export default function ChatList({ onOpen }: { onOpen: (id: number) => void }) {
  const { threads, messagesIn, titleFor, unreadIn, typingIn, me, alive, burned, purgeHours, othersIn } =
    useVault();
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<Filter>("all");

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return threads
      .map((conv) => {
        const list = messagesIn(conv.id);
        const last = list[list.length - 1] ?? null;
        return { conv, last, unread: unreadIn(conv.id) };
      })
      .filter(({ conv, last }) => {
        if (filter === "unread" && unreadIn(conv.id) === 0) return false;
        if (filter === "group" && conv.kind !== "group") return false;
        if (!q) return true;
        return (
          titleFor(conv).toLowerCase().includes(q) || (last?.body ?? "").toLowerCase().includes(q)
        );
      })
      .sort((a, b) => {
        const at = a.last ? new Date(a.last.createdAt).getTime() : new Date(a.conv.lastMessageAt).getTime();
        const bt = b.last ? new Date(b.last.createdAt).getTime() : new Date(b.conv.lastMessageAt).getTime();
        return bt - at;
      });
  }, [threads, messagesIn, titleFor, unreadIn, filter, query]);

  return (
    <div className="flex h-full flex-col">
      {/* purge telemetry strip */}
      <div className="mx-4 mt-4 flex items-center gap-3 rounded-2xl border border-jade-500/18 bg-jade-500/6 px-3.5 py-2.5">
        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-jade-500/15 text-jade-300">
          <IconFlame size={16} />
        </span>
        <div className="min-w-0 flex-1">
          <p className="font-mono text-[11.5px] text-jade-300/90">
            {alive} live message{alive === 1 ? "" : "s"} · {burned} burned
          </p>
          <p className="truncate text-[11px] text-vault-muted">
            Auto-purge sweeps every sync · TTL {purgeHours}h
          </p>
        </div>
        <span className="hidden shrink-0 items-center gap-1.5 rounded-full border border-white/8 px-2 py-1 font-mono text-[10px] tracking-[0.14em] text-vault-muted uppercase sm:flex">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-jade-400" /> live
        </span>
      </div>

      {/* search + filters */}
      <div className="px-4 pt-3.5">
        <div className="flex items-center gap-2 rounded-2xl border border-white/8 bg-vault-800/70 px-3.5 py-2.5 focus-within:border-jade-500/40">
          <IconSearch size={16} className="text-vault-muted" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search threads and text"
            className="w-full bg-transparent text-[13.5px] text-vault-text placeholder:text-vault-muted/60 focus:outline-none"
          />
          {query && (
            <button onClick={() => setQuery("")} className="font-mono text-[11px] text-vault-muted hover:text-jade-300">
              clear
            </button>
          )}
        </div>
        <div className="mt-2.5 flex gap-2">
          {(["all", "unread", "group"] as Filter[]).map((f) => (
            <button
              key={f}
              onClick={() => {
                haptic(7);
                setFilter(f);
              }}
              className={[
                "rounded-full border px-3 py-1.5 font-mono text-[10.5px] tracking-[0.14em] uppercase transition",
                filter === f
                  ? "border-jade-500/50 bg-jade-500/15 text-jade-300"
                  : "border-white/8 text-vault-muted hover:border-white/20 hover:text-vault-text",
              ].join(" ")}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* thread rows */}
      <div className="scroll-thin mt-2 flex-1 overflow-y-auto px-2 pb-6">
        {rows.length === 0 && (
          <p className="px-6 py-10 text-center text-[13px] text-vault-muted">
            Nothing matches. The vault is quiet.
          </p>
        )}
        {rows.map(({ conv, last, unread }, index) => {
          const typing = typingIn.includes(conv.id);
          return (
            <motion.button
              key={conv.id}
              layout
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: Math.min(index * 0.035, 0.3), type: "spring", stiffness: 260, damping: 26 }}
              whileTap={{ scale: 0.985 }}
              onClick={() => {
                haptic(9);
                onOpen(conv.id);
              }}
              className="relative flex w-full items-center gap-3.5 rounded-2xl px-3 py-3 text-left transition hover:bg-white/4"
            >
              <div className="relative">
                <Avatar
                  user={conv.kind === "group" ? { name: titleFor(conv), hue: 158 } : othersIn(conv)[0]}
                  title={conv.kind === "group" ? undefined : titleFor(conv)}
                  group={conv.kind === "group"}
                  size={52}
                  presence={conv.kind === "dm"}
                />
                {conv.kind === "group" && (
                  <span className="absolute -bottom-0.5 -right-0.5 grid h-5 w-5 place-items-center rounded-full border border-vault-900 bg-vault-700 text-jade-300">
                    <IconUsers size={11} />
                  </span>
                )}
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex items-baseline gap-2">
                  <span className="truncate font-display text-[15.5px] font-semibold text-vault-text">
                    {titleFor(conv)}
                  </span>
                  <span className="ml-auto shrink-0 font-mono text-[10.5px] text-vault-muted">
                    {last ? relativeTime(last.createdAt) : "—"}
                  </span>
                </div>
                <div className="mt-0.5 flex items-center gap-1.5">
                  {typing ? (
                    <span className="flex items-center gap-1 font-mono text-[12px] text-jade-300">
                      typing
                      <span className="typing-dot h-1 w-1 rounded-full bg-jade-300" />
                      <span className="typing-dot h-1 w-1 rounded-full bg-jade-300 [animation-delay:.15s]" />
                      <span className="typing-dot h-1 w-1 rounded-full bg-jade-300 [animation-delay:.3s]" />
                    </span>
                  ) : (
                    <>
                      {last?.senderId === me.id && <Ticks status={last.status} />}
                      <span className="truncate text-[12.5px] text-vault-muted">
                        {last ? preview(last, conv, me.id) : "No messages in the last 48h — thread is clean"}
                      </span>
                    </>
                  )}
                  {unread > 0 && (
                    <motion.span
                      initial={{ scale: 0.5 }}
                      animate={{ scale: 1 }}
                      className="jade-glow ml-auto grid h-5 min-w-5 shrink-0 place-items-center rounded-full bg-jade-500 px-1.5 font-mono text-[10.5px] font-bold text-vault-950"
                    >
                      {unread}
                    </motion.span>
                  )}
                </div>
                {last && (
                  <div className="mt-1.5 flex items-center gap-1.5">
                    <span className="h-1 flex-1 overflow-hidden rounded-full bg-white/6">
                      <motion.span
                        className="block h-full rounded-full bg-gradient-to-r from-jade-600 to-jade-400"
                        initial={{ width: "100%" }}
                        animate={{
                          width: `${Math.max(
                            4,
                            Math.min(
                              100,
                              ((new Date(last.expiresAt).getTime() - Date.now()) /
                                (purgeHours * 3_600_000)) *
                                100,
                            ),
                          )}%`,
                        }}
                        transition={{ duration: 0.6 }}
                      />
                    </span>
                    <span className="font-mono text-[9.5px] tracking-[0.1em] text-vault-muted/70 uppercase">
                      {ttlLabel(last.expiresAt)} left
                    </span>
                  </div>
                )}
              </div>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}

function Ticks({ status }: { status: MessageWire["status"] }) {
  if (status === "sent")
    return <IconChecks size={14} className="shrink-0 text-vault-muted/70" style={{ opacity: 0.5 }} />;
  return (
    <IconChecks
      size={14}
      className={status === "read" ? "shrink-0 text-jade-400" : "shrink-0 text-vault-muted"}
    />
  );
}

function preview(last: MessageWire, conv: ConversationWire, meId: number) {
  const sender = last.senderId === meId ? "You: " : conv.kind === "group" ? "" : "";
  switch (last.kind) {
    case "image":
      return (
        <>
          {sender}
          <IconCamera size={12} className="mr-1 inline" /> Photo
        </>
      );
    case "sticker":
      return (
        <>
          {sender}
          <IconSticker size={12} className="mr-1 inline" /> Sticker
        </>
      );
    case "voice":
      return (
        <>
          {sender}
          <IconMic size={12} className="mr-1 inline" /> {last.body || "Voice note"}
        </>
      );
    case "system":
      return last.body;
    default:
      return `${sender}${last.body}`;
  }
}

export { Ticks };
