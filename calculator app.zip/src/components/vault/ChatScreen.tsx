"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useMemo, useRef, useState } from "react";
import { Avatar } from "@/components/ui/Avatar";
import {
  IconChecks,
  IconChevronLeft,
  IconClose,
  IconDots,
  IconFlame,
  IconPhone,
  IconTrash,
  IconUsers,
  IconVideo,
} from "@/components/ui/icons";
import Composer from "@/components/vault/Composer";
import { haptic } from "@/lib/client";
import { clockTime, dayLabel, durationLabel, ttlLabel } from "@/lib/format";
import { useVault } from "@/lib/vault-store";
import type { MessageWire } from "@/lib/types";

export default function ChatScreen({
  conversationId,
  onBack,
  embedded = false,
}: {
  conversationId: number;
  onBack: () => void;
  embedded?: boolean;
}) {
  const vault = useVault();
  const {
    me,
    threads,
    messagesIn,
    titleFor,
    othersIn,
    typingIn,
    userById,
    stickers,
    placeCall,
    deleteMessage,
    purgeNow,
  } = vault;

  const conv = threads.find((c) => c.id === conversationId);
  const list = messagesIn(conversationId);
  const [menu, setMenu] = useState(false);
  const [info, setInfo] = useState(false);
  const [lightbox, setLightbox] = useState<MessageWire | null>(null);
  const [replyTo, setReplyTo] = useState<MessageWire | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [list.length, conversationId]);

  const grouped = useMemo(() => {
    const out: { day: string; items: MessageWire[] }[] = [];
    for (const m of list) {
      const day = dayLabel(m.createdAt);
      const last = out[out.length - 1];
      if (last && last.day === day) last.items.push(m);
      else out.push({ day, items: [m] });
    }
    return out;
  }, [list]);

  if (!conv) {
    return (
      <div className="grid h-full place-items-center p-10 text-center">
        <div>
          <p className="font-display text-[18px] text-vault-text">Thread closed</p>
          <p className="mt-1 text-[13px] text-vault-muted">
            Everything here expired. Pick another thread from the list.
          </p>
        </div>
      </div>
    );
  }

  const others = othersIn(conv);
  const typing = typingIn.includes(conv.id);

  return (
    <div className={`relative flex h-full flex-col ${embedded ? "" : "bg-vault-900"}`}>
      {/* ── header ── */}
      <header className="relative z-30 flex items-center gap-3 border-b border-white/6 bg-vault-850/95 px-3 py-2.5 backdrop-blur-xl">
        {!embedded && (
          <button
            onClick={onBack}
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-vault-text transition hover:bg-white/6 lg:hidden"
            aria-label="Back to threads"
          >
            <IconChevronLeft size={20} />
          </button>
        )}
        <button
          onClick={() => {
            haptic(8);
            setInfo(true);
          }}
          className="flex min-w-0 flex-1 items-center gap-3 text-left"
        >
          <Avatar
            user={conv.kind === "group" ? { name: titleFor(conv), hue: 158 } : others[0]}
            title={conv.kind === "group" ? undefined : titleFor(conv)}
            group={conv.kind === "group"}
            size={40}
            presence={conv.kind === "dm"}
          />
          <span className="min-w-0">
            <span className="block truncate font-display text-[15.5px] font-semibold text-vault-text">
              {titleFor(conv)}
            </span>
            <span className="block truncate font-mono text-[11px] text-jade-300/80">
              {typing
                ? "typing…"
                : conv.kind === "group"
                  ? `${conv.members.length} members · ${others.map((o) => o.name).join(", ")}`
                  : others[0]?.status ?? "online"}
            </span>
          </span>
        </button>

        <div className="flex items-center gap-1">
          <button
            onClick={() => placeCall(conv.id, "audio")}
            className="grid h-9 w-9 place-items-center rounded-full text-vault-muted transition hover:bg-jade-500/12 hover:text-jade-300"
            aria-label="Voice call"
          >
            <IconPhone size={18} />
          </button>
          <button
            onClick={() => placeCall(conv.id, "video")}
            className="grid h-9 w-9 place-items-center rounded-full text-vault-muted transition hover:bg-jade-500/12 hover:text-jade-300"
            aria-label="Video call"
          >
            <IconVideo size={19} />
          </button>
          <div className="relative">
            <button
              onClick={() => setMenu((m) => !m)}
              className="grid h-9 w-9 place-items-center rounded-full text-vault-muted transition hover:bg-white/6 hover:text-vault-text"
              aria-label="Thread menu"
            >
              <IconDots size={18} />
            </button>
            <AnimatePresence>
              {menu && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setMenu(false)} />
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9, y: -6 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.92, y: -6 }}
                    transition={{ duration: 0.14 }}
                    className="absolute right-0 z-20 mt-1 w-56 overflow-hidden rounded-2xl border border-white/10 bg-vault-800 shadow-2xl"
                  >
                    {[
                      { label: "Thread info", fn: () => setInfo(true) },
                      { label: "Burn expired now", fn: () => void purgeNow() },
                      { label: "Mark everything read", fn: () => undefined },
                    ].map((item) => (
                      <button
                        key={item.label}
                        onClick={() => {
                          haptic(8);
                          item.fn();
                          setMenu(false);
                        }}
                        className="block w-full px-4 py-2.5 text-left text-[13px] text-vault-text transition hover:bg-jade-500/12"
                      >
                        {item.label}
                      </button>
                    ))}
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>
        </div>
      </header>

      {/* ── messages ── */}
      <div className="vault-doodle scroll-thin relative flex-1 overflow-y-auto px-3 py-4 sm:px-6">
        <div className="mx-auto flex max-w-[820px] flex-col gap-1.5">
          <div className="mx-auto mb-2 max-w-[420px] rounded-2xl border border-jade-500/18 bg-vault-850/85 px-4 py-3 text-center backdrop-blur">
            <p className="flex items-center justify-center gap-1.5 font-mono text-[11px] tracking-[0.12em] text-jade-300/90 uppercase">
              <IconFlame size={13} /> {vault.purgeHours}-hour auto-purge armed
            </p>
            <p className="mt-1 text-[12px] leading-relaxed text-vault-muted">
              Only the four of you can see this thread. Anything older than{" "}
              {vault.purgeHours}h is deleted on the server during the next sync sweep.
            </p>
          </div>

          {grouped.map((group) => (
            <div key={group.day} className="flex flex-col gap-1.5">
              <div className="sticky top-1 z-10 my-2 flex justify-center">
                <span className="rounded-full border border-white/8 bg-vault-850/90 px-3 py-1 font-mono text-[10.5px] tracking-[0.16em] text-vault-muted uppercase backdrop-blur">
                  {group.day}
                </span>
              </div>
              {group.items.map((m, i) => {
                const prev = group.items[i - 1];
                const showSender =
                  conv.kind === "group" &&
                  m.senderId !== me.id &&
                  (!prev || prev.senderId !== m.senderId || m.kind === "system");
                return (
                  <Bubble
                    key={m.id}
                    message={m}
                    mine={m.senderId === me.id}
                    showSender={showSender}
                    senderName={userById(m.senderId)?.name ?? "Unknown"}
                    senderHue={userById(m.senderId)?.hue ?? 160}
                    sticker={stickers.find((s) => String(s.id) === m.stickerId)}
                    quoted={m.replyToId ? list.find((x) => x.id === m.replyToId) ?? null : null}
                    quotedSender={
                      m.replyToId ? userById(list.find((x) => x.id === m.replyToId)?.senderId ?? 0)?.name : undefined
                    }
                    onOpenImage={() => setLightbox(m)}
                    onReply={() => setReplyTo(m)}
                    onDelete={() => void deleteMessage(m.id)}
                  />
                );
              })}
            </div>
          ))}

          <AnimatePresence>
            {typing && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 6 }}
                className="mt-1 flex items-end gap-2"
              >
                <Avatar user={others[0]} title={titleFor(conv)} size={28} />
                <div className="flex items-center gap-1.5 rounded-2xl rounded-bl-md border border-white/6 bg-bubble-in px-4 py-3">
                  {[0, 1, 2].map((d) => (
                    <span
                      key={d}
                      className="typing-dot h-1.5 w-1.5 rounded-full bg-jade-300"
                      style={{ animationDelay: `${d * 0.16}s` }}
                    />
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          <div ref={bottomRef} />
        </div>
      </div>

      <Composer
        conversationId={conv.id}
        replyTo={replyTo}
        clearReply={() => setReplyTo(null)}
      />

      {/* ── thread info sheet ── */}
      <AnimatePresence>
        {info && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setInfo(false)}
              className="fixed inset-0 z-40 bg-black/65 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 260, damping: 30 }}
              className="fixed inset-x-0 bottom-0 z-50 mx-auto max-h-[82dvh] w-full max-w-[560px] overflow-y-auto rounded-t-[30px] border-t border-white/10 bg-vault-850 p-5 shadow-2xl"
            >
              <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-white/15" />
              <div className="flex flex-col items-center">
                <Avatar
                  user={conv.kind === "group" ? { name: titleFor(conv), hue: 158 } : others[0]}
                  title={conv.kind === "group" ? undefined : titleFor(conv)}
                  group={conv.kind === "group"}
                  size={86}
                  ring
                />
                <h3 className="mt-3 font-display text-[22px] font-semibold text-vault-text">
                  {titleFor(conv)}
                </h3>
                <p className="font-mono text-[11px] tracking-[0.16em] text-vault-muted uppercase">
                  {conv.kind === "group" ? conv.subject ?? "" : others[0]?.tagline ?? ""}
                </p>
              </div>

              <div className="mt-5 grid grid-cols-3 gap-2.5">
                {[
                  { k: "messages", v: String(list.length) },
                  { k: "ttl left", v: list.length ? ttlLabel(list[list.length - 1].expiresAt) : "—" },
                  { k: "media", v: String(list.filter((m) => m.kind !== "text" && m.kind !== "system").length) },
                ].map((s) => (
                  <div key={s.k} className="rounded-2xl border border-white/8 bg-vault-800/70 px-3 py-2.5 text-center">
                    <div className="font-mono text-[15px] text-jade-300">{s.v}</div>
                    <div className="mt-0.5 font-mono text-[9.5px] tracking-[0.14em] text-vault-muted uppercase">
                      {s.k}
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-5 space-y-2">
                <p className="font-mono text-[10.5px] tracking-[0.2em] text-vault-muted uppercase">
                  {conv.kind === "group" ? "Members" : "Participants"}
                </p>
                {conv.members.map((id) => {
                  const u = userById(id);
                  if (!u) return null;
                  return (
                    <div
                      key={id}
                      className="flex items-center gap-3 rounded-2xl border border-white/6 bg-vault-800/50 px-3 py-2.5"
                    >
                      <Avatar user={u} size={38} presence />
                      <div className="min-w-0">
                        <div className="truncate font-display text-[14.5px] font-semibold text-vault-text">
                          {u.name}
                          {u.id === me.id && <span className="ml-2 font-mono text-[10px] text-jade-300">you</span>}
                        </div>
                        <div className="truncate font-mono text-[11px] text-vault-muted">
                          {u.role} · {u.status}
                        </div>
                      </div>
                      {conv.kind === "group" && (
                        <IconUsers size={15} className="ml-auto text-vault-muted/60" />
                      )}
                    </div>
                  );
                })}
              </div>

              <button
                onClick={() => setInfo(false)}
                className="mt-5 w-full rounded-2xl border border-white/10 py-3 font-mono text-[11.5px] tracking-[0.2em] text-vault-muted uppercase transition hover:border-jade-500/40 hover:text-jade-300"
              >
                close
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* ── image lightbox ── */}
      <AnimatePresence>
        {lightbox?.mediaData && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[70] flex flex-col bg-black/94 p-4 backdrop-blur"
            onClick={() => setLightbox(null)}
          >
            <div className="flex items-center justify-between">
              <span className="font-mono text-[11.5px] text-white/70">
                {lightbox.mediaName} · {clockTime(lightbox.createdAt)}
              </span>
              <span className="grid h-9 w-9 place-items-center rounded-full border border-white/15 text-white/80">
                <IconClose size={17} />
              </span>
            </div>
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 210, damping: 22 }}
              className="flex flex-1 items-center justify-center"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={lightbox.mediaData}
                alt={lightbox.mediaName ?? "shared photo"}
                className="max-h-full max-w-full rounded-2xl object-contain shadow-2xl"
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ───────────────────────────── bubble ───────────────────────────── */

function Bubble({
  message,
  mine,
  showSender,
  senderName,
  senderHue,
  sticker,
  quoted,
  quotedSender,
  onOpenImage,
  onReply,
  onDelete,
}: {
  message: MessageWire;
  mine: boolean;
  showSender: boolean;
  senderName: string;
  senderHue: number;
  sticker?: { id: number; label: string; data: string };
  quoted: MessageWire | null;
  quotedSender?: string;
  onOpenImage: () => void;
  onReply: () => void;
  onDelete: () => void;
}) {
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!playing) return;
    const total = 14;
    const started = Date.now();
    const t = window.setInterval(() => {
      const pct = Math.min(100, ((Date.now() - started) / (total * 1000)) * 100);
      setProgress(pct);
      if (pct >= 100) {
        setPlaying(false);
        setProgress(0);
        window.clearInterval(t);
      }
    }, 90);
    return () => window.clearInterval(t);
  }, [playing]);

  if (message.kind === "system") {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        className="my-1.5 flex justify-center"
      >
        <span className="max-w-[440px] rounded-2xl border border-jade-500/15 bg-vault-850/85 px-4 py-2 text-center font-mono text-[11px] text-jade-300/85 backdrop-blur">
          {message.body}
        </span>
      </motion.div>
    );
  }

  const isSticker = message.kind === "sticker";
  const bars = Array.from({ length: 26 }, (_, i) => 0.3 + (((message.id * 37 + i * 29) % 70) / 100));

  return (
    <motion.div
      layout="position"
      initial={{ opacity: 0, y: 12, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ type: "spring", stiffness: 320, damping: 28 }}
      className={`group flex w-full items-end gap-2 ${mine ? "justify-end" : "justify-start"}`}
    >
      <div className={`relative max-w-[min(78%,520px)] ${isSticker ? "" : ""}`}>
        {/* hover actions */}
        <div
          className={`absolute -top-3 z-10 flex gap-1 opacity-0 transition group-hover:opacity-100 ${
            mine ? "left-0" : "right-0"
          }`}
        >
          <button
            onClick={onReply}
            className="rounded-full border border-white/10 bg-vault-800 px-2 py-0.5 font-mono text-[9.5px] tracking-[0.1em] text-vault-muted uppercase hover:text-jade-300"
          >
            reply
          </button>
          {mine && (
            <button
              onClick={onDelete}
              className="grid h-5 w-5 place-items-center rounded-full border border-white/10 bg-vault-800 text-vault-muted hover:border-red-500/40 hover:text-red-300"
              aria-label="Delete message"
            >
              <IconTrash size={11} />
            </button>
          )}
        </div>

        {isSticker ? (
          <motion.button
            whileHover={{ scale: 1.06, rotate: -2 }}
            whileTap={{ scale: 0.94 }}
            onClick={onReply}
            className="block"
            title={sticker?.label ?? "sticker"}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={sticker?.data ?? ""}
              alt={sticker?.label ?? "sticker"}
              className="h-[112px] w-[112px] object-contain drop-shadow-[0_8px_18px_rgba(0,0,0,.6)]"
            />
          </motion.button>
        ) : (
          <div
            className={[
              "relative overflow-hidden rounded-[18px] px-3 py-2 shadow-[0_6px_18px_-10px_rgba(0,0,0,.9)]",
              mine
                ? "rounded-br-[5px] bg-bubble-out text-vault-text"
                : "rounded-bl-[5px] bg-bubble-in text-vault-text",
            ].join(" ")}
          >
            {showSender && (
              <div
                className="mb-1 font-display text-[12.5px] font-semibold"
                style={{ color: `hsl(${senderHue} 75% 68%)` }}
              >
                {senderName}
              </div>
            )}

            {quoted && (
              <div className="mb-1.5 rounded-lg border-l-2 border-jade-400 bg-black/20 px-2.5 py-1.5">
                <div className="font-display text-[11.5px] font-semibold text-jade-300">
                  {quotedSender ?? "Message"}
                </div>
                <div className="truncate text-[11.5px] text-vault-muted">
                  {quoted.body || (quoted.kind === "image" ? "Photo" : "Attachment")}
                </div>
              </div>
            )}

            {message.kind === "image" && message.mediaData && (
              <button onClick={onOpenImage} className="mb-1 block w-full overflow-hidden rounded-xl">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={message.mediaData}
                  alt={message.mediaName ?? "photo"}
                  className="max-h-[300px] w-full object-cover transition duration-500 hover:scale-[1.02]"
                />
              </button>
            )}

            {message.kind === "voice" && (
              <div className="flex items-center gap-2.5 py-0.5">
                <button
                  onClick={() => {
                    haptic(10);
                    setPlaying((p) => !p);
                  }}
                  className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-jade-500 text-vault-950"
                  aria-label={playing ? "Pause voice note" : "Play voice note"}
                >
                  {playing ? (
                    <span className="flex gap-[2px]">
                      <span className="h-3 w-[2px] rounded bg-vault-950" />
                      <span className="h-3 w-[2px] rounded bg-vault-950" />
                    </span>
                  ) : (
                    <span className="ml-[2px] h-0 w-0 border-y-[5px] border-l-[8px] border-y-transparent border-l-vault-950" />
                  )}
                </button>
                <div className="flex h-7 items-end gap-[2px]">
                  {bars.map((h, i) => (
                    <span
                      key={i}
                      className={[
                        "w-[2.5px] rounded-full transition-all duration-150",
                        (i / bars.length) * 100 <= progress ? "bg-jade-300" : "bg-white/25",
                        playing ? "animate-wavebar" : "",
                      ].join(" ")}
                      style={{ height: `${h * 100}%`, animationDelay: `${i * 0.05}s` }}
                    />
                  ))}
                </div>
                <span className="shrink-0 font-mono text-[10.5px] text-vault-muted">
                  {playing ? durationLabel((progress / 100) * 14) : "0:14"}
                </span>
              </div>
            )}

            {message.kind === "image" && message.body && (
              <p className="whitespace-pre-wrap break-words text-[13.8px] leading-snug">
                {message.body}
              </p>
            )}
            {message.kind === "text" && (
              <p className="whitespace-pre-wrap break-words text-[13.8px] leading-snug">
                {message.body}
              </p>
            )}

            <div className="mt-0.5 flex items-center justify-end gap-1.5">
              {message.simulated && (
                <span className="font-mono text-[9px] tracking-[0.1em] text-jade-300/50 uppercase">
                  sim
                </span>
              )}
              <span className="font-mono text-[10px] text-vault-muted/75">
                {clockTime(message.createdAt)}
              </span>
              {mine &&
                (message.status === "sent" ? (
                  <IconChecks size={14} className="text-vault-muted/55" style={{ opacity: 0.55 }} />
                ) : (
                  <IconChecks
                    size={14}
                    className={message.status === "read" ? "text-jade-300" : "text-vault-muted"}
                  />
                ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}

