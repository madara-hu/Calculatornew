"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import {
  IconCamera,
  IconClose,
  IconImage,
  IconLink,
  IconMic,
  IconPlus,
  IconSend,
  IconSmile,
  IconSticker,
  IconTrash,
} from "@/components/ui/icons";
import { haptic } from "@/lib/client";
import { durationLabel, fileToDataUri, resizeImage } from "@/lib/format";
import { useVault } from "@/lib/vault-store";
import type { MessageWire } from "@/lib/types";

export default function Composer({
  conversationId,
  replyTo,
  clearReply,
}: {
  conversationId: number;
  replyTo: MessageWire | null;
  clearReply: () => void;
}) {
  const { send, stickers, addSticker, removeSticker, notify, me } = useVault();
  const [text, setText] = useState("");
  const [sheet, setSheet] = useState(false);
  const [stickerPanel, setStickerPanel] = useState(false);
  const [pendingImage, setPendingImage] = useState<{ dataUri: string; name: string } | null>(null);
  const [recording, setRecording] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [addingSticker, setAddingSticker] = useState(false);
  const [stickerUrl, setStickerUrl] = useState("");
  const [stickerLabel, setStickerLabel] = useState("");
  const [busy, setBusy] = useState(false);

  const galleryRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);
  const stickerFileRef = useRef<HTMLInputElement>(null);
  const areaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (!recording) return;
    const t = window.setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => window.clearInterval(t);
  }, [recording]);

  useEffect(() => {
    const el = areaRef.current;
    if (!el) return;
    el.style.height = "0px";
    el.style.height = `${Math.min(el.scrollHeight, 116)}px`;
  }, [text]);

  const pickImage = async (file?: File | null) => {
    if (!file) return;
    setBusy(true);
    try {
      const resized = await resizeImage(file, 1280, 0.72);
      setPendingImage({ dataUri: resized.dataUri, name: resized.name });
      setSheet(false);
      haptic(14);
    } catch (e) {
      notify(e instanceof Error ? e.message : "Could not read that image", "bad");
    } finally {
      setBusy(false);
    }
  };

  const dispatch = async () => {
    const body = text.trim();
    if (!body && !pendingImage) return;
    if (pendingImage) {
      await send({
        conversationId,
        kind: "image",
        body,
        mediaData: pendingImage.dataUri,
        mediaMime: "image/jpeg",
        mediaName: pendingImage.name,
        replyToId: replyTo?.id ?? null,
      });
      setPendingImage(null);
    } else {
      await send({ conversationId, kind: "text", body, replyToId: replyTo?.id ?? null });
    }
    setText("");
    clearReply();
  };

  const sendVoice = async () => {
    const len = Math.max(3, seconds);
    setRecording(false);
    setSeconds(0);
    await send({
      conversationId,
      kind: "voice",
      body: `Voice note · ${durationLabel(len)}`,
      replyToId: replyTo?.id ?? null,
    });
    clearReply();
  };

  const sendPinDrop = async () => {
    setSheet(false);
    const lat = (18 + Math.random() * 10).toFixed(4);
    const lng = (72 + Math.random() * 8).toFixed(4);
    await send({
      conversationId,
      kind: "text",
      body: `📍 Pin drop · ${lat}° N, ${lng}° E\nAccurate to ~6 m. Expires with the thread.`,
      replyToId: replyTo?.id ?? null,
    });
    clearReply();
  };

  const submitSticker = async () => {
    if (!stickerUrl.trim()) return;
    setBusy(true);
    try {
      await addSticker({
        label: stickerLabel.trim() || "Linked sticker",
        data: stickerUrl.trim(),
      });
      setStickerUrl("");
      setStickerLabel("");
      setAddingSticker(false);
    } finally {
      setBusy(false);
    }
  };

  const packs = Array.from(new Set(stickers.map((s) => s.pack)));

  return (
    <div className="relative z-20 border-t border-white/6 bg-vault-850/95 px-3 pb-3 pt-2.5 backdrop-blur-xl">
      {/* reply preview */}
      <AnimatePresence>
        {replyTo && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="mb-2 overflow-hidden"
          >
            <div className="flex items-center gap-2 rounded-xl border-l-2 border-jade-400 bg-vault-800/80 px-3 py-2">
              <div className="min-w-0 flex-1">
                <div className="font-display text-[11.5px] font-semibold text-jade-300">
                  Replying to {replyTo.senderId === me.id ? "yourself" : "message"}
                </div>
                <div className="truncate text-[11.5px] text-vault-muted">
                  {replyTo.body || (replyTo.kind === "image" ? "Photo" : "Attachment")}
                </div>
              </div>
              <button onClick={clearReply} className="text-vault-muted hover:text-red-300" aria-label="Cancel reply">
                <IconClose size={15} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* pending photo */}
      <AnimatePresence>
        {pendingImage && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 12 }}
            className="mb-2 flex items-center gap-3 rounded-2xl border border-jade-500/25 bg-vault-800/80 p-2"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={pendingImage.dataUri} alt="pending" className="h-14 w-14 rounded-xl object-cover" />
            <div className="min-w-0 flex-1">
              <p className="truncate font-mono text-[11.5px] text-jade-300">{pendingImage.name}</p>
              <p className="font-mono text-[10.5px] text-vault-muted">
                compressed on device · sent with the caption below
              </p>
            </div>
            <button
              onClick={() => setPendingImage(null)}
              className="grid h-8 w-8 place-items-center rounded-full border border-white/10 text-vault-muted hover:border-red-500/40 hover:text-red-300"
              aria-label="Remove photo"
            >
              <IconTrash size={14} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* recording bar */}
      <AnimatePresence>
        {recording && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-2 overflow-hidden"
          >
            <div className="flex items-center gap-3 rounded-2xl border border-red-500/25 bg-red-500/8 px-3.5 py-2.5">
              <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-red-400" />
              <span className="font-mono text-[13px] text-red-200">{durationLabel(seconds)}</span>
              <div className="flex h-6 flex-1 items-end gap-[3px]">
                {Array.from({ length: 28 }, (_, i) => (
                  <span
                    key={i}
                    className="animate-wavebar w-[3px] rounded-full bg-red-300/70"
                    style={{ height: `${28 + ((i * 37) % 70)}%`, animationDelay: `${i * 0.06}s` }}
                  />
                ))}
              </div>
              <button
                onClick={() => {
                  setRecording(false);
                  setSeconds(0);
                }}
                className="font-mono text-[11px] tracking-[0.12em] text-vault-muted uppercase hover:text-red-300"
              >
                cancel
              </button>
              <button
                onClick={sendVoice}
                className="rounded-full bg-jade-500 px-3 py-1.5 font-mono text-[11px] tracking-[0.12em] text-vault-950 uppercase"
              >
                send
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex items-end gap-2">
        <button
          onClick={() => {
            haptic(8);
            setSheet((s) => !s);
            setStickerPanel(false);
          }}
          className={[
            "grid h-11 w-11 shrink-0 place-items-center rounded-full border transition",
            sheet
              ? "border-jade-500/50 bg-jade-500/15 text-jade-300"
              : "border-white/8 bg-vault-800 text-vault-muted hover:text-jade-300",
          ].join(" ")}
          aria-label="Attach"
        >
          <motion.span animate={{ rotate: sheet ? 45 : 0 }} transition={{ type: "spring", stiffness: 300, damping: 20 }}>
            <IconPlus size={20} />
          </motion.span>
        </button>

        <div className="flex min-w-0 flex-1 items-end gap-2 rounded-[24px] border border-white/8 bg-vault-800 px-3 py-2 focus-within:border-jade-500/35">
          <textarea
            ref={areaRef}
            rows={1}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void dispatch();
              }
            }}
            placeholder="Message"
            className="max-h-[116px] min-h-[26px] flex-1 resize-none bg-transparent py-1 text-[14px] leading-snug text-vault-text placeholder:text-vault-muted/60 focus:outline-none"
          />
          <button
            onClick={() => {
              haptic(8);
              setStickerPanel((s) => !s);
              setSheet(false);
            }}
            className={[
              "grid h-8 w-8 shrink-0 place-items-center rounded-full transition",
              stickerPanel ? "text-jade-300" : "text-vault-muted hover:text-jade-300",
            ].join(" ")}
            aria-label="Stickers"
          >
            <IconSmile size={20} />
          </button>
        </div>

        {text.trim() || pendingImage ? (
          <motion.button
            initial={{ scale: 0.6, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => void dispatch()}
            disabled={busy}
            className="jade-glow grid h-11 w-11 shrink-0 place-items-center rounded-full bg-jade-500 text-vault-950 transition disabled:opacity-60"
            aria-label="Send message"
          >
            <IconSend size={19} />
          </motion.button>
        ) : (
          <motion.button
            initial={{ scale: 0.6, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => {
              haptic(10);
              setRecording((r) => !r);
              setSeconds(0);
            }}
            className={[
              "grid h-11 w-11 shrink-0 place-items-center rounded-full border transition",
              recording
                ? "border-red-400/50 bg-red-500/15 text-red-300"
                : "border-white/8 bg-vault-800 text-vault-muted hover:text-jade-300",
            ].join(" ")}
            aria-label="Record voice note"
          >
            <IconMic size={19} />
          </motion.button>
        )}
      </div>

      {/* attachment sheet */}
      <AnimatePresence>
        {sheet && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 16 }}
            transition={{ type: "spring", stiffness: 300, damping: 28 }}
            className="absolute inset-x-3 bottom-[76px] grid grid-cols-3 gap-2.5 rounded-[26px] border border-white/10 bg-vault-850/98 p-3 shadow-2xl backdrop-blur-xl sm:grid-cols-5"
          >
            {[
              { label: "Camera", icon: <IconCamera size={20} />, hue: 8, fn: () => cameraRef.current?.click() },
              { label: "Gallery", icon: <IconImage size={20} />, hue: 158, fn: () => galleryRef.current?.click() },
              { label: "Sticker", icon: <IconSticker size={20} />, hue: 42, fn: () => { setSheet(false); setStickerPanel(true); } },
              { label: "Voice note", icon: <IconMic size={20} />, hue: 340, fn: () => { setSheet(false); setRecording(true); setSeconds(0); } },
              { label: "Pin drop", icon: <IconLink size={20} />, hue: 200, fn: () => void sendPinDrop() },
            ].map((item) => (
              <button
                key={item.label}
                onClick={() => {
                  haptic(10);
                  item.fn();
                }}
                className="flex flex-col items-center gap-2 rounded-2xl border border-white/6 bg-vault-800/60 px-2 py-3.5 transition hover:border-white/16 hover:bg-vault-700/60"
              >
                <span
                  className="grid h-11 w-11 place-items-center rounded-full text-white"
                  style={{
                    background: `linear-gradient(145deg, hsl(${item.hue} 72% 46%), hsl(${(item.hue + 26) % 360} 66% 28%))`,
                    boxShadow: `0 0 20px -6px hsl(${item.hue} 80% 55% / .8)`,
                  }}
                >
                  {item.icon}
                </span>
                <span className="font-mono text-[10px] tracking-[0.1em] text-vault-muted uppercase">
                  {item.label}
                </span>
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* sticker panel */}
      <AnimatePresence>
        {stickerPanel && (
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 24, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 300, damping: 28 }}
            className="absolute inset-x-3 bottom-[76px] max-h-[46dvh] overflow-hidden rounded-[26px] border border-white/10 bg-vault-850/98 shadow-2xl backdrop-blur-xl"
          >
            <div className="flex items-center justify-between border-b border-white/6 px-4 py-2.5">
              <span className="font-mono text-[10.5px] tracking-[0.2em] text-vault-muted uppercase">
                {packs.length} pack{packs.length === 1 ? "" : "s"} · {stickers.length} stickers
              </span>
              <div className="flex gap-2">
                <button
                  onClick={() => stickerFileRef.current?.click()}
                  className="rounded-full border border-white/10 px-2.5 py-1 font-mono text-[10px] tracking-[0.1em] text-vault-muted uppercase hover:border-jade-500/40 hover:text-jade-300"
                >
                  upload
                </button>
                <button
                  onClick={() => setAddingSticker((a) => !a)}
                  className="rounded-full border border-white/10 px-2.5 py-1 font-mono text-[10px] tracking-[0.1em] text-vault-muted uppercase hover:border-jade-500/40 hover:text-jade-300"
                >
                  link from app
                </button>
                <button onClick={() => setStickerPanel(false)} className="text-vault-muted hover:text-red-300" aria-label="Close stickers">
                  <IconClose size={16} />
                </button>
              </div>
            </div>

            <AnimatePresence>
              {addingSticker && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden border-b border-white/6"
                >
                  <div className="flex flex-col gap-2 p-3 sm:flex-row">
                    <input
                      value={stickerUrl}
                      onChange={(e) => setStickerUrl(e.target.value)}
                      placeholder="https://…/sticker.webp  (paste a link from any sticker app)"
                      className="flex-1 rounded-xl border border-white/10 bg-vault-800 px-3 py-2 font-mono text-[12px] text-vault-text placeholder:text-vault-muted/60 focus:border-jade-500/40 focus:outline-none"
                    />
                    <input
                      value={stickerLabel}
                      onChange={(e) => setStickerLabel(e.target.value)}
                      placeholder="label"
                      className="w-full rounded-xl border border-white/10 bg-vault-800 px-3 py-2 font-mono text-[12px] text-vault-text placeholder:text-vault-muted/60 focus:border-jade-500/40 focus:outline-none sm:w-32"
                    />
                    <button
                      onClick={() => void submitSticker()}
                      disabled={busy}
                      className="rounded-xl bg-jade-500 px-4 py-2 font-mono text-[11px] tracking-[0.14em] text-vault-950 uppercase disabled:opacity-60"
                    >
                      import
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="scroll-thin max-h-[32dvh] overflow-y-auto p-3">
              {packs.map((pack) => (
                <div key={pack} className="mb-3 last:mb-0">
                  <p className="mb-2 font-display text-[12px] tracking-[0.16em] text-jade-300/80 uppercase">
                    {pack}
                  </p>
                  <div className="grid grid-cols-4 gap-2 sm:grid-cols-6">
                    {stickers
                      .filter((s) => s.pack === pack)
                      .map((s) => (
                        <motion.button
                          key={s.id}
                          whileHover={{ scale: 1.08, rotate: -2 }}
                          whileTap={{ scale: 0.92 }}
                          onClick={async () => {
                            haptic(10);
                            await send({
                              conversationId,
                              kind: "sticker",
                              stickerId: String(s.id),
                              replyToId: replyTo?.id ?? null,
                            });
                            clearReply();
                          }}
                          className="group relative grid aspect-square place-items-center rounded-2xl border border-white/6 bg-vault-800/60 p-1.5 transition hover:border-jade-500/35"
                          title={s.label}
                        >
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img src={s.data} alt={s.label} className="h-full w-full object-contain" />
                          {s.ownerId === me.id && (
                            <span
                              role="button"
                              tabIndex={0}
                              onClick={(e) => {
                                e.stopPropagation();
                                void removeSticker(s.id);
                              }}
                              onKeyDown={(e) => {
                                if (e.key === "Enter") {
                                  e.stopPropagation();
                                  void removeSticker(s.id);
                                }
                              }}
                              className="absolute -right-1 -top-1 hidden h-5 w-5 place-items-center rounded-full border border-white/15 bg-vault-950 text-red-300 group-hover:grid"
                            >
                              <IconClose size={11} />
                            </span>
                          )}
                        </motion.button>
                      ))}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <input
        ref={galleryRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => void pickImage(e.target.files?.[0])}
      />
      <input
        ref={cameraRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={(e) => void pickImage(e.target.files?.[0])}
      />
      <input
        ref={stickerFileRef}
        type="file"
        accept="image/png,image/webp,image/gif,image/svg+xml"
        className="hidden"
        onChange={async (e) => {
          const file = e.target.files?.[0];
          if (!file) return;
          setBusy(true);
          try {
            const dataUri = await fileToDataUri(file, 900_000);
            await addSticker({ label: file.name.replace(/\.[^.]+$/, ""), data: dataUri });
          } catch (err) {
            notify(err instanceof Error ? err.message : "Upload failed", "bad");
          } finally {
            setBusy(false);
          }
        }}
      />
    </div>
  );
}
