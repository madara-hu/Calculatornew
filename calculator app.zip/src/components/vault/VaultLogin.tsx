"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { Avatar } from "@/components/ui/Avatar";
import {
  IconBolt,
  IconChevronLeft,
  IconEye,
  IconLock,
  IconShield,
} from "@/components/ui/icons";
import { Auth, haptic } from "@/lib/client";
import type { RosterUser, UserWire } from "@/lib/types";

export default function VaultLogin({
  roster,
  onSuccess,
  onBack,
}: {
  roster: RosterUser[];
  onSuccess: (me: UserWire) => void;
  onBack: () => void;
}) {
  const [selected, setSelected] = useState<string | null>(null);
  const [password, setPassword] = useState("");
  const [reveal, setReveal] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [shake, setShake] = useState(0);
  const [showCreds, setShowCreds] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const submitted = useRef(false);

  const person = roster.find((r) => r.handle === selected) ?? null;

  useEffect(() => {
    if (person) window.setTimeout(() => inputRef.current?.focus(), 260);
  }, [person]);

  const submit = () => {
    if (!person || busy || submitted.current || !password) return;
    submitted.current = true;
    setBusy(true);
    setError(null);
    haptic(10);
    Auth.login(person.handle, password)
      .then((res) => {
        haptic([16, 40, 30]);
        onSuccess(res.me);
      })
      .catch((e: Error) => {
        haptic(80);
        submitted.current = false;
        setBusy(false);
        setError(e.message);
        setShake((s) => s + 1);
        setPassword("");
      });
  };

  const reset = () => {
    setSelected(null);
    setPassword("");
    setError(null);
    submitted.current = false;
    setBusy(false);
  };

  const strength = Math.min(4, Math.floor(password.length / 3));

  return (
    <div className="vault-doodle relative flex min-h-dvh flex-col overflow-hidden px-5 pb-8 pt-6">
      <div className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-jade-500/12 blur-3xl" />

      <div className="relative mx-auto flex w-full max-w-[480px] flex-1 flex-col">
        <div className="mb-6 flex items-center justify-between">
          <button
            onClick={person ? reset : onBack}
            className="flex items-center gap-1.5 rounded-full border border-white/8 bg-white/4 px-3 py-1.5 font-mono text-[11px] tracking-[0.14em] text-vault-muted uppercase transition hover:border-jade-500/40 hover:text-jade-300"
          >
            <IconChevronLeft size={13} /> {person ? "not me" : "relock"}
          </button>
          <span className="flex items-center gap-1.5 font-mono text-[10.5px] tracking-[0.2em] text-jade-300/60 uppercase">
            <IconShield size={13} /> 4 seats · no sign-ups
          </span>
        </div>

        <AnimatePresence mode="wait">
          {!person ? (
            <motion.div
              key="roster"
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -18 }}
              transition={{ type: "spring", stiffness: 210, damping: 26 }}
            >
              <h1 className="font-display text-[30px] leading-tight font-semibold text-vault-text">
                Who is holding the phone?
              </h1>
              <p className="mt-1.5 max-w-[38ch] text-[13.5px] leading-relaxed text-vault-muted">
                Pick your username and enter your own password. Every seat has a different one, and
                none of them are stored in plain text — only a salted hash lives in the database.
              </p>

              <div className="mt-6 grid grid-cols-2 gap-3">
                {roster.map((r, i) => (
                  <motion.button
                    key={r.handle}
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.05 * i, type: "spring", stiffness: 230, damping: 24 }}
                    whileHover={{ y: -3 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => {
                      haptic(12);
                      setSelected(r.handle);
                      setPassword("");
                      setError(null);
                      submitted.current = false;
                    }}
                    className="group relative overflow-hidden rounded-3xl border border-white/8 bg-vault-800/70 p-4 text-left backdrop-blur transition hover:border-jade-500/40"
                  >
                    <span className="pointer-events-none absolute inset-x-0 -top-14 h-24 bg-jade-500/12 blur-2xl transition group-hover:bg-jade-400/22" />
                    <Avatar user={r} size={46} />
                    <div className="mt-3 font-display text-[16px] font-semibold text-vault-text">
                      {r.name}
                    </div>
                    <div className="truncate font-mono text-[10.5px] tracking-[0.1em] text-jade-300/75">
                      @{r.handle}
                    </div>
                    <div className="mt-1 font-mono text-[9.5px] tracking-[0.16em] text-vault-muted uppercase">
                      {r.role}
                    </div>
                  </motion.button>
                ))}
              </div>

              {roster.some((r) => r.demoPassword) && (
                <button
                  onClick={() => setShowCreds((s) => !s)}
                  className="mt-5 w-full rounded-2xl border border-dashed border-white/12 px-4 py-3 text-left transition hover:border-jade-500/40"
                >
                  <span className="flex items-center gap-2 font-mono text-[11px] tracking-[0.18em] text-vault-muted uppercase">
                    <IconLock size={13} /> {showCreds ? "hide" : "show"} demo credentials
                  </span>
                  <AnimatePresence>
                    {showCreds && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <ul className="mt-2.5 space-y-1.5 font-mono text-[12px]">
                          {roster.map((r) => (
                            <li key={r.handle} className="flex items-center justify-between gap-3">
                              <span className="text-vault-text/80">@{r.handle}</span>
                              <span className="text-jade-300">{r.demoPassword}</span>
                            </li>
                          ))}
                        </ul>
                        <p className="mt-2 font-mono text-[10.5px] leading-relaxed text-vault-muted/70">
                          Served by the API only while EXPOSE_DEMO_CREDENTIALS=true. Switch it off in
                          .env for production.
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </button>
              )}
            </motion.div>
          ) : (
            <motion.div
              key="password"
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -40 }}
              transition={{ type: "spring", stiffness: 230, damping: 26 }}
              className="flex flex-1 flex-col"
            >
              <div className="flex flex-col items-center">
                <motion.div
                  animate={busy ? { scale: [1, 1.05, 1] } : {}}
                  transition={{ duration: 1, repeat: Infinity }}
                >
                  <Avatar user={person} size={84} ring />
                </motion.div>
                <h2 className="mt-4 font-display text-[26px] font-semibold text-vault-text">
                  {person.name}
                </h2>
                <p className="font-mono text-[11px] tracking-[0.18em] text-jade-300/80">
                  @{person.handle}
                </p>
                <p className="mt-1 font-mono text-[10.5px] tracking-[0.2em] text-vault-muted uppercase">
                  {person.role} · password required
                </p>
              </div>

              <motion.form
                key={shake}
                animate={shake ? { x: [0, -10, 9, -6, 4, 0] } : {}}
                transition={{ duration: 0.45 }}
                onSubmit={(e) => {
                  e.preventDefault();
                  submit();
                }}
                className="mt-7"
              >
                <div
                  className={[
                    "flex items-center gap-2 rounded-2xl border bg-vault-800/85 px-4 transition",
                    error ? "border-red-500/45" : "border-white/10 focus-within:border-jade-500/50",
                  ].join(" ")}
                >
                  <IconLock size={16} className={error ? "text-red-300" : "text-vault-muted"} />
                  <input
                    ref={inputRef}
                    type={reveal ? "text" : "password"}
                    value={password}
                    autoComplete="current-password"
                    autoCapitalize="off"
                    autoCorrect="off"
                    spellCheck={false}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setError(null);
                    }}
                    placeholder="your password"
                    className="w-full bg-transparent py-3.5 font-mono text-[14.5px] tracking-[0.06em] text-vault-text placeholder:tracking-normal placeholder:text-vault-muted/55 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      haptic(7);
                      setReveal((r) => !r);
                    }}
                    className="shrink-0 text-vault-muted transition hover:text-jade-300"
                    aria-label={reveal ? "Hide password" : "Show password"}
                  >
                    <IconEye size={17} />
                  </button>
                </div>

                <div className="mt-2.5 flex items-center gap-2 px-1">
                  <div className="flex flex-1 gap-1">
                    {[0, 1, 2, 3].map((i) => (
                      <span
                        key={i}
                        className={[
                          "h-1 flex-1 rounded-full transition-colors duration-300",
                          i < strength
                            ? strength <= 1
                              ? "bg-red-400"
                              : strength === 2
                                ? "bg-amber-glow"
                                : "bg-jade-400"
                            : "bg-white/8",
                        ].join(" ")}
                      />
                    ))}
                  </div>
                  <span className="font-mono text-[9.5px] tracking-[0.16em] text-vault-muted uppercase">
                    {password.length === 0 ? "awaiting input" : `${password.length} chars`}
                  </span>
                </div>

                <AnimatePresence>
                  {error && (
                    <motion.p
                      initial={{ opacity: 0, y: -6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="mt-3 rounded-xl border border-red-500/25 bg-red-500/10 px-3 py-2 text-center font-mono text-[11.5px] text-red-300"
                    >
                      {error}
                    </motion.p>
                  )}
                </AnimatePresence>

                <motion.button
                  type="submit"
                  whileTap={{ scale: 0.97 }}
                  disabled={busy || !password}
                  className="jade-glow mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-jade-500 py-3.5 font-display text-[13px] tracking-[0.24em] text-vault-950 uppercase transition disabled:opacity-45"
                >
                  <IconBolt size={15} />
                  {busy ? "verifying…" : "unlock vault"}
                </motion.button>
              </motion.form>

              {person.demoPassword && (
                <p className="mt-4 text-center font-mono text-[10.5px] tracking-[0.1em] text-vault-muted/70">
                  demo password for @{person.handle}:{" "}
                  <span className="text-jade-300">{person.demoPassword}</span>
                </p>
              )}

              <div className="mt-auto pt-8 text-center">
                <p className="font-mono text-[10px] tracking-[0.16em] text-vault-muted/60 uppercase">
                  5 failed attempts locks the username for 30s
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
