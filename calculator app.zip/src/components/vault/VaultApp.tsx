"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import CallOverlay from "@/components/vault/CallOverlay";
import ChatList from "@/components/vault/ChatList";
import ChatScreen from "@/components/vault/ChatScreen";
import { CallsTab, SettingsTab, StickersTab } from "@/components/vault/SideTabs";
import { Avatar } from "@/components/ui/Avatar";
import {
  IconChats,
  IconClose,
  IconGear,
  IconLock,
  IconPhone,
  IconShield,
  IconSticker,
} from "@/components/ui/icons";
import { haptic } from "@/lib/client";
import { useVault } from "@/lib/vault-store";
import type { UserWire } from "@/lib/types";

type Tab = "chats" | "calls" | "stickers" | "settings";

const TABS: { id: Tab; label: string; icon: typeof IconChats }[] = [
  { id: "chats", label: "Chats", icon: IconChats },
  { id: "calls", label: "Calls", icon: IconPhone },
  { id: "stickers", label: "Stickers", icon: IconSticker },
  { id: "settings", label: "Settings", icon: IconGear },
];

export default function VaultApp({ me }: { me: UserWire }) {
  const vault = useVault();
  const {
    ready,
    error,
    openId,
    setOpenId,
    activeCall,
    toasts,
    dismissToast,
    unreadIn,
    threads,
    stream,
  } = vault;
  const [tab, setTab] = useState<Tab>("chats");

  const totalUnread = threads.reduce((sum, t) => sum + unreadIn(t.id), 0);

  useEffect(() => {
    if (openId !== null) setTab("chats");
  }, [openId]);

  const openThread = (id: number) => {
    haptic(9);
    setOpenId(id);
  };

  if (error) {
    return (
      <div className="vault-doodle grid min-h-dvh place-items-center p-8">
        <div className="max-w-sm rounded-3xl border border-red-500/25 bg-vault-850/85 p-6 text-center">
          <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-red-500/12 text-red-300">
            <IconClose size={22} />
          </span>
          <h2 className="mt-4 font-display text-[20px] font-semibold text-vault-text">
            Vault unreachable
          </h2>
          <p className="mt-2 text-[13px] leading-relaxed text-vault-muted">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="mt-5 w-full rounded-2xl border border-white/12 py-3 font-mono text-[11px] tracking-[0.18em] text-vault-text uppercase hover:border-jade-500/40"
          >
            retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="vault-doodle relative flex h-dvh flex-col overflow-hidden">
      {/* ── app bar ── */}
      <header className="relative z-30 shrink-0 border-b border-white/6 bg-vault-900/92 backdrop-blur-xl">
        <div className="flex items-center gap-3 px-4 pt-3.5">
          <span className="jade-glow grid h-9 w-9 place-items-center rounded-xl bg-vault-800 text-jade-300">
            <IconShield size={18} />
          </span>
          <div className="min-w-0">
            <h1 className="font-display text-[17px] leading-none font-semibold tracking-[0.14em] text-vault-text uppercase">
              Hustler
            </h1>
            <p className="mt-1 flex items-center gap-1.5 font-mono text-[10px] tracking-[0.2em] text-jade-300/70 uppercase">
              <span
                className={[
                  "h-1.5 w-1.5 rounded-full",
                  stream.state === "live"
                    ? "animate-pulse bg-jade-400"
                    : stream.state === "error"
                      ? "bg-red-400"
                      : "animate-pulse bg-amber-glow",
                ].join(" ")}
              />
              {stream.state === "live" ? "live socket" : stream.state === "error" ? "socket down · polling" : "connecting"}{" "}
              · @{me.handle}
            </p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <button
              onClick={() => {
                haptic([12, 30, 12]);
                void vault.relock();
              }}
              className="grid h-9 w-9 place-items-center rounded-full border border-white/8 text-vault-muted transition hover:border-amber-glow/40 hover:text-amber-glow"
              aria-label="Relock to calculator"
              title="Relock to calculator"
            >
              <IconLock size={16} />
            </button>
            <button onClick={() => setTab("settings")} aria-label="Profile and settings">
              <Avatar user={me} size={36} ring={tab === "settings"} presence />
            </button>
          </div>
        </div>

        <nav className="mt-3 flex px-2">
          {TABS.map((t) => {
            const active = tab === t.id;
            const badge = t.id === "chats" ? totalUnread : 0;
            return (
              <button
                key={t.id}
                onClick={() => {
                  haptic(8);
                  setTab(t.id);
                  if (t.id !== "chats") setOpenId(null);
                }}
                className="relative flex flex-1 items-center justify-center gap-2 py-2.5"
              >
                <t.icon size={16} className={active ? "text-jade-300" : "text-vault-muted"} />
                <span
                  className={[
                    "font-display text-[12.5px] tracking-[0.14em] uppercase transition",
                    active ? "text-jade-300" : "text-vault-muted",
                  ].join(" ")}
                >
                  {t.label}
                </span>
                {badge > 0 && (
                  <span className="jade-glow grid h-4 min-w-4 place-items-center rounded-full bg-jade-500 px-1 font-mono text-[9.5px] font-bold text-vault-950">
                    {badge}
                  </span>
                )}
                {active && (
                  <motion.span
                    layoutId="tab-indicator"
                    transition={{ type: "spring", stiffness: 420, damping: 34 }}
                    className="absolute inset-x-2 -bottom-px h-[2.5px] rounded-full bg-gradient-to-r from-jade-500 via-jade-300 to-jade-500 shadow-[0_0_14px_rgba(37,211,102,.8)]"
                  />
                )}
              </button>
            );
          })}
        </nav>
      </header>

      {/* ── body ── */}
      <div className="relative min-h-0 flex-1">
        {!ready ? (
          <VaultSkeleton />
        ) : (
          <>
            {/* desktop / tablet two-pane for chats */}
            <div className="hidden h-full lg:block">
              {tab === "chats" ? (
                <div className="grid h-full grid-cols-[minmax(340px,400px)_1fr]">
                  <div className="min-h-0 border-r border-white/6 bg-vault-900/60">
                    <motion.div
                      initial={{ opacity: 0, x: -14 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.18 }}
                      className="h-full"
                    >
                      <ChatList onOpen={openThread} />
                    </motion.div>
                  </div>
                  <div className="min-h-0">
                    {openId ? (
                      <ChatScreen key={openId} conversationId={openId} onBack={() => setOpenId(null)} embedded />
                    ) : (
                      <EmptyPane />
                    )}
                  </div>
                </div>
              ) : (
                <motion.div
                  key={tab}
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.22 }}
                  className="mx-auto h-full w-full max-w-[1020px]"
                >
                  {tab === "calls" && <CallsTab onOpenThread={openThread} />}
                  {tab === "stickers" && <StickersTab onOpenThread={openThread} />}
                  {tab === "settings" && <SettingsTab />}
                </motion.div>
              )}
            </div>

            {/* mobile: single pane with slide transitions */}
            <div className="h-full lg:hidden">
              <AnimatePresence mode="wait" initial={false}>
                {tab === "chats" && openId ? (
                  <motion.div
                    key="chat"
                    initial={{ x: "100%" }}
                    animate={{ x: 0 }}
                    exit={{ x: "100%" }}
                    transition={{ type: "spring", stiffness: 320, damping: 34 }}
                    className="h-full"
                  >
                    <ChatScreen conversationId={openId} onBack={() => setOpenId(null)} />
                  </motion.div>
                ) : (
                  <motion.div
                    key={tab}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -12 }}
                    transition={{ duration: 0.18 }}
                    className="h-full"
                  >
                    {tab === "chats" && <ChatList onOpen={openThread} />}
                    {tab === "calls" && <CallsTab onOpenThread={openThread} />}
                    {tab === "stickers" && <StickersTab onOpenThread={openThread} />}
                    {tab === "settings" && <SettingsTab />}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </>
        )}
      </div>

      {/* ── toasts ── */}
      <div className="pointer-events-none fixed inset-x-0 bottom-6 z-[90] flex flex-col items-center gap-2 px-4">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.button
              key={t.id}
              layout
              initial={{ opacity: 0, y: 22, scale: 0.94 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 12, scale: 0.96 }}
              transition={{ type: "spring", stiffness: 340, damping: 28 }}
              onClick={() => dismissToast(t.id)}
              className={[
                "pointer-events-auto max-w-[420px] rounded-2xl border px-4 py-2.5 text-left font-mono text-[11.5px] backdrop-blur-xl",
                t.tone === "bad"
                  ? "border-red-500/35 bg-red-950/85 text-red-200"
                  : t.tone === "warn"
                    ? "border-amber-glow/35 bg-amber-950/80 text-amber-glow"
                    : "border-jade-500/35 bg-vault-850/92 text-jade-300",
              ].join(" ")}
            >
              {t.text}
            </motion.button>
          ))}
        </AnimatePresence>
      </div>

      {/* ── call overlay ── */}
      <AnimatePresence>{activeCall && <CallOverlay key={activeCall.id} call={activeCall} />}</AnimatePresence>
    </div>
  );
}

function EmptyPane() {
  return (
    <div className="vault-doodle grid h-full place-items-center p-10">
      <div className="max-w-md text-center">
        <motion.div
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
          className="mx-auto grid h-24 w-24 place-items-center rounded-[28px] border border-jade-500/20 bg-vault-850/80 text-jade-300 jade-glow"
        >
          <IconShield size={40} />
        </motion.div>
        <h2 className="mt-6 font-display text-[24px] font-semibold text-vault-text">
          Four seats. No strangers.
        </h2>
        <p className="mt-2.5 text-[13.5px] leading-relaxed text-vault-muted">
          Pick a thread on the left to open it. Everything you send here carries a 48-hour fuse and
          is deleted by the server on the next sweep — no archive, no export, no trace.
        </p>
        <div className="mt-6 flex flex-wrap items-center justify-center gap-2 font-mono text-[10.5px] tracking-[0.14em] text-vault-muted uppercase">
          {["74 + 88 = vault", "48h auto-purge", "no sign-ups"].map((chip) => (
            <span key={chip} className="rounded-full border border-white/8 bg-vault-850/70 px-3 py-1.5">
              {chip}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

function VaultSkeleton() {
  return (
    <div className="h-full p-4">
      <div className="mx-auto max-w-[820px] space-y-3">
        {Array.from({ length: 6 }, (_, i) => (
          <div key={i} className="flex items-center gap-3.5 rounded-2xl border border-white/5 bg-vault-850/50 p-3">
            <span className="h-12 w-12 shrink-0 animate-pulse rounded-full bg-white/6" />
            <span className="flex-1 space-y-2">
              <span className="block h-3 w-1/3 animate-pulse rounded-full bg-white/7" />
              <span className="block h-2.5 w-2/3 animate-pulse rounded-full bg-white/5" />
            </span>
          </div>
        ))}
      </div>
      <p className="mt-6 text-center font-mono text-[11px] tracking-[0.2em] text-vault-muted uppercase">
        decrypting vault…
      </p>
    </div>
  );
}
