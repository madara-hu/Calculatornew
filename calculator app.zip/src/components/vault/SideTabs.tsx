"use client";

import { AnimatePresence, motion } from "framer-motion";
import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { Avatar } from "@/components/ui/Avatar";
import {
  IconBolt,
  IconDownload,
  IconFlame,
  IconLink,
  IconLock,
  IconLogout,
  IconPhone,
  IconPlus,
  IconShield,
  IconSticker,
  IconTrash,
  IconVideo,
} from "@/components/ui/icons";
import { haptic } from "@/lib/client";
import { clockTime, dayLabel, durationLabel, fileToDataUri, relativeTime } from "@/lib/format";
import { useVault } from "@/lib/vault-store";
import type { RealtimeStatus } from "@/lib/realtime";

/* ─────────────────────────── CALLS ─────────────────────────── */

export function CallsTab({ onOpenThread }: { onOpenThread: (id: number) => void }) {
  const { calls, threads, userById, titleFor, me, placeCall } = useVault();

  return (
    <div className="scroll-thin h-full overflow-y-auto pb-8">
      <div className="px-4 pt-4">
        <p className="font-mono text-[10.5px] tracking-[0.2em] text-vault-muted uppercase">
          quick dial · the four
        </p>
        <div className="mt-3 flex gap-3 overflow-x-auto pb-1 no-scrollbar">
          {threads
            .filter((t) => t.kind === "dm")
            .map((t) => {
              const other = userById(t.members.find((id) => id !== me.id) ?? 0);
              if (!other) return null;
              return (
                <div key={t.id} className="flex w-[74px] shrink-0 flex-col items-center gap-1.5">
                  <div className="relative">
                    <button
                      onClick={() => {
                        haptic(10);
                        void placeCall(t.id, "audio");
                      }}
                      className="block"
                      aria-label={`Voice call ${other.name}`}
                    >
                      <Avatar user={other} size={54} presence />
                    </button>
                    <button
                      onClick={() => {
                        haptic(10);
                        void placeCall(t.id, "video");
                      }}
                      className="jade-glow absolute -bottom-1 -right-1 grid h-6 w-6 place-items-center rounded-full bg-jade-500 text-vault-950"
                      aria-label={`Video call ${other.name}`}
                    >
                      <IconVideo size={12} />
                    </button>
                  </div>
                  <span className="truncate font-mono text-[10.5px] text-vault-muted">{other.name}</span>
                </div>
              );
            })}
        </div>
      </div>

      <div className="mt-5 px-4">
        <p className="font-mono text-[10.5px] tracking-[0.2em] text-vault-muted uppercase">
          call log · {calls.length} entries
        </p>
      </div>

      <div className="mt-2 space-y-1 px-2">
        {calls.length === 0 && (
          <p className="px-4 py-8 text-center text-[13px] text-vault-muted">
            No calls yet. Tap an avatar above to ring someone.
          </p>
        )}
        {calls.map((c, i) => {
          const conv = threads.find((t) => t.id === c.conversationId);
          if (!conv) return null;
          const caller = userById(c.callerId);
          const mine = c.callerId === me.id;
          const missed = c.status === "missed" || c.status === "declined";
          return (
            <motion.button
              key={c.id}
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: Math.min(i * 0.03, 0.24) }}
              onClick={() => onOpenThread(c.conversationId)}
              className="flex w-full items-center gap-3.5 rounded-2xl px-3 py-2.5 text-left transition hover:bg-white/4"
            >
              <Avatar
                user={conv.kind === "group" ? { name: titleFor(conv), hue: 158 } : (caller ?? { name: "?", hue: 158 })}
                title={conv.kind === "group" ? undefined : caller?.name}
                group={conv.kind === "group"}
                size={44}
              />
              <div className="min-w-0 flex-1">
                <div
                  className={[
                    "truncate font-display text-[15px] font-semibold",
                    missed ? "text-red-300" : "text-vault-text",
                  ].join(" ")}
                >
                  {titleFor(conv)}
                </div>
                <div className="flex items-center gap-1.5 font-mono text-[11px] text-vault-muted">
                  <span className={missed ? "text-red-300/80" : "text-jade-300/80"}>
                    {mine ? "↗ outgoing" : "↙ incoming"}
                  </span>
                  <span>·</span>
                  <span>
                    {c.status === "completed" ? durationLabel(c.durationSeconds) : c.status}
                  </span>
                  <span>·</span>
                  <span>{c.kind === "video" ? "video" : "voice"}</span>
                </div>
              </div>
              <div className="flex shrink-0 flex-col items-end gap-1.5">
                <span className="font-mono text-[10.5px] text-vault-muted">
                  {relativeTime(c.startedAt)}
                </span>
                <span className="grid h-8 w-8 place-items-center rounded-full border border-white/8 text-jade-300 transition hover:border-jade-500/40">
                  {c.kind === "video" ? <IconVideo size={14} /> : <IconPhone size={14} />}
                </span>
              </div>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}

/* ─────────────────────────── STICKERS ─────────────────────────── */

export function StickersTab({ onOpenThread }: { onOpenThread: (id: number) => void }) {
  const { stickers, threads, me, addSticker, removeSticker, send, titleFor, notify } = useVault();
  const [url, setUrl] = useState("");
  const [label, setLabel] = useState("");
  const [busy, setBusy] = useState(false);
  const [target, setTarget] = useState<{ id: number; label: string; data: string } | null>(null);

  const packs = Array.from(new Set(stickers.map((s) => s.pack)));
  const mine = stickers.filter((s) => s.ownerId === me.id).length;

  const submit = async () => {
    if (!url.trim()) {
      notify("Paste an image link first", "warn");
      return;
    }
    setBusy(true);
    try {
      await addSticker({ label: label.trim() || "Linked sticker", data: url.trim() });
      setUrl("");
      setLabel("");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="scroll-thin h-full overflow-y-auto pb-8">
      <div className="px-4 pt-4">
        <div className="grid grid-cols-3 gap-2.5">
          {[
            { k: "stickers", v: String(stickers.length) },
            { k: "packs", v: String(packs.length) },
            { k: "yours", v: String(mine) },
          ].map((s) => (
            <div key={s.k} className="rounded-2xl border border-white/8 bg-vault-800/60 px-3 py-2.5 text-center">
              <div className="font-mono text-[17px] text-jade-300">{s.v}</div>
              <div className="mt-0.5 font-mono text-[9.5px] tracking-[0.14em] text-vault-muted uppercase">
                {s.k}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 rounded-3xl border border-white/8 bg-vault-850/70 p-4">
          <p className="flex items-center gap-2 font-display text-[13px] tracking-[0.16em] text-jade-300 uppercase">
            <IconLink size={15} /> import from another app
          </p>
          <p className="mt-1.5 text-[12.5px] leading-relaxed text-vault-muted">
            Paste any sticker link (Telegram, Discord, a CDN, a shared drive) or upload a
            PNG / WEBP / SVG from this device. Imports are stored with your handle and can be
            deleted any time.
          </p>
          <div className="mt-3 flex flex-col gap-2 sm:flex-row">
            <input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://cdn.example.com/sticker.webp"
              className="flex-1 rounded-xl border border-white/10 bg-vault-800 px-3 py-2.5 font-mono text-[12px] text-vault-text placeholder:text-vault-muted/60 focus:border-jade-500/40 focus:outline-none"
            />
            <input
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder="label"
              className="rounded-xl border border-white/10 bg-vault-800 px-3 py-2.5 font-mono text-[12px] text-vault-text placeholder:text-vault-muted/60 focus:border-jade-500/40 focus:outline-none sm:w-28"
            />
            <label className="cursor-pointer rounded-xl border border-white/10 px-3 py-2.5 text-center font-mono text-[11px] tracking-[0.12em] text-vault-muted uppercase transition hover:border-jade-500/40 hover:text-jade-300">
              upload
              <input
                type="file"
                accept="image/png,image/webp,image/gif,image/svg+xml"
                className="hidden"
                onChange={async (e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  setBusy(true);
                  try {
                    const dataUri = await fileToDataUri(f, 900_000);
                    await addSticker({ label: f.name.replace(/\.[^.]+$/, ""), data: dataUri });
                  } finally {
                    setBusy(false);
                  }
                }}
              />
            </label>
            <button
              onClick={() => void submit()}
              disabled={busy}
              className="rounded-xl bg-jade-500 px-4 py-2.5 font-mono text-[11px] tracking-[0.14em] text-vault-950 uppercase disabled:opacity-60"
            >
              import
            </button>
          </div>
        </div>
      </div>

      <div className="mt-5 px-4">
        {packs.map((pack) => (
          <div key={pack} className="mb-5">
            <div className="mb-2 flex items-center justify-between">
              <p className="font-display text-[12.5px] tracking-[0.18em] text-vault-text uppercase">
                {pack}
              </p>
              <span className="font-mono text-[10.5px] text-vault-muted">
                {stickers.filter((s) => s.pack === pack).length} items
              </span>
            </div>
            <div className="grid grid-cols-4 gap-2.5 sm:grid-cols-5 lg:grid-cols-6">
              {stickers
                .filter((s) => s.pack === pack)
                .map((s) => (
                  <motion.button
                    key={s.id}
                    layout
                    whileHover={{ y: -3, rotate: -2 }}
                    whileTap={{ scale: 0.93 }}
                    onClick={() => {
                      haptic(9);
                      setTarget({ id: s.id, label: s.label, data: s.data });
                    }}
                    className="group relative grid aspect-square place-items-center rounded-2xl border border-white/7 bg-vault-800/60 p-2 transition hover:border-jade-500/40"
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={s.data} alt={s.label} className="h-full w-full object-contain" />
                    <span className="absolute inset-x-1 bottom-1 truncate rounded-md bg-black/55 px-1 py-0.5 text-center font-mono text-[8.5px] text-white/75 opacity-0 transition group-hover:opacity-100">
                      {s.source === "builtin" ? "pack" : s.source}
                    </span>
                    {s.ownerId === me.id && (
                      <span
                        role="button"
                        tabIndex={0}
                        onClick={(e) => {
                          e.stopPropagation();
                          void removeSticker(s.id);
                        }}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.stopPropagation();
                            void removeSticker(s.id);
                          }
                        }}
                        className="absolute -right-1.5 -top-1.5 hidden h-6 w-6 place-items-center rounded-full border border-white/15 bg-vault-950 text-red-300 group-hover:grid"
                      >
                        <IconTrash size={12} />
                      </span>
                    )}
                  </motion.button>
                ))}
            </div>
          </div>
        ))}
      </div>

      {/* send-to picker */}
      <AnimatePresence>
        {target && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setTarget(null)}
              className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 270, damping: 30 }}
              className="fixed inset-x-0 bottom-0 z-[55] mx-auto w-full max-w-[520px] rounded-t-[30px] border-t border-white/10 bg-vault-850 p-5"
            >
              <div className="flex items-center gap-3">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={target.data} alt={target.label} className="h-16 w-16 object-contain" />
                <div>
                  <p className="font-display text-[16px] font-semibold text-vault-text">{target.label}</p>
                  <p className="font-mono text-[11px] text-vault-muted">send to a thread</p>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                {threads.map((t) => (
                  <button
                    key={t.id}
                    onClick={async () => {
                      await send({ conversationId: t.id, kind: "sticker", stickerId: String(target.id) });
                      setTarget(null);
                      onOpenThread(t.id);
                    }}
                    className="flex w-full items-center gap-3 rounded-2xl border border-white/7 bg-vault-800/60 px-3 py-2.5 text-left transition hover:border-jade-500/40"
                  >
                    <Avatar
                      user={t.kind === "group" ? { name: titleFor(t), hue: 158 } : undefined}
                      title={t.kind === "group" ? undefined : titleFor(t)}
                      group={t.kind === "group"}
                      size={36}
                    />
                    <span className="font-display text-[14.5px] text-vault-text">{titleFor(t)}</span>
                    <IconSticker size={15} className="ml-auto text-vault-muted" />
                  </button>
                ))}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ─────────────────────────── SETTINGS ─────────────────────────── */

export function SettingsTab() {
  const {
    me,
    alive,
    burned,
    purges,
    purgeHours,
    demoReplies,
    setDemoReplies,
    purgeNow,
    relock,
    signOut,
    messages,
    threads,
    calls,
    stickers,
  } = useVault();
  const [busy, setBusy] = useState(false);

  const rows = [
    { k: "Threads", v: String(threads.length) },
    { k: "Live messages", v: String(messages.length) },
    { k: "Calls logged", v: String(calls.length) },
    { k: "Stickers", v: String(stickers.length) },
  ];

  return (
    <div className="scroll-thin h-full overflow-y-auto pb-10">
      <div className="px-4 pt-4">
        <div className="relative overflow-hidden rounded-[28px] border border-white/8 bg-vault-850/80 p-5">
          <div
            className="pointer-events-none absolute -right-10 -top-14 h-44 w-44 rounded-full blur-3xl"
            style={{ background: `hsl(${me.hue} 75% 50% / .28)` }}
          />
          <div className="relative flex items-center gap-4">
            <Avatar user={me} size={72} ring presence />
            <div className="min-w-0">
              <h2 className="font-display text-[22px] font-semibold text-vault-text">{me.name}</h2>
              <p className="font-mono text-[11.5px] tracking-[0.16em] text-jade-300/85 uppercase">
                @{me.handle} · {me.role}
              </p>
              <p className="mt-1 truncate text-[12.5px] italic text-vault-muted">“{me.tagline}”</p>
            </div>
          </div>
          <div className="relative mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {rows.map((r) => (
              <div key={r.k} className="rounded-2xl border border-white/7 bg-vault-800/60 px-3 py-2 text-center">
                <div className="font-mono text-[16px] text-vault-text">{r.v}</div>
                <div className="font-mono text-[9px] tracking-[0.14em] text-vault-muted uppercase">{r.k}</div>
              </div>
            ))}
          </div>
        </div>

        {/* auto-purge */}
        <section className="mt-4 rounded-[26px] border border-jade-500/18 bg-vault-850/70 p-4">
          <p className="flex items-center gap-2 font-display text-[12.5px] tracking-[0.18em] text-jade-300 uppercase">
            <IconFlame size={15} /> auto-purge engine
          </p>
          <div className="mt-3 grid grid-cols-2 gap-2.5">
            <div className="rounded-2xl border border-white/7 bg-vault-800/60 px-3 py-2.5">
              <div className="font-mono text-[18px] text-jade-300">{alive}</div>
              <div className="font-mono text-[9.5px] tracking-[0.14em] text-vault-muted uppercase">
                messages alive
              </div>
            </div>
            <div className="rounded-2xl border border-white/7 bg-vault-800/60 px-3 py-2.5">
              <div className="font-mono text-[18px] text-amber-glow">{burned}</div>
              <div className="font-mono text-[9.5px] tracking-[0.14em] text-vault-muted uppercase">
                burned all-time
              </div>
            </div>
          </div>
          <p className="mt-3 text-[12.5px] leading-relaxed text-vault-muted">
            Every message is written with a {purgeHours}-hour TTL. The server sweep runs on each
            sync request, so the vault never grows stale — and the client drops expired rows even
            if the tab was asleep.
          </p>
          <button
            onClick={async () => {
              setBusy(true);
              haptic([12, 40, 12]);
              await purgeNow();
              setBusy(false);
            }}
            disabled={busy}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl border border-jade-500/35 bg-jade-500/10 py-3 font-mono text-[11.5px] tracking-[0.18em] text-jade-300 uppercase transition hover:bg-jade-500/18 disabled:opacity-60"
          >
            <IconBolt size={15} /> {busy ? "sweeping…" : "run sweep now"}
          </button>

          <div className="mt-4">
            <p className="font-mono text-[10px] tracking-[0.2em] text-vault-muted uppercase">
              sweep log
            </p>
            <div className="scroll-thin mt-2 max-h-[132px] space-y-1.5 overflow-y-auto pr-1">
              {purges.length === 0 && (
                <p className="font-mono text-[11.5px] text-vault-muted/70">No sweeps recorded yet.</p>
              )}
              {purges.map((p) => (
                <div
                  key={p.id}
                  className="flex items-center justify-between rounded-xl border border-white/6 bg-vault-800/40 px-3 py-1.5"
                >
                  <span className="font-mono text-[11px] text-vault-muted">
                    {dayLabel(p.ranAt)} · {clockTime(p.ranAt)} · {p.trigger}
                  </span>
                  <span
                    className={[
                      "font-mono text-[11px]",
                      p.purged > 0 ? "text-amber-glow" : "text-jade-300/70",
                    ].join(" ")}
                  >
                    {p.purged > 0 ? `-${p.purged}` : "clean"}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* simulator */}
        <section className="mt-4 rounded-[26px] border border-white/8 bg-vault-850/70 p-4">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="flex items-center gap-2 font-display text-[12.5px] tracking-[0.18em] text-vault-text uppercase">
                <IconShield size={15} className="text-jade-300" /> offline companion
              </p>
              <p className="mt-2 max-w-[46ch] text-[12.5px] leading-relaxed text-vault-muted">
                The other three handles reply and occasionally ring you, so a single-device demo
                behaves like a live four-person vault. Turn this off the moment real users are on
                the thread.
              </p>
            </div>
            <button
              onClick={() => {
                haptic(10);
                void setDemoReplies(!demoReplies);
              }}
              className={[
                "relative h-7 w-13 shrink-0 rounded-full border transition",
                demoReplies ? "border-jade-500/50 bg-jade-500/35" : "border-white/12 bg-vault-800",
              ].join(" ")}
              style={{ width: 52 }}
              aria-label="Toggle offline companion"
            >
              <motion.span
                layout
                transition={{ type: "spring", stiffness: 500, damping: 32 }}
                className={[
                  "absolute top-[3px] h-5 w-5 rounded-full",
                  demoReplies ? "left-[26px] bg-jade-400" : "left-[3px] bg-vault-muted",
                ].join(" ")}
              />
            </button>
          </div>
          <p className="mt-3 font-mono text-[10.5px] tracking-[0.14em] text-vault-muted uppercase">
            status: {demoReplies ? "on — replies + inbound rings" : "off — silent vault"}
          </p>
        </section>

        <RealtimePanel />

        {/* handover */}
        <section className="mt-4 rounded-[26px] border border-white/8 bg-vault-850/70 p-4">
          <p className="flex items-center gap-2 font-display text-[12.5px] tracking-[0.18em] text-vault-text uppercase">
            <IconDownload size={15} className="text-amber-glow" /> developer handover
          </p>
          <p className="mt-2 text-[12.5px] leading-relaxed text-vault-muted">
            Build manual, Termux / Codespace commands, Firebase + Cloudflare insertion points and
            the Expo SDK 51 port kit.
          </p>
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            <Link
              href="/guide"
              className="flex items-center justify-center gap-2 rounded-2xl border border-amber-glow/30 bg-amber-glow/8 py-2.5 font-mono text-[11px] tracking-[0.16em] text-amber-glow uppercase transition hover:bg-amber-glow/16"
            >
              open manual
            </Link>
            <a
              href="/api/download/setup-guide"
              className="flex items-center justify-center gap-2 rounded-2xl border border-white/10 py-2.5 font-mono text-[11px] tracking-[0.16em] text-vault-muted uppercase transition hover:border-jade-500/40 hover:text-jade-300"
            >
              <IconDownload size={13} /> setup_guide.md
            </a>
            <a
              href="/api/download/app-json"
              className="flex items-center justify-center gap-2 rounded-2xl border border-white/10 py-2.5 font-mono text-[11px] tracking-[0.16em] text-vault-muted uppercase transition hover:border-jade-500/40 hover:text-jade-300"
            >
              expo app.json
            </a>
            <a
              href="/api/download/app-tsx"
              className="flex items-center justify-center gap-2 rounded-2xl border border-white/10 py-2.5 font-mono text-[11px] tracking-[0.16em] text-vault-muted uppercase transition hover:border-jade-500/40 hover:text-jade-300"
            >
              expo App.tsx
            </a>
          </div>
        </section>

        {/* vault actions */}
        <section className="mt-4 space-y-2">
          <button
            onClick={() => {
              haptic([14, 30, 14]);
              void relock();
            }}
            className="flex w-full items-center justify-center gap-2 rounded-2xl border border-white/10 bg-vault-800/60 py-3.5 font-mono text-[11.5px] tracking-[0.18em] text-vault-text uppercase transition hover:border-jade-500/40 hover:text-jade-300"
          >
            <IconLock size={15} /> relock to calculator
          </button>
          <button
            onClick={() => void signOut()}
            className="flex w-full items-center justify-center gap-2 rounded-2xl border border-red-500/25 bg-red-500/8 py-3.5 font-mono text-[11.5px] tracking-[0.18em] text-red-300 uppercase transition hover:bg-red-500/16"
          >
            <IconLogout size={15} /> sign out & burn session
          </button>
        </section>

        <p className="mt-5 text-center font-mono text-[10px] tracking-[0.18em] text-vault-muted/60 uppercase">
          hustler calculator v1.0 · next.js + postgres · 4 seats · no sign-ups
        </p>
        <p className="mt-1.5 flex items-center justify-center gap-1.5 text-center font-mono text-[10px] text-vault-muted/45">
          <IconPlus size={11} /> seats are fixed in src/lib/config.ts
        </p>
      </div>
    </div>
  );
}

/* ─────────────────────────── REALTIME ─────────────────────────── */

function Dot({ tone }: { tone: "ok" | "warn" | "bad" | "idle" }) {
  const colour =
    tone === "ok" ? "bg-jade-400" : tone === "warn" ? "bg-amber-glow" : tone === "bad" ? "bg-red-400" : "bg-white/25";
  return (
    <span className="relative flex h-2 w-2 shrink-0">
      {tone === "ok" && <span className={`absolute inline-flex h-full w-full animate-ping rounded-full ${colour} opacity-70`} />}
      <span className={`relative inline-flex h-2 w-2 rounded-full ${colour}`} />
    </span>
  );
}

function Env({ name }: { name: string }) {
  return (
    <code className="rounded-md bg-white/8 px-1.5 py-0.5 font-mono text-[11.5px] text-amber-glow">
      {name}
    </code>
  );
}

export function RealtimePanel() {
  const { stream } = useVault();
  const [status, setStatus] = useState<RealtimeStatus | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/realtime", { cache: "no-store" });
      const data = (await res.json()) as { status: RealtimeStatus };
      setStatus(data.status);
    } catch {
      /* panel is non-critical */
    }
  }, []);

  useEffect(() => {
    void load();
    const t = window.setInterval(load, 12_000);
    return () => window.clearInterval(t);
  }, [load]);

  const test = async () => {
    setBusy(true);
    try {
      const res = await fetch("/api/realtime", { method: "POST" });
      const data = (await res.json()) as { status: RealtimeStatus };
      setStatus(data.status);
    } finally {
      setBusy(false);
    }
  };

  const socketTone =
    stream.state === "live" ? "ok" : stream.state === "connecting" ? "warn" : stream.state === "error" ? "bad" : "idle";

  return (
    <section className="mt-4 rounded-[26px] border border-white/8 bg-vault-850/70 p-4">
      <div className="flex items-center justify-between gap-3">
        <p className="flex items-center gap-2 font-display text-[12.5px] tracking-[0.18em] text-vault-text uppercase">
          <IconBolt size={15} className="text-jade-300" /> realtime engine
        </p>
        <span className="flex items-center gap-1.5 rounded-full border border-white/8 px-2.5 py-1 font-mono text-[10px] tracking-[0.14em] text-vault-muted uppercase">
          <Dot tone={socketTone} />
          {stream.state}
        </span>
      </div>

      <p className="mt-2 text-[12.5px] leading-relaxed text-vault-muted">
        Transport: <span className="font-mono text-[12px] text-jade-300">{status?.transport ?? "…"}</span>.
        Server-Sent Events push every message, call, sticker, read receipt and purge instantly —
        polling only runs if the socket goes quiet for 45s.
      </p>

      <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
        {[
          { k: "socket", v: stream.url.replace(/^https?:\/\//, "").slice(0, 18) },
          { k: "received", v: String(stream.received) },
          { k: "published", v: String(status?.sse.published ?? 0) },
          { k: "open sockets", v: String(status?.sse.subscribers ?? 0) },
        ].map((c) => (
          <div key={c.k} className="rounded-2xl border border-white/7 bg-vault-800/60 px-3 py-2">
            <div className="truncate font-mono text-[13px] text-vault-text">{c.v}</div>
            <div className="font-mono text-[9px] tracking-[0.14em] text-vault-muted uppercase">{c.k}</div>
          </div>
        ))}
      </div>

      {/* cloudflare */}
      <div className="mt-3 rounded-2xl border border-white/7 bg-vault-800/45 p-3">
        <div className="flex items-center gap-2">
          <Dot tone={!status?.cloudflare.configured ? "idle" : status.cloudflare.ok ? "ok" : "bad"} />
          <span className="font-display text-[12px] tracking-[0.16em] text-vault-text uppercase">
            cloudflare edge relay
          </span>
          <span className="ml-auto font-mono text-[10.5px] text-vault-muted">
            {status?.cloudflare.configured
              ? `${status.cloudflare.published} sent · ${status.cloudflare.failed} failed`
              : "not configured"}
          </span>
        </div>
        {status?.cloudflare.configured ? (
          <p className="mt-2 font-mono text-[11.5px] leading-relaxed text-vault-muted">
            {status.cloudflare.host} · {status.cloudflare.probe}
            {status.cloudflare.lastError ? ` · last error: ${status.cloudflare.lastError}` : ""}
          </p>
        ) : (
          <p className="mt-2 text-[12px] leading-relaxed text-vault-muted">
            Set <Env name="CLOUDFLARE_RELAY_URL" /> and <Env name="CLOUDFLARE_RELAY_TOKEN" /> in
            .env, then deploy <span className="font-mono text-[11.5px] text-jade-300">handover/cloudflare/worker.ts</span>{" "}
            with <span className="font-mono text-[11.5px] text-jade-300">wrangler deploy</span>. Optional browser
            socket: <Env name="NEXT_PUBLIC_CLOUDFLARE_STREAM_URL" />
          </p>
        )}
      </div>

      {/* firebase */}
      <div className="mt-2 rounded-2xl border border-white/7 bg-vault-800/45 p-3">
        <div className="flex items-center gap-2">
          <Dot tone={!status?.firebase.configured ? "idle" : status.firebase.ok ? "ok" : "bad"} />
          <span className="font-display text-[12px] tracking-[0.16em] text-vault-text uppercase">
            firebase / firestore mirror
          </span>
          <span className="ml-auto font-mono text-[10.5px] text-vault-muted">
            {status?.firebase.configured
              ? `${status.firebase.mirrored} mirrored · ${status.firebase.failed} failed`
              : "not configured"}
          </span>
        </div>
        {status?.firebase.configured ? (
          <p className="mt-2 font-mono text-[11.5px] leading-relaxed text-vault-muted">
            project {status.firebase.projectId} · {status.firebase.serviceAccount}
            {status.firebase.lastError ? ` · last error: ${status.firebase.lastError}` : " · healthy"}
          </p>
        ) : (
          <p className="mt-2 text-[12px] leading-relaxed text-vault-muted">
            Set <Env name="FIREBASE_PROJECT_ID" />, <Env name="FIREBASE_CLIENT_EMAIL" /> and{" "}
            <Env name="FIREBASE_PRIVATE_KEY" /> (service account JSON, \n escaped). Every message and
            call is then mirrored to <span className="font-mono text-[11.5px] text-jade-300">threads/{"{id}"}/messages</span>{" "}
            so the Expo build can use <span className="font-mono text-[11.5px] text-jade-300">onSnapshot</span>.
          </p>
        )}
      </div>

      <div className="mt-3 flex gap-2">
        <button
          onClick={() => void load()}
          className="flex-1 rounded-2xl border border-white/10 py-2.5 font-mono text-[11px] tracking-[0.16em] text-vault-muted uppercase transition hover:border-jade-500/40 hover:text-jade-300"
        >
          refresh
        </button>
        <button
          onClick={() => void test()}
          disabled={busy}
          className="flex-1 rounded-2xl border border-jade-500/35 bg-jade-500/10 py-2.5 font-mono text-[11px] tracking-[0.16em] text-jade-300 uppercase transition hover:bg-jade-500/18 disabled:opacity-60"
        >
          {busy ? "firing…" : "send test event"}
        </button>
      </div>
    </section>
  );
}
