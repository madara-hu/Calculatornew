import { SECRET_SEQUENCE } from "@/lib/config";

export type Token = { type: "num" | "op"; value: string };

const OPS = ["+", "−", "×", "÷", "%"] as const;

export function isOp(ch: string): ch is (typeof OPS)[number] {
  return (OPS as readonly string[]).includes(ch);
}

/** Compact an expression so `74 + 88` and `074+88.0` both match the key. */
export function normalize(expr: string) {
  return expr
    .replace(/\s+/g, "")
    .replace(/×/g, "*")
    .replace(/÷/g, "/")
    .replace(/−/g, "-")
    .replace(/(\d)\.0+(?=\D|$)/g, "$1")
    .replace(/(^|[+\-*/])0+(\d)/g, "$1$2");
}

export const isSecretSequence = (expr: string) => normalize(expr) === normalize(SECRET_SEQUENCE);

export function tokenize(expr: string): Token[] {
  const out: Token[] = [];
  let buffer = "";
  for (const ch of expr.replace(/\s+/g, "")) {
    if (isOp(ch)) {
      if (buffer) out.push({ type: "num", value: buffer });
      buffer = "";
      out.push({ type: "op", value: ch });
    } else if (/[\d.]/.test(ch)) {
      buffer += ch;
    }
  }
  if (buffer) out.push({ type: "num", value: buffer });
  return out;
}

/** Two-pass evaluator with correct × ÷ % before + − precedence. */
export function evaluate(expr: string): number | null {
  const tokens = tokenize(expr);
  if (!tokens.length || tokens[0].type !== "num") return null;

  const values: number[] = [];
  const ops: string[] = [];

  const apply = (a: number, b: number, op: string): number | null => {
    switch (op) {
      case "+": return a + b;
      case "−": return a - b;
      case "×": return a * b;
      case "÷": return b === 0 ? null : a / b;
      case "%": return a * (b / 100);
      default: return null;
    }
  };

  let index = 0;
  let current = Number(tokens[index++].value);
  if (!Number.isFinite(current)) return null;

  while (index < tokens.length) {
    const op = tokens[index++].value;
    if (op === "%") {
      // postfix percent: 25% → 0.25
      current = current / 100;
      continue;
    }
    if (index >= tokens.length) return null;
    const next = Number(tokens[index++].value);
    if (!Number.isFinite(next)) return null;
    if (op === "×" || op === "÷") {
      const r = apply(current, next, op);
      if (r === null) return null;
      current = r;
    } else {
      values.push(current);
      ops.push(op);
      current = next;
    }
  }
  values.push(current);

  let result = values[0];
  for (let i = 0; i < ops.length; i++) {
    const r = apply(result, values[i + 1], ops[i]);
    if (r === null) return null;
    result = r;
  }
  return Number.isFinite(result) ? result : null;
}

export function formatNumber(n: number): string {
  if (!Number.isFinite(n)) return "Error";
  const abs = Math.abs(n);
  if (abs !== 0 && (abs >= 1e12 || abs < 1e-9)) {
    return n.toExponential(6).replace("e", "E");
  }
  const rounded = Math.round(n * 1e10) / 1e10;
  const [int, dec] = String(rounded).split(".");
  const grouped = int.replace("-", "").replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  return `${rounded < 0 ? "-" : ""}${grouped}${dec ? "." + dec : ""}`;
}

/** Live preview of what "=" would produce, without committing it. */
export function preview(expr: string): string {
  const compact = expr.replace(/\s+/g, "");
  if (!/[+\-−×÷%]/.test(compact.slice(1))) return "";
  const trimmed = compact.replace(/[+\-−×÷%]$/, "");
  const value = evaluate(trimmed);
  if (value === null) return "";
  const shown = formatNumber(value);
  return shown === compact ? "" : shown;
}
