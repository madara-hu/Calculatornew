"use client";

import { AnimatePresence, motion } from "framer-motion";
import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  IconBackspace,
  IconBolt,
  IconClose,
  IconHistory,
  IconTrash,
} from "@/components/ui/icons";
import { haptic } from "@/lib/client";
import { SECRET_SEQUENCE } from "@/lib/config";
import { clockTime } from "@/lib/format";
import { evaluate, formatNumber, isSecretSequence, preview } from "./calcEngine";

type HistoryEntry = { expr: string; result: string; at: string };

const HISTORY_KEY = "hustler.calc.tape";

const KEYS: { label: string; kind: "num" | "op" | "fn" | "eq"; span?: number }[] = [
  { label: "C", kind: "fn" },
  { label: "⌫", kind: "fn" },
  { label: "%", kind: "op" },
  { label: "÷", kind: "op" },
  { label: "7", kind: "num" },
  { label: "8", kind: "num" },
  { label: "9", kind: "num" },
  { label: "×", kind: "op" },
  { label: "4", kind: "num" },
  { label: "5", kind: "num" },
  { label: "6", kind: "num" },
  { label: "−", kind: "op" },
  { label: "1", kind: "num" },
  { label: "2", kind: "num" },
  { label: "3", kind: "num" },
  { label: "+", kind: "op" },
  { label: "±", kind: "fn" },
  { label: "0", kind: "num" },
  { label: ".", kind: "num" },
  { label: "=", kind: "eq" },
];

export default function Calculator({ onUnlock }: { onUnlock: () => void }) {
  const [expr, setExpr] = useState("0");
  const [result, setResult] = useState<string | null>(null);
  const [tape, setTape] = useState<HistoryEntry[]>([]);
  const [showTape, setShowTape] = useState(false);
  const [breach, setBreach] = useState(false);
  const [shake, setShake] = useState(0);
  const unlocked = useRef(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(HISTORY_KEY);
      if (raw) setTape(JSON.parse(raw) as HistoryEntry[]);
    } catch {
      /* first run */
    }
  }, []);

  const persist = (next: HistoryEntry[]) => {
    setTape(next);
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(next.slice(0, 40)));
    } catch {
      /* quota */
    }
  };

  const live = result ?? expr;
  const hint = useMemo(() => (result ? "" : preview(expr)), [expr, result]);

  const press = useCallback(
    (key: string) => {
      if (unlocked.current) return;
      haptic(key === "=" ? [14, 40, 26] : 9);

      if (key === "C") {
        setExpr("0");
        setResult(null);
        return;
      }
      if (key === "⌫") {
        setResult(null);
        setExpr((e) => (e.length <= 1 ? "0" : e.slice(0, -1)));
        return;
      }
      if (key === "±") {
        setExpr((e) => {
          if (e === "0") return "-";
          return e.startsWith("-") ? e.slice(1) : `-${e}`;
        });
        return;
      }
      if (key === "=") {
        if (isSecretSequence(expr)) {
          unlocked.current = true;
          setBreach(true);
          haptic([20, 60, 20, 60, 120]);
          window.setTimeout(onUnlock, 900);
          return;
        }
        const value = evaluate(expr);
        if (value === null) {
          setShake((n) => n + 1);
          haptic(60);
          setResult("Error");
          window.setTimeout(() => setResult(null), 900);
          return;
        }
        const shown = formatNumber(value);
        setResult(null);
        persist([{ expr, result: shown, at: new Date().toISOString() }, ...tape]);
        setExpr(shown.replace(/ /g, ""));
        return;
      }

      setResult(null);
      setExpr((e) => {
        const isOperator = ["+", "−", "×", "÷", "%"].includes(key);
        if (e === "0" && !isOperator && key !== ".") return key;
        if (e === "Error") return isOperator ? "0" : key;
        if (isOperator) {
          if (["+", "−", "×", "÷", "%"].includes(e.slice(-1))) return e.slice(0, -1) + key;
          return e + key;
        }
        if (key === ".") {
          const tail = e.split(/[+\-−×÷%]/).pop() ?? "";
          if (tail.includes(".")) return e;
          if (tail === "") return `${e}0.`;
        }
        if (e.replace(/[^0-9]/g, "").length >= 16) return e;
        return e + key;
      });
    },
    [onUnlock, tape, expr],
  );

  /* physical keyboard support */
  useEffect(() => {
    const map: Record<string, string> = {
      "*": "×",
      "/": "÷",
      "-": "−",
      Enter: "=",
      "=": "=",
      Backspace: "⌫",
      Escape: "C",
      Delete: "C",
      "%": "%",
      ".": ".",
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey) return;
      const k = map[e.key] ?? (/^[0-9]$/.test(e.key) ? e.key : null);
      if (!k) {
        if (e.key.toLowerCase() === "h") setShowTape((s) => !s);
        return;
      }
      e.preventDefault();
      press(k);
      const el = document.querySelector<HTMLElement>(`[data-key="${CSS.escape(k)}"]`);
      el?.classList.add("key-flash");
      window.setTimeout(() => el?.classList.remove("key-flash"), 140);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [press]);

  const fontSize = live.length > 16 ? 34 : live.length > 12 ? 44 : live.length > 8 ? 54 : 64;

  return (
    <div className="cover-ambient relative flex min-h-dvh w-full flex-col items-center overflow-hidden px-4 pb-6 pt-5 sm:px-8">
      {/* ambient sweep */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-64 overflow-hidden opacity-60">
        <div className="animate-sweep h-40 w-1/3 -skew-x-12 bg-gradient-to-r from-transparent via-amber-glow/12 to-transparent blur-2xl" />
      </div>

      <div className="relative flex w-full max-w-[1120px] flex-1 items-stretch gap-8 xl:justify-center">
        {/* ── the device ── */}
        <motion.div
          initial={{ opacity: 0, y: 26, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ type: "spring", stiffness: 190, damping: 24 }}
          className="relative mx-auto flex w-full max-w-[440px] flex-col"
        >
          <header className="mb-4 flex items-center justify-between px-1">
            <div className="flex items-baseline gap-2">
              <span className="font-display text-[13px] font-bold tracking-[0.42em] text-amber-glow/90 uppercase">
                Hustler
              </span>
              <span className="font-display text-[13px] font-medium tracking-[0.34em] text-mint-text/45 uppercase">
                Calculator
              </span>
            </div>
            <button
              onClick={() => {
                haptic(8);
                setShowTape(true);
              }}
              className="grid h-9 w-9 place-items-center rounded-full border border-white/8 bg-white/4 text-mint-text/60 transition hover:border-amber-glow/40 hover:text-amber-glow active:scale-92 xl:hidden"
              aria-label="Calculation tape"
            >
              <IconHistory size={18} />
            </button>
          </header>

          <motion.div
            key={shake}
            animate={shake ? { x: [0, -9, 8, -5, 3, 0] } : {}}
            transition={{ duration: 0.42 }}
            className="relative overflow-hidden rounded-[30px] border border-white/8 bg-graphite-900/85 p-5 shadow-[0_40px_80px_-40px_rgba(0,0,0,.95)] backdrop-blur-xl"
          >
            {/* display */}
            <div className="relative mb-5 rounded-[22px] border border-white/6 bg-graphite-950/80 px-5 py-6">
              <div className="absolute inset-x-6 top-0 h-px bg-gradient-to-r from-transparent via-amber-glow/45 to-transparent" />
              <div className="flex min-h-[22px] items-center justify-between gap-3 font-mono text-[12px] tracking-wide text-mint-text/35">
                <span className="truncate">{result ? `${expr} =` : hint ? "" : "\u00A0"}</span>
                <span className="flex items-center gap-1.5 text-amber-glow/55">
                  <IconBolt size={12} />
                  <span className="uppercase tracking-[0.22em]">offline</span>
                </span>
              </div>
              <AnimatePresence mode="wait">
                <motion.div
                  key={live}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.16 }}
                  className="mt-1 text-right font-mono font-light text-amber-glow text-glow-amber"
                  style={{ fontSize, lineHeight: 1.12, letterSpacing: "-0.02em" }}
                >
                  {live}
                </motion.div>
              </AnimatePresence>
              {hint && !result ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="mt-1 text-right font-mono text-[15px] text-mint-text/30"
                >
                  = {hint}
                </motion.div>
              ) : null}
              <div className="mt-3 h-px w-full overflow-hidden bg-white/5">
                <motion.div
                  className="h-px bg-gradient-to-r from-transparent via-amber-glow to-transparent"
                  animate={{ x: ["-100%", "100%"] }}
                  transition={{ duration: 3.4, repeat: Infinity, ease: "easeInOut" }}
                />
              </div>
            </div>

            {/* keypad */}
            <div className="grid grid-cols-4 gap-2.5 sm:gap-3">
              {KEYS.map((k) => {
                const isNum = k.kind === "num";
                return (
                  <motion.button
                    key={k.label}
                    data-key={k.label}
                    onClick={() => press(k.label)}
                    whileTap={{ scale: 0.93 }}
                    transition={{ type: "spring", stiffness: 520, damping: 26 }}
                    className={[
                      "group relative h-[62px] overflow-hidden rounded-[20px] sm:h-[70px]",
                      k.kind === "eq"
                        ? "amber-glow bg-gradient-to-b from-amber-glow to-amber-deep text-graphite-950"
                        : isNum
                          ? "key-cap text-mint-text"
                          : k.kind === "op"
                            ? "key-cap-op text-amber-glow"
                            : "key-cap text-mint-text/60",
                    ].join(" ")}
                    aria-label={k.label}
                  >
                    <span
                      className={[
                        "relative z-10 font-mono",
                        k.kind === "eq" ? "text-[26px] font-medium" : isNum ? "text-[24px] font-light" : "text-[21px]",
                        k.label === "⌫" ? "translate-y-[1px]" : "",
                      ].join(" ")}
                    >
                      {k.label === "⌫" ? <IconBackspace size={22} className="mx-auto" /> : k.label}
                    </span>
                    <span className="pointer-events-none absolute inset-0 bg-white/0 transition group-active:bg-white/8" />
                  </motion.button>
                );
              })}
            </div>

            <p className="mt-4 text-center font-mono text-[10.5px] tracking-[0.18em] text-mint-text/22 uppercase">
              keyboard enabled · tape kept on device
            </p>
          </motion.div>
        </motion.div>

        {/* ── persistent tape on wide screens ── */}
        <motion.aside
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.12, type: "spring", stiffness: 170, damping: 24 }}
          className="hidden w-[330px] shrink-0 flex-col rounded-[30px] border border-white/7 bg-graphite-900/70 p-5 backdrop-blur-xl xl:flex"
        >
          <TapeBody tape={tape} onPick={(v) => setExpr(v)} onClear={() => persist([])} embedded />
        </motion.aside>
      </div>

      {/* ── tape drawer (compact screens) ── */}
      <AnimatePresence>
        {showTape && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowTape(false)}
              className="fixed inset-0 z-40 bg-black/65 backdrop-blur-[3px]"
            />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", stiffness: 260, damping: 30 }}
              className="fixed inset-y-0 right-0 z-50 flex w-[min(88vw,360px)] flex-col border-l border-white/8 bg-graphite-900 p-5 shadow-2xl"
            >
              <div className="mb-3 flex items-center justify-between">
                <h2 className="font-display text-[13px] tracking-[0.34em] text-amber-glow uppercase">
                  Tape
                </h2>
                <button
                  onClick={() => setShowTape(false)}
                  className="grid h-9 w-9 place-items-center rounded-full border border-white/8 text-mint-text/60 transition hover:text-amber-glow"
                  aria-label="Close tape"
                >
                  <IconClose size={17} />
                </button>
              </div>
              <TapeBody tape={tape} onPick={(v) => { setExpr(v); setShowTape(false); }} onClear={() => persist([])} />
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* ── the breach moment ── */}
      <AnimatePresence>
        {breach && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="pointer-events-none fixed inset-0 z-[60] grid place-items-center bg-vault-950/85 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.4, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 18 }}
              className="relative grid place-items-center"
            >
              <span className="animate-pulsering absolute h-40 w-40 rounded-full border border-jade-400/50" />
              <span className="animate-pulsering absolute h-40 w-40 rounded-full border border-jade-300/30 [animation-delay:.5s]" />
              <span className="jade-glow grid h-28 w-28 place-items-center rounded-full bg-vault-800 font-mono text-[26px] text-jade-300">
                {evaluate(SECRET_SEQUENCE)}
              </span>
              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.25 }}
                className="mt-6 font-display text-[12px] tracking-[0.5em] text-jade-300/80 uppercase"
              >
                vault unlocked
              </motion.p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`.key-flash{box-shadow:0 0 0 1px rgba(255,179,71,.7),0 0 26px -4px rgba(255,179,71,.8)!important;transform:scale(.94)}`}</style>
    </div>
  );
}

function TapeBody({
  tape,
  onPick,
  onClear,
  embedded = false,
}: {
  tape: HistoryEntry[];
  onPick: (value: string) => void;
  onClear: () => void;
  embedded?: boolean;
}) {
  return (
    <>
      {embedded && (
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-[13px] tracking-[0.34em] text-amber-glow uppercase">
            Tape
          </h2>
          <button
            onClick={onClear}
            className="grid h-8 w-8 place-items-center rounded-full border border-white/8 text-mint-text/45 transition hover:border-amber-glow/40 hover:text-amber-glow"
            aria-label="Clear tape"
          >
            <IconTrash size={15} />
          </button>
        </div>
      )}
      <div className="scroll-thin flex-1 space-y-2 overflow-y-auto pr-1">
        {tape.length === 0 && (
          <div className="mt-10 text-center">
            <p className="font-mono text-[12px] text-mint-text/30">No calculations yet</p>
            <p className="mt-1 font-mono text-[11px] text-mint-text/20">
              Results stay on this device only.
            </p>
          </div>
        )}
        <AnimatePresence initial={false}>
          {tape.map((entry) => (
            <motion.button
              key={entry.at + entry.expr}
              layout
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, x: 20 }}
              onClick={() => onPick(entry.result.replace(/,/g, ""))}
              className="block w-full rounded-2xl border border-white/6 bg-white/3 px-4 py-3 text-left transition hover:border-amber-glow/30 hover:bg-amber-glow/6"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="truncate font-mono text-[12px] text-mint-text/45">{entry.expr} =</span>
                <span className="font-mono text-[10px] text-mint-text/25">{clockTime(entry.at)}</span>
              </div>
              <div className="mt-0.5 truncate font-mono text-[19px] text-amber-glow/90">
                {entry.result}
              </div>
            </motion.button>
          ))}
        </AnimatePresence>
      </div>
      <div className="mt-4 border-t border-white/6 pt-3">
        <Link
          href="/guide"
          className="font-mono text-[10.5px] tracking-[0.16em] text-mint-text/28 uppercase transition hover:text-amber-glow/80"
        >
          app notes & build manual →
        </Link>
      </div>
      {!embedded && (
        <button
          onClick={onClear}
          className="mt-3 flex items-center justify-center gap-2 rounded-2xl border border-white/8 py-2.5 font-mono text-[11px] tracking-[0.18em] text-mint-text/45 uppercase transition hover:border-amber-glow/40 hover:text-amber-glow"
        >
          <IconTrash size={14} /> clear tape
        </button>
      )}
    </>
  );
}
