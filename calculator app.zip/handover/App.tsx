/**
 * handover/App.tsx — React Native / Expo SDK 51 port skeleton
 * ─────────────────────────────────────────────────────────────
 * This is the mobile twin of the web reference build in `src/`.
 * Drop it into an Expo SDK 51 project as `App.tsx`.
 *
 *   npm i @react-native-async-storage/async-storage expo-haptics
 *         expo-image-picker react-native-reanimated react-native-safe-area-context
 *
 * Marked insertion points:
 *   // >>> VAULT UI INSERTION POINT      (chat/call screens)
 *   // >>> HAPTICS INSERTION POINT        (tactile feedback)
 */
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Haptics from "expo-haptics";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  Pressable,
  StatusBar,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
} from "react-native";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";
import { login, pullBootstrap } from "./handover/backend";

const SECRET_SEQUENCE = "74+88"; // keep in sync with src/lib/config.ts
const SESSION_KEY = "hustler.session";

type User = { handle: string; name: string; hue: number; role: string };

export default function App() {
  const { width } = useWindowDimensions();
  const isTablet = width >= 720; // responsive: tablets get a two-pane vault

  const [expression, setExpression] = useState("0");
  const [unlocked, setUnlocked] = useState(false);
  const [me, setMe] = useState<User | null>(null);
  const [bootstrapped, setBootstrapped] = useState(false);

  /* rehydrate a previous stealth session from AsyncStorage */
  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(SESSION_KEY);
        if (raw) setMe(JSON.parse(raw));
      } catch {
        /* storage unavailable → stay on the cover */
      }
    })();
  }, []);

  const tap = useCallback(async (key: string) => {
    // >>> HAPTICS INSERTION POINT
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});

    if (key === "C") return setExpression("0");
    if (key === "⌫")
      return setExpression((e) => (e.length <= 1 ? "0" : e.slice(0, -1)));
    if (key === "=") {
      const compact = expression.replace(/\s/g, "");
      if (compact === SECRET_SEQUENCE) {
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(
          () => {},
        );
        setUnlocked(true);
        return;
      }
      // normal calculator behaviour — never hint at the second layer
      return setExpression(String(safeEval(compact)));
    }
    setExpression((e) => (e === "0" ? key : e + key));
  }, [expression]);

  const signIn = useCallback(async (handle: string, password: string) => {
    const user = await login(handle, password); // see handover/backend.ts
    if (!user) throw new Error("Invalid username or password");
    setMe(user);
    await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(user));
    const vault = await pullBootstrap();
    setBootstrapped(!!vault);
    return user;
  }, []);

  const keys = useMemo(
    () => ["C", "⌫", "%", "÷", "7", "8", "9", "×", "4", "5", "6", "−", "1", "2", "3", "+", "±", "0", ".", "="],
    [],
  );

  if (unlocked && !me) {
    // >>> VAULT UI INSERTION POINT — render <VaultLogin onSignIn={signIn} />
    return (
      <SafeAreaProvider>
        <SafeAreaView style={s.center}>
          <Text style={s.title}>Select operator</Text>
          <Text style={s.hint}>pov_navneet · pov_shreya · pov_navya · w.o.n.s</Text>
        </SafeAreaView>
      </SafeAreaProvider>
    );
  }

  if (unlocked && me) {
    // >>> VAULT UI INSERTION POINT — render <VaultApp me={me} twoPane={isTablet} />
    return (
      <SafeAreaProvider>
        <SafeAreaView style={s.center}>
          <Text style={s.title}>{me.name}</Text>
          <Text style={s.hint}>vault ready · {bootstrapped ? "synced" : "syncing"}</Text>
        </SafeAreaView>
      </SafeAreaProvider>
    );
  }

  /* ── THE COVER: a plain, sleek, glowing calculator ── */
  return (
    <SafeAreaProvider>
      <StatusBar barStyle="light-content" backgroundColor="#0d1113" />
      <SafeAreaView style={[s.cover, isTablet && s.coverTablet]}>
        <Text style={s.appName}>Hustler Calculator</Text>
        <View style={s.display}>
          <Text style={s.readout} numberOfLines={1}>
            {expression}
          </Text>
        </View>
        <View style={[s.pad, isTablet && s.padTablet]}>
          {keys.map((k) => (
            <Pressable
              key={k}
              onPress={() => tap(k)}
              style={({ pressed }) => [s.key, pressed && s.keyPressed, k === "=" && s.keyAccent]}
            >
              <Text style={[s.keyText, k === "=" && s.keyAccentText]}>{k}</Text>
            </Pressable>
          ))}
        </View>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

/** Small, dependency-free arithmetic evaluator (mirrors src/components/calculator/calcEngine.ts). */
function safeEval(input: string): number {
  const tokens = input.replace(/×/g, "*").replace(/÷/g, "/").replace(/−/g, "-").match(/\d+(\.\d+)?|[+\-*/%]/g);
  if (!tokens) return 0;
  let value = Number(tokens[0]);
  let op = "";
  for (let i = 1; i < tokens.length; i++) {
    const t = tokens[i];
    if (/[+\-*/%]/.test(t)) op = t;
    else {
      const n = Number(t);
      if (op === "+") value += n;
      if (op === "-") value -= n;
      if (op === "*") value *= n;
      if (op === "/") value = n === 0 ? NaN : value / n;
      if (op === "%") value = value % n;
      op = "";
    }
  }
  return Number.isFinite(value) ? Math.round(value * 1e10) / 1e10 : 0;
}

const s = StyleSheet.create({
  cover: { flex: 1, backgroundColor: "#0d1113", padding: 20, justifyContent: "flex-end" },
  coverTablet: { maxWidth: 620, width: "100%", alignSelf: "center", borderRadius: 28 },
  center: { flex: 1, backgroundColor: "#0b141a", alignItems: "center", justifyContent: "center" },
  appName: { color: "#6b7a76", fontSize: 13, letterSpacing: 3, textAlign: "center", marginBottom: 12 },
  display: { alignItems: "flex-end", paddingVertical: 28, paddingHorizontal: 8 },
  readout: { color: "#ffb347", fontSize: 56, fontWeight: "300" },
  title: { color: "#e8f5ef", fontSize: 26, fontWeight: "700" },
  hint: { color: "#7f9c91", marginTop: 8 },
  pad: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  padTablet: { gap: 14 },
  key: {
    width: "22%", aspectRatio: 1, borderRadius: 22, backgroundColor: "#161b1e",
    alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#232a2d",
  },
  keyPressed: { backgroundColor: "#242b2f", transform: [{ scale: 0.96 }] },
  keyAccent: { backgroundColor: "#ffb347", borderColor: "#ffd79a" },
  keyText: { color: "#e8f0ee", fontSize: 24 },
  keyAccentText: { color: "#20160a", fontWeight: "700" },
});
