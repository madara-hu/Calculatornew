/**
 * handover/cloudflare/worker.ts — Hustler Vault edge relay (Durable Object SSE)
 * ─────────────────────────────────────────────────────────────────────────────
 * Deploy:
 *   cd handover/cloudflare
 *   npx wrangler login
 *   npx wrangler secret put RELAY_TOKEN      # long random string, same as .env
 *   npx wrangler deploy
 *
 * You get two URLs:
 *   https://hustler-vault-relay.<you>.workers.dev/internal/publish  → CLOUDFLARE_RELAY_URL
 *   https://hustler-vault-relay.<you>.workers.dev/stream            → NEXT_PUBLIC_CLOUDFLARE_STREAM_URL
 *   https://hustler-vault-relay.<you>.workers.dev/healthz           → used by the probe button
 *
 * The Next.js server publishes every vault event here; every connected device
 * (web tab OR Expo app) receives it from the edge in ~50ms, across instances.
 */

export interface Env {
  RELAY_TOKEN: string;
  VAULT_DO: DurableObjectNamespace;
}

const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json", "cache-control": "no-store" },
  });

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const stub = env.VAULT_DO.get(env.VAULT_DO.idFromName("hustler-vault"));

    // CORS so the Expo app / any browser origin can open the stream
    const cors = {
      "access-control-allow-origin": "*",
      "access-control-allow-headers": "content-type,x-relay-token",
      "access-control-allow-methods": "GET,POST,OPTIONS",
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });

    if (url.pathname === "/healthz") return json({ ok: true, at: Date.now() });

    if (url.pathname === "/internal/publish") {
      if (request.method !== "POST") return json({ error: "POST only" }, 405);
      if (request.headers.get("x-relay-token") !== env.RELAY_TOKEN) {
        return json({ error: "bad token" }, 401);
      }
      const envelope = await request.json();
      return (await stub.publish(envelope)) as Response;
    }

    if (url.pathname === "/stream") {
      // ?user=<id> lets the DO filter by audience, mirroring /api/stream
      const userId = Number(url.searchParams.get("user") ?? 0) || null;
      return (await stub.stream(userId)) as Response;
    }

    return json({ error: "unknown path", hint: "/stream · /internal/publish · /healthz" }, 404);
  },
};

export class VaultRelay {
  private clients: { id: number; user: number | null; ctrl: ReadableStreamDefaultController }[] = [];
  private nextId = 1;
  private timer: ReturnType<typeof setInterval> | null = null;
  private counters = { published: 0, delivered: 0 };

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  async publish(envelope: any) {
    this.counters.published += 1;
    const payload = `event: vault\ndata: ${JSON.stringify(envelope?.event ?? envelope)}\n\n`;
    const audience: number[] | null = envelope?.audience ?? null;

    this.clients = this.clients.filter((client) => {
      if (audience && client.user && !audience.includes(client.user)) return true; // keep, just skip
      try {
        client.ctrl.enqueue(new TextEncoder().encode(payload));
        this.counters.delivered += 1;
        return true;
      } catch {
        return false; // socket gone
      }
    });

    return json({ ok: true, clients: this.clients.length, ...this.counters });
  }

  async stream(userId: number | null) {
    const encoder = new TextEncoder();
    let mine: { id: number; user: number | null; ctrl: ReadableStreamDefaultController } | null = null;

    const body = new ReadableStream({
      start: (ctrl) => {
        mine = { id: this.nextId++, user: userId, ctrl };
        this.clients.push(mine);
        ctrl.enqueue(
          encoder.encode(
            `event: hello\ndata: ${JSON.stringify({
              ok: true,
              relay: "cloudflare-durable-object",
              clients: this.clients.length,
              at: Date.now(),
            })}\n\n`,
          ),
        );
        if (!this.timer) {
          this.timer = setInterval(() => {
            const beat = encoder.encode(`event: ping\ndata: ${JSON.stringify({ at: Date.now() })}\n\n`);
            this.clients = this.clients.filter((c) => {
              try {
                c.ctrl.enqueue(beat);
                return true;
              } catch {
                return false;
              }
            });
            if (!this.clients.length && this.timer) {
              clearInterval(this.timer);
              this.timer = null;
            }
          }, 20_000);
        }
      },
      cancel: () => {
        if (mine) this.clients = this.clients.filter((c) => c.id !== mine!.id);
      },
    });

    return new Response(body, {
      headers: {
        "content-type": "text/event-stream; charset=utf-8",
        "cache-control": "no-cache, no-transform",
        connection: "keep-alive",
        "access-control-allow-origin": "*",
      },
    });
  }
}
