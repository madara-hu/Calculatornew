/**
 * handover/backend.ts — the ONE data adapter the mobile app talks to.
 * ───────────────────────────────────────────────────────────────────
 * Point `API_BASE` at this Next.js deployment, or swap in Firebase / Cloudflare
 * using the marked insertion points. Payload contract: `src/lib/types.ts`.
 */

export const API_BASE =
  (typeof process !== "undefined" && process.env?.EXPO_PUBLIC_API_BASE) ||
  "http://10.0.2.2:3000"; // Android emulator → host machine

let cookie = "";

async function call<T>(path: string, init: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: {
      "content-type": "application/json",
      ...(cookie ? { cookie } : {}),
      ...(init.headers ?? {}),
    },
  });
  const setCookie = res.headers.get("set-cookie");
  if (setCookie) cookie = setCookie.split(";")[0];
  if (!res.ok) {
    const err = (await res.json().catch(() => ({}))) as { error?: string };
    throw new Error(err.error || `Request failed (${res.status})`);
  }
  return (await res.json()) as T;
}

/* ── AUTH ────────────────────────────────────────────────────────── */

export type SessionUser = { id: number; handle: string; name: string; hue: number; role: string };

export async function login(handle: string, password: string): Promise<SessionUser> {
  const { me } = await call<{ me: SessionUser }>("/api/auth", {
    method: "POST",
    body: JSON.stringify({ handle, password }),
  });
  return me;
}

export const logout = () => call<{ ok: boolean }>("/api/auth", { method: "DELETE" });

/* ── VAULT ───────────────────────────────────────────────────────── */

export const pullBootstrap = () => call<Record<string, unknown>>("/api/bootstrap");

export const pullSync = (after: number, open?: number) =>
  call<Record<string, unknown>>(`/api/sync?after=${after}${open ? `&open=${open}` : ""}`);

export const sendMessage = (payload: Record<string, unknown>) =>
  call<{ message: unknown }>("/api/messages", { method: "POST", body: JSON.stringify(payload) });

export const startCall = (conversationId: number, kind: "audio" | "video") =>
  call<{ call: unknown }>("/api/calls", {
    method: "POST",
    body: JSON.stringify({ conversationId, kind }),
  });

export const endCall = (id: number, status: string, durationSeconds: number) =>
  call<{ call: unknown }>("/api/calls", {
    method: "PATCH",
    body: JSON.stringify({ id, status, durationSeconds }),
  });

/* ─────────────────────────────────────────────────────────────────
 * >>> FIREBASE INSERTION POINT
 * Replace `call()` above with Firestore listeners for realtime chat:
 *
 *   import { initializeApp } from "firebase/app";
 *   import { getFirestore, collection, onSnapshot, query, where } from "firebase/firestore";
 *   const app = initializeApp({ apiKey: process.env.EXPO_PUBLIC_FIREBASE_API_KEY, ... });
 *   export const firestore = getFirestore(app);
 *   export const watchThread = (id: number, cb: (m: unknown[]) => void) =>
 *     onSnapshot(query(collection(firestore, `threads/${id}/messages`), where("expiresAt", ">", Date.now())),
 *                (snap) => cb(snap.docs.map((d) => d.data())));
 * ───────────────────────────────────────────────────────────────── */

/* ─────────────────────────────────────────────────────────────────
 * >>> CLOUDFLARE INSERTION POINT
 * Workers + D1 alternative — keep the same JSON contract:
 *
 *   export const API_BASE = "https://vault.<your-subdomain>.workers.dev";
 *   // Worker routes: POST /auth, GET /bootstrap, GET /sync, POST /messages
 *   // D1 table mirrors src/db/schema.ts (messages.expiresAt drives the purge cron)
 * ───────────────────────────────────────────────────────────────── */

/* ─────────────────────────────────────────────────────────────────
 * >>> AUTO-PURGE INSERTION POINT (server side, if you leave Next.js)
 *   Cloudflare: Cron Trigger "0 *\/6 * * *" → DELETE FROM messages WHERE expires_at < now
 *   Firebase:   Scheduled Cloud Function, same query, batched 400 docs per pass
 * ───────────────────────────────────────────────────────────────── */
