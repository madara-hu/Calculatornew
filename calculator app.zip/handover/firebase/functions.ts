/**
 * handover/firebase/functions.ts — Firebase side of the vault
 * ────────────────────────────────────────────────────────────
 *   cd handover/firebase && npm i firebase-functions firebase-admin
 *   firebase deploy --only functions,firestore:rules
 *
 * Two jobs:
 *   1. purgeExpiredVaultMessages — hourly sweep, the Firestore twin of
 *      purgeExpired() in src/lib/repo.ts. Keeps the 48h promise even if the
 *      Next.js server is asleep.
 *   2. issueVaultToken — mints the custom auth token the Expo app needs so
 *      firestore.rules can check `request.auth.token.handle`.
 */
import { initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore, Query, Timestamp } from "firebase-admin/firestore";
import { onRequest } from "firebase-functions/v2/https";
import { onSchedule } from "firebase-functions/v2/scheduler";

initializeApp();
const db = getFirestore();

/** The four seats. Keep in sync with src/lib/config.ts → USERS[].handle */
const MEMBERS = ["pov_navneet", "pov_shreya", "pov_navya", "w.o.n.s"] as const;
const PURGE_HOURS = 48;

export const purgeExpiredVaultMessages = onSchedule(
  { schedule: "every 1 hours", timeZone: "Asia/Kolkata" },
  async () => {
    const cutoff = Timestamp.fromMillis(Date.now());
    let total = 0;

    const threads = await db.collection("threads").listDocuments();
    for (const thread of threads) {
      const expired: Query = thread
        .collection("messages")
        .where("expiresAt", "<", cutoff)
        .limit(400);

      // Batched deletes: Firestore caps a commit at 500 operations.
      for (;;) {
        const snap = await expired.get();
        if (snap.empty) break;
        const batch = db.batch();
        snap.docs.forEach((doc) => batch.delete(doc.ref));
        await batch.commit();
        total += snap.size;
        if (snap.size < 400) break;
      }
    }

    await db.doc("meta/purge/last").set({ purged: total, at: Timestamp.now() });
    console.log(`[hustler] burned ${total} expired message(s)`);
  },
);

/**
 * POST { "handle": "pov_navneet", "password": "Navneet@7488" }
 * → { "token": "<custom auth token>" }
 *
 * The Expo app calls this once at login, stores the token in AsyncStorage and
 * passes it to firestore.rules via `handle` claim. Passwords are verified
 * against Postgres by the Next.js server first (see SETUP_GUIDE.md §7.3) — this
 * endpoint is meant to sit behind that same check, so wire it to your own
 * /api/auth exchange rather than exposing raw passwords.
 */
export const issueVaultToken = onRequest(async (req, res) => {
  res.set("Access-Control-Allow-Origin", "*");
  res.set("Access-Control-Allow-Headers", "content-type");
  if (req.method === "OPTIONS") {
    res.status(204).send("");
    return;
  }
  if (req.method !== "POST") {
    res.status(405).json({ error: "POST only" });
    return;
  }

  const handle = String(req.body?.handle ?? "")
    .trim()
    .toLowerCase();
  if (!MEMBERS.includes(handle as (typeof MEMBERS)[number])) {
    res.status(401).json({ error: "Unknown seat — the vault has exactly four" });
    return;
  }

  // >>> PASSWORD VERIFICATION INSERTION POINT
  // Verify against your source of truth (Next.js /api/auth, D1, or a secret
  // hash map) BEFORE minting a token. Never trust the client.
  const verified = Boolean(req.body?.verifiedByBackend);
  if (!verified) {
    res.status(401).json({ error: "Password not verified by the backend" });
    return;
  }

  const uid = `vault-${handle}`;
  try {
    await getAuth().updateUser(uid, { customClaims: { handle } });
  } catch {
    await getAuth().createUser({ uid, customClaims: { handle } });
  }
  const token = await getAuth().createCustomToken(uid, { handle });
  res.json({ token, handle, purgeHours: PURGE_HOURS });
});
