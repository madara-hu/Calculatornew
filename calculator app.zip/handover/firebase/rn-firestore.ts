/**
 * handover/firebase/rn-firestore.ts — realtime for the Expo / React Native build
 * ──────────────────────────────────────────────────────────────────────────────
 *   npx expo install firebase
 *
 * Keys come from eas.json → build profile → env (all EXPO_PUBLIC_* so they are
 * readable on the device). These are *client* keys: safe to ship, and locked
 * down by handover/firebase/firestore.rules.
 *
 *   EXPO_PUBLIC_FIREBASE_PROJECT_ID   hustler-vault
 *   EXPO_PUBLIC_FIREBASE_API_KEY      AIza...
 *   EXPO_PUBLIC_FIREBASE_SENDER_ID    1234567890
 *   EXPO_PUBLIC_FIREBASE_APP_ID       1:1234567890:android:abcdef
 */
import AsyncStorage from "@react-native-async-storage/async-storage";
import { getApp, getApps, initializeApp } from "firebase/app";
import {
  collection,
  getFirestore,
  limit,
  onSnapshot,
  orderBy,
  query,
  signInWithCustomToken,
  where,
} from "firebase/firestore";
import { getAuth } from "firebase/auth";

const PROJECT_ID = process.env.EXPO_PUBLIC_FIREBASE_PROJECT_ID ?? "";

export const firebaseApp = getApps().length
  ? getApp()
  : initializeApp({
      apiKey: process.env.EXPO_PUBLIC_FIREBASE_API_KEY,
      authDomain: `${PROJECT_ID}.firebaseapp.com`,
      projectId: PROJECT_ID,
      storageBucket: `${PROJECT_ID}.appspot.com`,
      messagingSenderId: process.env.EXPO_PUBLIC_FIREBASE_SENDER_ID,
      appId: process.env.EXPO_PUBLIC_FIREBASE_APP_ID,
    });

export const firestore = getFirestore(firebaseApp);
export const auth = getAuth(firebaseApp);

const TOKEN_KEY = "hustler.firebase.token";

/** Call once after /api/auth login succeeds with the token from issueVaultToken. */
export async function attachVaultToken(token: string) {
  await AsyncStorage.setItem(TOKEN_KEY, token);
  await signInWithCustomToken(auth, token);
}

export async function restoreVaultSession() {
  const token = await AsyncStorage.getItem(TOKEN_KEY);
  if (!token) return false;
  try {
    await signInWithCustomToken(auth, token);
    return true;
  } catch {
    return false; // expired → login again
  }
}

export type VaultMessage = {
  id: string;
  senderId: number;
  kind: string;
  body: string;
  mediaData?: string;
  stickerId?: string;
  status: string;
  createdAt: { toDate: () => Date };
  expiresAt: { toDate: () => Date };
};

/**
 * Live thread subscription. Mirrors src/lib/types.ts → MessageWire, and honours
 * the same 48h window so the mobile view can never show a burned message.
 */
export function watchThread(conversationId: number, onChange: (messages: VaultMessage[]) => void) {
  const q = query(
    collection(firestore, `threads/${conversationId}/messages`),
    where("expiresAt", ">", new Date()),
    orderBy("expiresAt"),
    orderBy("createdAt"),
    limit(200),
  );
  return onSnapshot(
    q,
    (snap) => onChange(snap.docs.map((d) => ({ id: d.id, ...(d.data() as object) }) as VaultMessage)),
    (err) => console.warn("[hustler] snapshot failed", err.message),
  );
}

export function watchCalls(conversationId: number, onChange: (calls: unknown[]) => void) {
  return onSnapshot(
    query(collection(firestore, `threads/${conversationId}/calls`), orderBy("startedAt", "desc"), limit(40)),
    (snap) => onChange(snap.docs.map((d) => ({ id: d.id, ...d.data() }))),
  );
}
