#!/data/data/com.termux/files/usr/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
#  handover/termux.sh — one-shot Android (Termux) build for Hustler Calculator
# ─────────────────────────────────────────────────────────────────────────────
#  Usage (on the phone, inside Termux):
#     pkg install -y git
#     git clone <your-fork> hustler && cd hustler
#     bash handover/termux.sh
#
#  Everything is non-interactive so nothing hangs waiting for a keypress.
#  Cloud builds are used (no Android SDK needed on the phone).
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

say()  { printf '\n\033[1;36m▸ %s\033[0m\n' "$1"; }
ok()   { printf '  \033[1;32m✓\033[0m %s\n' "$1"; }
die()  { printf '  \033[1;31m✗ %s\033[0m\n' "$1" >&2; exit 1; }

say "1/7  Termux base packages"
pkg update -y && pkg upgrade -y
pkg install -y nodejs-lts git python make openssl openssh
termux-setup-storage 2>/dev/null || true   # tap ALLOW so the APK can be saved
ok "node $(node -v) · npm $(npm -v)"

say "2/7  Global CLIs (EAS + Expo)"
npm install -g eas-cli @expo/cli
ok "eas-cli $(eas --version 2>/dev/null || echo 'installed')"

say "3/7  Project dependencies"
[ -f package.json ] || die "run this from the project root (cd hustler first)"
npm install --no-audit --no-fund
ok "npm install clean"

say "4/7  Expo config health check (must be 0 problems)"
npx expo-doctor || die "expo-doctor found problems — fix app.json before building"
ok "expo-doctor passed"

say "5/7  Expo login"
if [ -n "${EXPO_TOKEN:-}" ]; then
  eas whoami && ok "logged in with EXPO_TOKEN (non-interactive)"
else
  echo "  No EXPO_TOKEN found. Either:"
  echo "    export EXPO_TOKEN=xxxxxxxx   (recommended for SSH/Termux)"
  echo "  or run the interactive login now:"
  eas login
fi

say "6/7  Env file"
if [ ! -f .env ]; then
  cp handover/.env.example .env
  ok ".env created from template — edit DATABASE_URL, AUTH_SECRET, FIREBASE_*, CLOUDFLARE_*"
else
  ok ".env already present (left untouched)"
fi

say "7/7  Build the Android APK in the cloud"
echo "  Preview build (APK, installs directly on the phone):"
echo "    eas build -p android --profile preview --non-interactive"
echo "  Production build (AAB for Play Store):"
echo "    eas build -p android --profile production --non-interactive"
echo
read -r -p "  Start the preview build now? [y/N] " answer
if [[ "$answer" =~ ^[Yy]$ ]]; then
  eas build -p android --profile preview --non-interactive
  ok "build queued — EAS prints a URL; download it on the phone and tap to install"
  echo "  Save the APK to shared storage with:"
  echo "    eas build:download --path ~/storage/downloads/hustler.apk"
else
  ok "skipped — run the command above whenever you are ready"
fi

printf '\n\033[1;32mDone.\033[0m Next: bash handover/codespace.sh if you also build from a Codespace.\n'
