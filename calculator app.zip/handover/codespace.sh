#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
#  handover/codespace.sh — GitHub Codespace / SSH build for Hustler Calculator
# ─────────────────────────────────────────────────────────────────────────────
#  Usage (inside the Codespace terminal, or over `gh cs ssh`):
#     bash handover/codespace.sh            # web app + checks
#     bash handover/codespace.sh apk        # + cloud Android build (APK)
#
#  Non-interactive by design: EXPO_TOKEN replaces the browser login flow, which
#  is the #1 reason EAS fails over SSH.
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

say()  { printf '\n\033[1;36m▸ %s\033[0m\n' "$1"; }
ok()   { printf '  \033[1;32m✓\033[0m %s\n' "$1"; }
die()  { printf '  \033[1;31m✗ %s\033[0m\n' "$1" >&2; exit 1; }
MODE="${1:-web}"

say "1/6  Toolchain"
command -v node >/dev/null || die "node missing (Codespaces ship node 18/20 by default)"
ok "node $(node -v) · npm $(npm -v)"

say "2/6  Dependencies"
if [ -f package-lock.json ]; then npm ci --no-audit --no-fund; else npm install --no-audit --no-fund; fi
npm install -g eas-cli --no-audit --no-fund
ok "deps + eas-cli ready"

say "3/6  Env file"
if [ ! -f .env ]; then
  cp handover/.env.example .env
  ok ".env created — set DATABASE_URL / AUTH_SECRET (+ FIREBASE_* / CLOUDFLARE_* if used)"
else
  ok ".env already present (left untouched)"
fi
# shellcheck disable=SC1091
set -a; . ./.env; set +a

say "4/6  Postgres + schema"
if command -v psql >/dev/null && psql "$DATABASE_URL" -c 'select 1' >/dev/null 2>&1; then
  npx drizzle-kit push --force
  ok "schema pushed (seeding happens automatically on first request)"
else
  echo "  ! Postgres not reachable from here. In a Codespace add the PostgreSQL add-on,"
  echo "    or tunnel to it:  ssh -L 5432:localhost:5432 <host>   (then re-run)"
fi

say "5/6  Web app checks"
npm exec tsc -- --noEmit --pretty false && ok "typescript clean"
npm run build && ok "production build clean"
if [ "$MODE" = "web" ]; then
  echo
  echo "  Start it:  npm run start"
  echo "  Then forward the port: Codespaces → PORTS → 3000 → Forward"
  exit 0
fi

say "6/6  Android cloud build (APK)"
npx expo-doctor || die "expo-doctor found problems — fix handover/app.json first"
if [ -z "${EXPO_TOKEN:-}" ]; then
  die "EXPO_TOKEN not set. Create one at expo.dev → Account settings → Access tokens, then:  export EXPO_TOKEN=xxxx"
fi
eas whoami >/dev/null && ok "authenticated with EXPO_TOKEN (no browser needed)"
eas build -p android --profile preview --non-interactive
ok "build queued"
echo "  Download the APK straight into the Codespace:"
echo "    eas build:download --platform android --output ./hustler.apk"
echo "  Then pull it to your phone:  gh cs ssh  →  scp, or upload via the Files panel."
