# SETUP_GUIDE.md — Hustler Calculator & Stealth WhatsApp Vault

Developer handover for the **Hustler Calculator** stealth suite.

This repository ships two things:

| Layer | What it is | Where it lives |
| --- | --- | --- |
| **Running product** | A production Next.js 16 + PostgreSQL (Drizzle) full-stack build of the whole concept: glowing calculator cover → secret `74 + 88` unlock → four-user stealth WhatsApp vault with media, stickers, simulated calls, and a 48-hour auto-purge. | `src/` |
| **Mobile port kit** | Everything needed to re-host the exact same UX as a React Native / Expo SDK 51 Android app (phone + tablet) in Termux or a GitHub Codespace. | `handover/` + this file |

The web build is the reference implementation. The RN port kit mirrors it 1:1, so you
port screens, not concepts.

---

## 1. Run the reference build (local, Codespace, or container)

```bash
# 1. install
npm install

# 2. point at Postgres (already present in .env for the sandbox)
#    DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
#    AUTH_SECRET=<any long random string — used to salt the four PIN hashes>

# 3. create tables (schema lives in src/db/schema.ts)
npx drizzle-kit push

# 4. build + start
npm run build && npm run start
```

Seeding is **automatic and idempotent** (`src/db/seed.ts`). The first authenticated
request creates the four accounts, the group thread, all six 1:1 threads, the built-in
sticker packs and a small amount of demo history. Bump `SEED_VERSION` in
`src/lib/config.ts` (currently `5`) to force a clean reseed — required after changing any
username or password, because the four seats are rebuilt from scratch.

### Credentials (the four hardcoded accounts)

| # | Username | Display name | Password | Role |
| --- | --- | --- | --- | --- |
| 1 | `pov_navneet` | Navneet | `Navneet@7488` | Operator |
| 2 | `pov_shreya` | Shreya | `Shreya@1234` | Handler |
| 3 | `pov_navya` | Navya | `Navya@5678` | Logistics |
| 4 | `w.o.n.s` | W.O.N.S | `Wons@9999` | Runner |

Four seats, four **different** passwords. There is **no sign-up, no OAuth, no Gmail** —
`/api/auth` only accepts those four usernames. Five failed logins lock that username
for 30 seconds, and the error message is identical for "unknown username" and "wrong
password" so accounts cannot be enumerated.

Passwords are **never stored in plain text**. Each account gets a random 16-byte salt at
seed time and only this is written to Postgres:

```
sha256( salt : handle : password : AUTH_SECRET )
```

Comparison runs through `crypto.timingSafeEqual`. The login screen can reveal the seeded
passwords while `EXPOSE_DEMO_CREDENTIALS=true` (default) — set it to `false` in `.env`
before a real rollout and the credentials exist only as hashes.

### Unlocking the vault

On the cover calculator type **`74 + 88 =`**. Any other expression evaluates normally
and never hints that a second layer exists.

---

## 2. API surface (already implemented)

| Method | Route | Purpose |
| --- | --- | --- |
| `GET` | `/api/health` | Liveness probe |
| `GET/POST/DELETE` | `/api/auth` | Who am I + public roster / login with username+password / burn session |
| `GET` | `/api/bootstrap` | Full vault payload: users, threads, ≤48h messages, calls, stickers, purge telemetry |
| `GET` | `/api/sync?after=&ac=&as=&open=` | Delta feed. **Every call runs the auto-purge sweep.** `open` drives delivery/read ticks |
| `POST` | `/api/messages` | Send text / image / sticker / voice |
| `POST` | `/api/messages/simulate` | Offline companion reply from one of the other three users |
| `DELETE` | `/api/messages/:id` | Delete for everyone |
| `POST/PATCH` | `/api/calls` | Start an audio/video call, then end it with status + duration |
| `POST/DELETE` | `/api/stickers` | Import a sticker from an external app link (`https://…`) or a device upload (data URI) |
| `GET` | `/api/purge` | Simulator flag + alive/burned counters |
| `POST` | `/api/purge` | Manual sweep and/or toggle the reply simulator |
| `GET` | `/api/stream` | **Server-Sent Events** — instant push of messages, calls, stickers, read receipts, purges |
| `GET/POST` | `/api/realtime` | Live transport diagnostics (SSE / Cloudflare / Firebase) · POST fires a test event |
| `GET` | `/api/download/:file` | Downloads this guide plus any file of the `handover/` kit |
| `GET` | `/api/download/all` | **`hustler-handover.zip`** — the whole kit as one archive |

---

## 3. Exact code insertion points

Every configurable value is centralised. **Do not grep the codebase — edit these files.**

| You want to change… | File | Symbol |
| --- | --- | --- |
| Any username / password / avatar hue / the 4th seat | `src/lib/config.ts` | `USERS[]` |
| The secret unlock expression | `src/lib/config.ts` | `SECRET_SEQUENCE`, `SECRET_ANSWER` |
| The purge window (24h vs 48h) | `src/lib/config.ts` | `PURGE_HOURS` |
| Session lifetime | `src/lib/config.ts` | `SESSION_DAYS` |
| Password hashing pepper | `.env` | `AUTH_SECRET` |
| Reveal seeded passwords on the login screen | `.env` | `EXPOSE_DEMO_CREDENTIALS` |
| Database URL | `.env` | `DATABASE_URL` |
| Cover calculator engine | `src/components/calculator/calcEngine.ts` | `evaluate()` |
| Secret detection hook | `src/components/calculator/Calculator.tsx` | `handleEquals()` |
| Vault data access (web) | `src/lib/client.ts` | `Auth.*`, `Vault.*` |
| Realtime fan-out (SSE bus) | `src/lib/realtime/bus.ts` | `publish()`, `subscribe()` |
| Firebase / Firestore mirror | `src/lib/realtime/firebase.ts` | `mirror()` |
| Cloudflare edge relay | `src/lib/realtime/cloudflare.ts` | `relay()`, `probe()` |
| One call that feeds all three | `src/lib/realtime/index.ts` | `broadcast()` |
| Browser socket + polling fallback | `src/lib/vault-store.tsx` | the `realtime:` effect |

### 3.1 Plugging in Firebase (Firestore realtime chat)

Open **`handover/backend.ts`** — it is the single adapter the mobile app talks to.
Search for `// >>> FIREBASE INSERTION POINT` and paste:

```ts
import { initializeApp } from "firebase/app";
import { getFirestore, doc, onSnapshot, setDoc } from "firebase/firestore";

const app = initializeApp({
  apiKey: process.env.EXPO_PUBLIC_FIREBASE_API_KEY,
  authDomain: "<project>.firebaseapp.com",
  projectId: "<project-id>",
  storageBucket: "<project>.appspot.com",
  messagingSenderId: "<sender-id>",
  appId: "<app-id>",
});
export const db = getFirestore(app);
```

Env vars for Expo must be prefixed `EXPO_PUBLIC_*` and live in `.env` at the RN project
root. Never commit real keys.

### 3.2 Plugging in Cloudflare (D1 + Workers)

Same file, `// >>> CLOUDFLARE INSERTION POINT`:

```ts
export const API_BASE = "https://vault.<your-subdomain>.workers.dev";
// Worker routes expected: POST /auth, GET /bootstrap, GET /sync, POST /messages
```

Or simply point `API_BASE` at this Next.js deployment — the payload shapes in
`src/lib/types.ts` are the contract.

---

## 4. Porting to React Native / Expo SDK 51 (Android phone + tablet)

The kit in `handover/` is already SDK 51-clean:

* `handover/app.json` — valid Expo 51 schema. **No `softwareKeyboardMode`, no
  `cpuArchitecture`, no other unsupported keys**, so `expo-doctor` and the Gradle
  prebuild pass on the first attempt and cloud build quota is not wasted.
* `handover/eas.json` — `development`, `preview` (APK) and `production` (AAB) profiles.
* `handover/App.tsx` — the two-layer shell: calculator cover, secret `74+88` detection,
  `AsyncStorage` rehydrate, and the vault navigation stub.
* `handover/backend.ts` — the data adapter with all insertion points.

### 4.1 Termux (on-device)

```bash
pkg update -y && pkg upgrade -y
pkg install -y nodejs-lts git python make clang
npm install -g expo-cli eas-cli

git clone <your-fork> hustler && cd hustler
npm install
npm install @react-native-async-storage/async-storage expo-image-picker \
            expo-av expo-haptics react-native-reanimated react-native-safe-area-context

npx expo start -c            # dev against Expo Go / dev client
npx expo prebuild -p android # generates android/ (Gradle)
npx eas-cli build -p android --profile preview
```

AsyncStorage note: with SDK 51 the package autolinks. If a bundler crash appears, run
`npx expo prebuild --clean` and rebuild — never hand-edit `MainApplication`.

### 4.2 GitHub Codespace

```bash
npm install
npx expo start --tunnel      # scan the QR with Expo Go on the Android device
npx expo-doctor              # must print 0 problems
npx eas-cli login && npx eas-cli build -p android --profile preview
```

### 4.3 Packaging the deliverable zip

```bash
zip -r hustler-calculator.zip . \
  -x "node_modules/*" -x ".expo/*" -x "android/*" -x "ios/*" -x ".next/*"
```

---

## 5. Auto-purge / anti-bloat routine

* Every message is written with `expiresAt = createdAt + PURGE_HOURS` (48h default).
* `purgeExpired()` (`src/lib/repo.ts`) runs on **every** `/api/bootstrap` and
  `/api/sync` request, so the sweep happens continuously without a cron worker.
* `POST /api/purge` triggers an immediate manual sweep from the Settings tab.
* Each sweep writes a `purge_events` audit row (last 25 kept) — the Settings tab shows
  **alive** vs **burned** message counts and the sweep log.
* The client also drops any message whose `expiresAt` has passed, so a stale tab never
  renders expired content.

---

## 6. Security notes for a production rollout

1. Set a real `AUTH_SECRET`; password hashes are `sha256(salt:handle:password:AUTH_SECRET)` with a random per-user salt, compared in constant time.
2. Serve over HTTPS so the `Secure` session cookie is honoured.
3. The reply simulator (`/api/messages/simulate`) exists so a single-device demo feels
   alive. Turn it off in Settings — or delete the route — before real deployment.
4. Media is stored inline as resized data URIs (client caps at ~1.2 MP / q0.72). For
   real traffic, swap `messages.mediaData` for object storage and keep only the key.
5. Calls are a fully rendered simulation (ringing → connected → duration logged). Drop
   in WebRTC / Agora / Zegocloud inside `src/components/vault/CallOverlay.tsx`, marked
   `// >>> LIVE MEDIA INSERTION POINT`.

---

## 7. Realtime — Cloudflare + Firebase (and a zero-config default)

Three transports, one code path. `broadcast()` (`src/lib/realtime/index.ts`) is called by
every mutation route (`/api/messages`, `/api/messages/simulate`, `/api/messages/:id`,
`/api/calls`, `/api/stickers`, `/api/purge`, `/api/sync`) and fans out to whichever
transports are configured. **Nothing has to be configured for realtime to work** — that is
the point.

| Transport | Needed for | Env keys | Behaviour when unset |
| --- | --- | --- | --- |
| Postgres + SSE | Everything, single instance | none | **always on** — `/api/stream` |
| Cloudflare Worker (Durable Object) | Edge fan-out, >1 instance, Expo app talking to the edge | `CLOUDFLARE_RELAY_URL`, `CLOUDFLARE_RELAY_TOKEN`, optional `NEXT_PUBLIC_CLOUDFLARE_STREAM_URL` | silent no-op |
| Firebase Firestore mirror | Expo/React Native `onSnapshot`, offline mobile reads | `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY` | silent no-op |

Both external hops are **fire-and-forget with a hard timeout**, so a wrong key, a dead
network or a 403 can never block or slow down a send. Errors are counted and shown in the
app instead: **Vault → Settings → Realtime engine**.

The client keeps the old `/api/sync` poll as a safety net: it runs every 2.4 s while the
socket is down, and relaxes to a 9 s heartbeat check while SSE is live (45 s freshness
window). Pull-to-refresh therefore never depends on the socket being healthy.

### 7.1 Zero-config (already running)

```bash
npm run build && npm run start
# open two browsers, log in as two different seats, send a message →
# it lands on the other screen instantly over /api/stream
```

Watch the counters move in **Settings → Realtime engine**, then press **send test event**.

### 7.2 Cloudflare edge relay (~4 minutes)

```bash
cd handover/cloudflare
npm i -D wrangler                 # or: npm i -g wrangler
npx wrangler login
npx wrangler secret put RELAY_TOKEN     # paste a long random string
npx wrangler deploy
```

Copy the printed URL into the project `.env`:

```bash
CLOUDFLARE_RELAY_URL=https://hustler-vault-relay.<you>.workers.dev/internal/publish
CLOUDFLARE_RELAY_TOKEN=<the same secret you just set>
NEXT_PUBLIC_CLOUDFLARE_STREAM_URL=https://hustler-vault-relay.<you>.workers.dev/stream
```

Restart the web app. The Settings panel now shows `transport: cloudflare-edge + postgres-sse`
and the probe line reports the Worker's `/healthz` latency. Devices connect with
`new EventSource("<stream-url>?user=<userId>")` — the Worker filters by audience exactly
like `/api/stream` does.

### 7.3 Firebase / Firestore mirror (~6 minutes)

1. Firebase console → **Project settings → Service accounts → Generate new private key**.
2. Put the three values in `.env` (keep the private key on one line, `\n` escapes intact):

```bash
FIREBASE_PROJECT_ID=hustler-vault
FIREBASE_CLIENT_EMAIL=firebase-adminsdk-xxxx@hustler-vault.iam.gserviceaccount.com
FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n"
```

3. Restart. Every message and call is now mirrored to
   `threads/{conversationId}/messages/{messageId}` with an `expiresAt` timestamp — no SDK,
   no extra npm package (it signs a service-account JWT with `node:crypto` and uses the
   Firestore REST `documents:commit` endpoint).
4. Lock it down and add the purge cron:

```bash
cd handover/firebase
firebase deploy --only firestore:rules      # handover/firebase/firestore.rules
firebase deploy --only functions            # handover/firebase/functions.ts
```

5. Expo side: `npx expo install firebase`, copy `handover/firebase/rn-firestore.ts` into the
   app, fill the `EXPO_PUBLIC_FIREBASE_*` slots in `handover/eas.json`, and call
   `watchThread(conversationId, setMessages)` — that is the whole mobile realtime layer.

> Auth for the rules: `issueVaultToken` (in `functions.ts`) mints a custom token carrying the
> `handle` claim. Mint it **only after** your Next.js `/api/auth` login succeeded, and never
> let the client verify a password itself.

---

## 8. Easiest build path — Termux on the phone, or Codespace over SSH

Both scripts are non-interactive, so nothing hangs waiting for a keypress and there is no
browser login step (the usual cause of EAS failures over SSH).

### 8.1 Termux (build from the phone itself)

```bash
pkg install -y git
git clone <your-fork> hustler && cd hustler
bash handover/termux.sh          # packages → deps → expo-doctor → login → build
```

One-shot manual version:

```bash
pkg update -y && pkg install -y nodejs-lts git python make openssl
npm i -g eas-cli
npm install --no-audit --no-fund
npx expo-doctor                                  # must print 0 problems
export EXPO_TOKEN=xxxxxxxx                         # expo.dev → Access tokens
cp handover/.env.example .env && nano .env
eas build -p android --profile preview --non-interactive
eas build:download --path ~/storage/downloads/hustler.apk
```

### 8.2 GitHub Codespace (also over `gh cs ssh`)

```bash
bash handover/codespace.sh          # web checks: tsc + build + drizzle push
bash handover/codespace.sh apk      # same, then cloud Android build
```

Manual version:

```bash
export EXPO_TOKEN=xxxxxxxx          # non-interactive EAS auth — do this first
npm ci && npm i -g eas-cli
cp handover/.env.example .env       # then edit DATABASE_URL / AUTH_SECRET / FIREBASE_* / CLOUDFLARE_*
npx drizzle-kit push --force
npm run build && npm run start      # Codespaces → PORTS → forward 3000
npx expo-doctor
eas build -p android --profile preview --non-interactive
eas build:download --platform android --output ./hustler.apk
```

### 8.3 The grab-everything shortcut

```bash
curl -OJ https://YOUR-HOST/api/download/all      # → hustler-handover.zip
unzip hustler-handover.zip && cd hustler-handover
```

The zip contains this guide, `.env.example`, `app.json`, `eas.json`, `App.tsx`,
`backend.ts`, `termux.sh`, `codespace.sh`, the Cloudflare Worker + `wrangler.toml`, the
Firestore rules + functions + the RN realtime client, and for reference
`src/lib/config.ts`, `src/lib/realtime/*.ts` and `src/db/schema.ts`.

### 8.4 No-error checklist

| Symptom | Cause | Fix |
| --- | --- | --- |
| `expo-doctor` complains about `app.json` | unsupported key added by hand | use `handover/app.json` as-is (SDK 51 schema, `softwareKeyboardLayoutMode` only) |
| EAS hangs at "Log in to Expo" | interactive prompt over SSH/Termux | `export EXPO_TOKEN=…` then re-run with `--non-interactive` |
| `AsyncStorage is not defined` / bundler crash | stale prebuild | `npx expo prebuild --clean` then rebuild |
| Gradle runs out of memory in the cloud | local build attempted on a phone | use `eas build` (cloud), not `--local`, on Termux |
| SSE connects but no events arrive | reverse proxy buffering | keep `X-Accel-Buffering: no` (already set) and disable proxy buffering for `/api/stream` |
| Settings panel says `firebase: not configured` | env not reloaded | restart the server after editing `.env` (Next reads env at boot) |
| Firestore rules deny reads | custom token missing the `handle` claim | mint via `issueVaultToken` after a successful `/api/auth` login |
